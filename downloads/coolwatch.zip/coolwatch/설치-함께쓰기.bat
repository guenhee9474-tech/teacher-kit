@echo off
rem coolwatch installer (hybrid: local AI filters, Claude summarizes): just double-click this file (no administrator rights needed)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install.ps1" -Mode hybrid
echo.
pause
