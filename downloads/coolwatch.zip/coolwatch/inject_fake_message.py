# inject_fake_message.py - 가짜 DB에 메시지를 한 건 추가합니다. (실시간 감지 시험용)
# 사용: python inject_fake_message.py [발신자ID] [제목] [본문]
#   예: python inject_fake_message.py 1001 "회의 안내" "내일까지 회신 바랍니다."
#   --touch-error  : 가짜 Error.log 수정 시각을 바꿔 중단 장치를 시험
import sys, sqlite3, pathlib
from make_fake_db import DB, FAKE, NAMES, add_message


def main():
    if "--touch-error" in sys.argv:
        with (FAKE / "test.udb_Error.log").open("ab") as f:
            f.write("UnknownFunc(20261007 14:00) - SOMETHING_BAD[1] : fake error\r\n".encode("utf-16-le"))
        print("가짜 Error.log를 수정했습니다.")
        return
    if "--benign-error" in sys.argv:  # 쿨메신저가 시작할 때 늘 적는 가벼운 기록 (연동이 멈추면 안 됨)
        with (FAKE / "test.udb_Error.log").open("ab") as f:
            f.write(("\r\nLogStart(20261007 14:00) - Ver : 5.75.80.1\r\n"
                     "GetCountRecycleBinMessageOfExpired(20261007 14:00) - CPPSQLITE_ERROR[1000] : "
                     "Null Virtual Machine pointer(CPPSQLITE_ERROR)\r\n").encode("utf-16-le"))
        print("가벼운 시작 기록을 추가했습니다.")
        return
    mid = int(sys.argv[1]) if len(sys.argv) > 1 else 1001
    title = sys.argv[2] if len(sys.argv) > 2 else "시험 메시지"
    text = sys.argv[3] if len(sys.argv) > 3 else "10월 20일까지 자료를 제출해 주세요."
    con = sqlite3.connect(DB)
    add_message(con, mid, NAMES[mid - 1001], title, text)
    con.commit()
    con.close()
    print("메시지를 추가했습니다.")


if __name__ == "__main__":
    main()
