# cm_save.py - 쿨메신저 메시지 창에서 '모든파일 저장' 단추를 대신 눌러, 첨부 파일을 받은 파일 폴더에 저장하게 합니다.
#
# 쿨메신저는 첨부를 받자마자 저장하지 않고, 사람이 저장을 눌러야 내려받습니다. 그 누름만 대신합니다.
# - 마우스·키보드를 움직이지 않습니다. 쿨메신저 창 안의 목록과 단추에만 신호를 보냅니다.
# - 좌표로 누르지 않습니다. 단추는 번호(3320)와 글자("모든파일 저장")로 찾습니다.
# - 누르기 전에, 화면에 뜬 첨부 줄의 글자가 받으려는 파일 이름과 맞는지 확인합니다. 다르면 누르지 않습니다.
# - 쿨메신저 DB 는 읽기만 합니다(common.connect_ro).
# 알아 둘 것: 그 메시지를 목록에서 골라야 하므로 읽음으로 바뀌고, 메시지 창이 그 글로 넘어갑니다.
#             메시지 창(메시지 관리함)이 열려 있어야 합니다. 닫혀 있으면 아무것도 하지 않습니다.
#
# 시험: python cm_save.py --try          가장 최근의 '첨부가 있고 아직 저장되지 않은' 메시지로 한 번 해 봄
#       python cm_save.py --try --look   고르기와 확인까지만 하고 저장은 누르지 않음
import ctypes, os, subprocess, sys, time
from ctypes import wintypes

from common import attachment_names, connect_ro

LIST_ID, SAVE_ID = 3195, 3320          # 메시지 목록, '모든파일 저장 (Ctrl+S)' 단추
SAVE_TEXT = "모든파일 저장"
WM_GETTEXT, WM_GETTEXTLENGTH, WM_KEYDOWN, WM_KEYUP, BM_CLICK = 0x000D, 0x000E, 0x0100, 0x0101, 0x00F5
VK_HOME, VK_DOWN = 0x24, 0x28
MAX_ROW = 30                            # 목록에서 이보다 아래에 있는 글은 건드리지 않음 (내려가며 지나친 글도 읽음으로 바뀌므로)

u = ctypes.windll.user32 if os.name == "nt" else None


def _text(h):
    n = u.SendMessageW(h, WM_GETTEXTLENGTH, 0, 0)
    buf = ctypes.create_unicode_buffer(n + 2)
    u.SendMessageW(h, WM_GETTEXT, n + 1, buf)
    return buf.value


def _cls(h):
    b = ctypes.create_unicode_buffer(64)
    u.GetClassNameW(h, b, 64)
    return b.value


def _rect(h):
    r = wintypes.RECT()
    u.GetWindowRect(h, ctypes.byref(r))
    return r.left, r.top, r.right - r.left, r.bottom - r.top


def _children(h):
    out = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(c, _):
        out.append(c)
        return True
    u.EnumChildWindows(h, cb, 0)
    return out


def message_window():
    """보이는 쿨메신저 창 가운데 메시지 목록이 든 창(메시지 관리함). 없으면 None"""
    try:
        out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True, encoding="cp949", errors="replace",
                             creationflags=0x08000000).stdout
    except OSError:
        return None
    pids = {int(l.split('","')[1]) for l in out.splitlines() if l.lower().startswith('"coolmessenger.exe')}
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(h, _):
        pid = wintypes.DWORD()
        u.GetWindowThreadProcessId(h, ctypes.byref(pid))
        if pid.value in pids and u.IsWindowVisible(h) and _cls(h) == "#32770" and u.GetDlgItem(h, LIST_ID):
            found.append(h)
        return True
    u.EnumWindows(cb, 0)
    return found[0] if found else None


def chip_texts(win):
    """본문 바로 아래 첨부 줄에 보이는 글자들 (파일 이름 + 크기). 지금 화면에 뜬 메시지가 무엇인지 확인하는 데 씀"""
    body = next((c for c in _children(win) if _cls(c) == "AfxWnd140u" and u.GetParent(c) == win and _rect(c)[3] > 150), None)
    if not body:
        return []
    bx, by, bw, bh = _rect(body)
    for d in _children(win):
        if _cls(d) == "#32770" and u.GetParent(d) == win and u.IsWindowVisible(d):
            x, y, w, h = _rect(d)
            if abs(y - (by + bh)) <= 6 and abs(x - bx) <= 6:
                return [_text(c) for c in _children(d) if _cls(c).startswith("Afx:") and u.IsWindowVisible(c)]
    return []


def showing(win, names):
    """화면의 첨부 줄이 이 이름들과 맞는가. 첨부가 많으면 줄에 일부만 보이므로, '보이는 줄이 모두 이 메시지의 첨부 이름'이면 맞는 것으로 봄"""
    chips = chip_texts(win)
    return bool(chips) and len(chips) <= len(names) and all(any(n in c for n in names) for c in chips)


def _key(h, vk):
    u.PostMessageW(h, WM_KEYDOWN, vk, 0)
    u.PostMessageW(h, WM_KEYUP, vk, 0xC0000001)


def select_row(win, row):
    """목록의 맨 위에서 row 번째 글을 고름 (맨 위가 0). 목록에만 '맨 위로', '아래로' 신호를 보냄"""
    lst = u.GetDlgItem(win, LIST_ID)
    _key(lst, VK_HOME)
    time.sleep(0.25)
    for _ in range(row):
        _key(lst, VK_DOWN)
        time.sleep(0.06)


def press_save(win):
    """'모든파일 저장' 단추를 누름. 번호와 글자가 모두 맞고, 보이고, 켜져 있을 때만"""
    b = u.GetDlgItem(win, SAVE_ID)
    if not b or not u.IsWindowVisible(b) or not u.IsWindowEnabled(b) or not _text(b).startswith(SAVE_TEXT):
        return False
    u.PostMessageW(b, BM_CLICK, 0, 0)
    return True


def row_of(db, key):
    """받은 메시지 목록(최신순)에서 이 글이 몇 번째인지 어림함. 지운 글은 뺌. 어긋날 수 있어 화면의 첨부 이름으로 다시 확인함"""
    con = connect_ro(db)
    try:
        return con.execute("SELECT COUNT(*) FROM tbl_recv WHERE MessageKey > ? AND (DeletedDate IS NULL OR DeletedDate = '')", (key,)).fetchone()[0]
    finally:
        con.close()


def real_db(db):
    """쿨메신저가 실제로 쓰는 기록 파일인가 (시험용·시연용 가짜 DB 면 False)"""
    try:
        home = os.path.normcase(os.path.expandvars(r"%LOCALAPPDATA%\CoolMessenger"))
        return os.path.normcase(os.path.abspath(str(db))).startswith(home + os.sep)
    except (OSError, ValueError):
        return False


def save_attachments(db, key, names, look_only=False):
    """key 번 메시지의 첨부를 쿨메신저가 저장하게 함. 결과: {"ok": bool, "why": 사유}
    why: no_window(메시지 창이 닫힘) / too_far(목록에서 너무 아래) / not_shown(그 글을 화면에 띄우지 못함) / no_button / pressed / looked"""
    if os.name != "nt" or not names or not real_db(db):
        return {"ok": False, "why": "unsupported"}
    win = message_window()
    if not win:
        return {"ok": False, "why": "no_window"}
    if not showing(win, names):   # 이미 그 글이 떠 있으면 목록을 건드리지 않음
        row = row_of(db, key)
        if row > MAX_ROW:
            return {"ok": False, "why": "too_far"}
        hit = False
        for r in (row, row - 1, row + 1):   # 어림이 하나쯤 어긋나는 경우까지만 찾아봄
            if r < 0:
                continue
            select_row(win, r)
            for _ in range(12):   # 화면이 바뀌기를 3초까지 기다림
                time.sleep(0.25)
                if showing(win, names):
                    hit = True
                    break
            if hit:
                break
        if not hit:
            return {"ok": False, "why": "not_shown"}
    if look_only:
        return {"ok": True, "why": "looked"}
    return {"ok": True, "why": "pressed"} if press_save(win) else {"ok": False, "why": "no_button"}


def _try():
    """시험: 최근 메시지 가운데 첨부가 있고 아직 받은 파일 폴더에 없는 것 하나를 골라 저장해 봄. 이름과 내용은 찍지 않음"""
    import pathlib
    from common import Paths
    paths = Paths()
    db = paths.db()
    recv = pathlib.Path.home() / "Documents" / "CoolMessenger Files" / "Received Files"
    have = {f.name.lower() for f in recv.iterdir()} if recv.is_dir() else set()
    con = connect_ro(db)
    rows = con.execute("SELECT MessageKey, FilePath FROM tbl_recv WHERE FilePath IS NOT NULL AND FilePath != '' "
                       "AND (DeletedDate IS NULL OR DeletedDate = '') ORDER BY MessageKey DESC LIMIT 30").fetchall()
    total = con.execute("SELECT COUNT(*), SUM(CASE WHEN DeletedDate IS NULL OR DeletedDate = '' THEN 1 ELSE 0 END) FROM tbl_recv").fetchone()
    con.close()
    win = message_window()
    print("메시지 창:", "열려 있음" if win else "닫혀 있음", "| 창 제목의 숫자:", "".join(ch for ch in _text(win) if ch.isdigit()) if win else "-", "| 기록의 글 수(전체, 안 지운 것):", tuple(total))
    target = next(((k, attachment_names(fp)) for k, fp in rows if not all(n.lower() in have for n in attachment_names(fp))), None)
    if not target:
        return print("저장되지 않은 첨부가 있는 최근 메시지가 없음")
    key, names = target
    print("고른 메시지: %d번 | 첨부 %d개 | 목록에서의 위치(어림): %d번째" % (key, len(names), row_of(db, key)))
    before = set(have)
    r = save_attachments(db, key, names, look_only="--look" in sys.argv)
    chips = chip_texts(win) if win else []
    print("결과:", r, "| 지금 화면의 첨부 줄 수:", len(chips), "| 그중 이 메시지의 첨부 이름과 맞는 줄:", sum(any(n in c for n in names) for c in chips))
    if r["why"] == "pressed":
        for i in range(24):
            time.sleep(0.5)
            now = {f.name.lower() for f in recv.iterdir()}
            got = [n for n in names if n.lower() in now and n.lower() not in before]
            if len(got) == len(names):
                return print("  %.1f초 뒤: 첨부 %d개가 모두 받은 파일 폴더에 생김" % ((i + 1) * 0.5, len(got)))
        now = {f.name.lower() for f in recv.iterdir()}
        print("  12초 뒤: 새로 생긴 첨부 %d개 / %d개 (폴더에 새 파일 %d개)" % (sum(n.lower() in now and n.lower() not in before for n in names), len(names), len(now - before)))


if __name__ == "__main__":
    if "--try" in sys.argv:
        _try()
    else:
        print(__doc__ or "python cm_save.py --try [--look]")
