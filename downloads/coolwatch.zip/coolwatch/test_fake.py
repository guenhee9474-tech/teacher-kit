# test_fake.py - 가짜 DB로 완료 기준을 자동 시험합니다. (실제 DB는 건드리지 않음)
# 사용: python test_fake.py
import json, subprocess, sys, time, urllib.request, pathlib, os

import make_fake_db, inject_fake_message as inj
from common import BASE, read_json, write_json

FAKE = BASE / "fake"
CFG = FAKE / "config.json"
PORT = 8799
results = []


def check(name, ok):
    results.append(ok)
    print(("통과  " if ok else "실패  ") + name)


def api(path, body=None, token=None):
    req = urllib.request.Request(f"http://127.0.0.1:{PORT}{path}", method="POST" if body is not None else "GET",
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"X-CW-Token": token or "", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read() or b"{}")


def inject(mid, title, text):
    subprocess.run([sys.executable, str(BASE / "inject_fake_message.py"), str(mid), title, text],
                   check=True, capture_output=True, env={**os.environ, "PYTHONUTF8": "1"})


def md_text():
    return "".join(p.read_text(encoding="utf-8") for p in (FAKE / "inbox").glob("*.md")) if (FAKE / "inbox").exists() else ""


def wait(cond, sec=15):
    end = time.time() + sec
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.5)
    return False


def main():
    import shutil
    make_fake_db.main()
    # 쿨메신저가 꺼져 있을 때(-wal 없음) 읽기만 해도 폴더에 파일이 생기면 안 됨
    from common import connect_ro
    before = sorted(p.name for p in FAKE.glob("test.udb*"))
    con = connect_ro(make_fake_db.DB)
    n_rows = con.execute("SELECT COUNT(*) FROM tbl_recv").fetchone()[0]
    con.close()
    check("쿨메신저가 꺼진 상태의 DB를 읽어도 -wal/-shm 파일을 만들지 않음",
          n_rows == 3 and sorted(p.name for p in FAKE.glob("test.udb*")) == before and not any(x.endswith(("-wal", "-shm")) for x in before))
    for d in ("data", "inbox"):
        shutil.rmtree(FAKE / d, ignore_errors=True)
    cfg = read_json(CFG)
    cfg["ui_port"] = PORT
    write_json(CFG, cfg)

    import ui_server
    app = ui_server.App(str(CFG))
    srv = ui_server.start(app, PORT)
    env = {**os.environ, "PYTHONUTF8": "1"}
    w = subprocess.Popen([sys.executable, str(BASE / "watcher.py"), "--config", str(CFG)], env=env)
    try:
        check("연동 시작 후 상태가 '연동 중'", wait(lambda: api("/api/state")["status"]["state"] == "watching"))

        t0 = time.time()
        inject(1001, "회의 안내", "10월 20일 15:00 회의가 있습니다. 내일까지 회신 바랍니다.")
        ok = wait(lambda: "회의 안내" in md_text(), 15)
        check(f"가짜 메시지가 15초 안에 md에 기록됨 ({time.time()-t0:.1f}초)", ok)
        check("오늘 목록에 나타남", wait(lambda: any(i["title"] == "회의 안내" for i in api("/api/state")["today"]), 10))
        # ---- 연동 프로그램은 하나만 (둘이 뜨면 같은 메시지가 두 번 기록됨) ----
        w2 = subprocess.Popen([sys.executable, str(BASE / "watcher.py"), "--config", str(CFG)], env=env)
        check("두 번째 연동 프로그램은 스스로 끝남", wait(lambda: w2.poll() is not None, 10))
        inject(1001, "한번만", "23일까지 제출 바랍니다")
        wait(lambda: "한번만" in md_text(), 15); time.sleep(4)
        check("메시지는 한 번만 기록됨", md_text().count("· 한번만") == 1 and sum(i["title"] == "한번만" for i in api("/api/state")["items"]) == 1)
        check("요청사항·기한·일정이 정리됨", all(k in md_text() for k in ("요청사항", "기한", "일정")))

        inject(1005, "비대상", "내일까지 제출하세요")
        inject(1002, "성적 안내", "성적 확인 부탁")
        time.sleep(5)
        check("화이트리스트에 없는 발신자는 기록 안 됨", "비대상" not in md_text())
        check("제외 단어가 있으면 기록 안 됨", "성적 안내" not in md_text())

        tok = "x"
        page = urllib.request.urlopen(f"http://127.0.0.1:{PORT}/").read().decode()
        tok = page.split('const TOKEN = "')[1].split('"')[0]
        check("화면이 든 버전과 서버의 버전이 같음(다르면 창이 스스로 새로 고침)",
              page.split('VER = "')[1].split('"')[0] == api("/api/state")["page_version"])
        found = api("/api/members?q=" + urllib.parse.quote("한서어"))
        check("이름 검색으로 교직원 찾기", len(found) == 1)
        api("/api/whitelist", {"id": found[0]["id"], "on": True}, tok)
        inject(1011, "추가한 사람", "20일까지 제출 바랍니다")
        check("화이트리스트 추가가 재시작 없이 반영됨", wait(lambda: "추가한 사람" in md_text(), 15))
        api("/api/whitelist", {"id": found[0]["id"], "on": False}, tok)
        time.sleep(3)
        inject(1011, "뺀 뒤", "20일까지 제출 바랍니다")
        time.sleep(6)
        check("화이트리스트에서 빼면 재시작 없이 반영됨", "뺀 뒤" not in md_text())

        api("/api/exclude", {"word": "금지어", "on": True}, tok)
        time.sleep(3)
        inject(1001, "제외시험", "금지어 포함 20일까지")
        time.sleep(6)
        check("제외 단어 추가가 반영됨", "제외시험" not in md_text())

        try:
            api("/api/control", {"action": "pause"}, "wrong")
            check("토큰 없는 요청 거부", False)
        except urllib.error.HTTPError as e:
            check("토큰 없는 요청 거부", e.code == 403)

        api("/api/control", {"action": "pause"}, tok)
        check("일시정지 상태 표시", wait(lambda: api("/api/state")["status"]["state"] == "paused", 8))
        inject(1001, "정지중A", "20일까지 제출")
        inject(1002, "정지중B", "21일까지 제출")
        time.sleep(6)
        check("일시정지 중에는 기록하지 않음", "정지중A" not in md_text())
        api("/api/control", {"action": "resume"}, tok)
        check("재개 후 밀린 메시지가 빠짐없이·순서대로 기록",
              wait(lambda: "정지중B" in md_text(), 15) and md_text().index("정지중A") < md_text().index("정지중B"))

        # ---- 내 역할(관련도) / 지난 메시지 불러오기 ----
        api("/api/roles", {"role": "1학년 담임", "on": True}, tok)
        api("/api/roles", {"role": "영어과", "on": True}, tok)
        check("내 역할 저장", api("/api/state")["my_roles"] == ["1학년 담임", "영어과"])
        time.sleep(3)
        inject(1001, "역할시험", "1학년 담임 선생님들께. 20일까지 명단을 제출해 주세요.")
        inject(1002, "전체시험", "전 교직원 연수가 10월 22일 15:00 시청각실에서 있습니다.")
        inject(1001, "남시험", "2학년 담임 선생님들께. 출결 확인 바랍니다.")
        wait(lambda: any(i["title"] == "남시험" for i in api("/api/state")["items"]), 15)   # md가 먼저 써지므로 카드가 생길 때까지
        rel ={i["title"]: i for i in api("/api/state")["items"]}
        check("내 역할에게 온 글은 '나'", rel.get("역할시험", {}).get("rel") == "나")
        check("전체 교사 대상 글은 '전체'", rel.get("전체시험", {}).get("rel") == "전체")
        check("다른 학년 대상 글은 '기타'", rel.get("남시험", {}).get("rel") == "기타")
        check("카드에 기한일·일정일(달력용)이 들어감", rel["역할시험"]["due"].endswith("-20") and rel["전체시험"]["event"].endswith("-10-22"))
        before = len(api("/api/state")["items"])
        api("/api/backfill", {"n": 50}, tok)
        check("지난 메시지 불러오기: 시작 전에 있던 글이 카드로 추가됨",
              wait(lambda: any(i["title"] == "교과 협의회 안내" for i in api("/api/state")["items"]), 15))
        st = api("/api/state")["items"]
        check("불러오기는 중복 카드를 만들지 않음", len({i["key"] for i in st}) == len(st) and len(st) > before)
        check("불러오기에도 제외 단어 적용", not any(i["title"] == "생활기록부 점검" for i in st))
        api("/api/backfill", {"n": 5, "redo": True}, tok)
        time.sleep(8)
        st2 = api("/api/state")["items"]
        check("다시 정리: 카드 수가 그대로이고 중복 없음", len(st2) == len(st) and len({i["key"] for i in st2}) == len(st2))
        check("짧은 제목: 인사말로 시작하지 않음", not any(i["title"].startswith("안녕하세요") for i in st2))

        # ---- 첨부 이름 / 원문 보기 / 처리 상태 / 새 글 표시 ----
        rep = next((i for i in st2 if i["title"] == "현장체험학습 결과 보고"), {"key": 0, "attach": ""})
        check("첨부: 쿨메신저 형식에서 파일 이름만 뽑음", rep["attach"] == "보고서양식.hwpx")
        o = api(f"/api/original?key={rep['key']}", token=tok)
        check("원문 보기: 본문이 나오고 전화번호는 가려짐",
              o.get("found") and "결과보고서" in o["text"] and "[전화번호]" in o["text"] and "010-1234" not in o["text"])
        try:
            api(f"/api/original?key={rep['key']}", token="wrong")
            check("토큰 없이는 원문을 주지 않음", False)
        except urllib.error.HTTPError as e:
            check("토큰 없이는 원문을 주지 않음", e.code == 403)
        status = lambda: {i["key"]: i["status"] for i in api("/api/state")["items"]}.get(rep["key"])
        check("처음 상태는 '미정리'", status() == "미정리")
        api("/api/mark", {"key": rep["key"], "status": "처리완료"}, tok)
        check("완료 표시가 저장됨", status() == "처리완료")
        api("/api/mark", {"key": rep["key"], "status": "미정리"}, tok)
        check("되돌리기", status() == "미정리")
        try:
            api("/api/mark", {"key": rep["key"], "status": "이상한값"}, tok)
            check("모르는 상태는 거부", False)
        except urllib.error.HTTPError as e:
            check("모르는 상태는 거부", e.code == 400)
        # ---- 화면 색 / Claude 모델·노력 고르기 ----
        st0 = api("/api/state")
        check("기본값: 가벼운 모델 + 노력 낮음, 진홍·자동", (st0["summary_model"], st0["summary_effort"], st0["ui_theme"], st0["ui_mode"]) == ("haiku", "low", "crimson", "auto"))
        api("/api/claude", {"model": "sonnet", "effort": "medium"}, tok)
        api("/api/ui", {"theme": "blue", "mode": "dark"}, tok)
        st1 = api("/api/state")
        check("모델·노력·화면 색을 바꾸면 저장됨", (st1["summary_model"], st1["summary_effort"], st1["ui_theme"], st1["ui_mode"]) == ("sonnet", "medium", "blue", "dark"))
        check("새로 연 화면은 처음부터 고른 색", 'data-theme="blue" data-mode="dark"' in urllib.request.urlopen(f"http://127.0.0.1:{PORT}/").read().decode())
        try:
            api("/api/claude", {"model": "아무거나", "effort": "low"}, tok)
            check("모르는 모델은 거부", False)
        except urllib.error.HTTPError as e:
            check("모르는 모델은 거부", e.code == 400)
        api("/api/claude", {"model": "haiku", "effort": "low"}, tok)
        api("/api/ui", {"theme": "crimson", "mode": "auto"}, tok)
        check("오늘 Claude 사용량이 상태에 들어 있음", set(api("/api/state")["usage"]) == {"calls", "tokens", "limit"})

        api("/api/seen", {}, tok)
        check("화면을 보면 '새 글' 수가 0", api("/api/state")["unseen"] == 0)
        inject(1001, "새글표시", "20일까지 제출")
        check("그 뒤에 온 글은 '새 글'로 셈", wait(lambda: api("/api/state")["unseen"] == 1, 15))
        api("/api/seen", {}, tok)
        check("다시 보면 0", api("/api/state")["unseen"] == 0)

        # ---- 노션 연결 끊김 → 복구 (가짜 모드: 실제 노션에는 가지 않음) ----
        c = read_json(CFG); c.update(notion_enabled=True, notion_mode="fake_fail", notion_retry_sec=2); write_json(CFG, c)
        time.sleep(3)
        inject(1001, "노션끊김A", "20일까지 제출")
        inject(1002, "노션끊김B", "21일까지 제출")
        check("노션이 끊겨도 로컬 md에는 기록됨", wait(lambda: "노션끊김B" in md_text(), 15))
        check("끊긴 동안 노션 대기열에 쌓임(2건)", wait(lambda: api("/api/state")["notion_pending"] == 2, 10))
        c["notion_mode"] = "fake"; write_json(CFG, c)
        check("노션이 돌아오면 대기열이 비워짐", wait(lambda: api("/api/state")["notion_pending"] == 0, 15))
        urls = {i["title"]: i["notion_url"] for i in api("/api/state")["today"]}
        check("오늘 목록에 노션 페이지 주소가 붙음", urls.get("노션끊김A", "").startswith("https://") and urls.get("노션끊김B", "").startswith("https://"))
        lg = (FAKE / "data" / "coolwatch.log").read_text(encoding="utf-8")
        keys = [l.split("번 노션 전송 완료")[0].split()[-1] for l in lg.splitlines() if "노션 전송 완료" in l]
        check("밀린 메시지가 번호 순서대로 노션에 전송됨", keys == sorted(keys, key=int) and len(keys) >= 2)
        c["notion_enabled"] = False; write_json(CFG, c)

        # ---- 망이 끊겼다 붙는 상황 (교실 이동): 끊긴 동안에도 이 PC 안에는 정리하고, 연결되면 이어서 ----
        (FAKE / "fake_claude.py").write_text(
            "import json, sys\nsys.stdin.read()\n"
            "body = {'짧은제목': 'CLAUDE정리', '한줄요약': 'S', '요청사항': ['A'], '기한': [], '관련': '기타', '대상': ''}\n"
            "print(json.dumps({'is_error': False, 'result': json.dumps(body, ensure_ascii=True),\n"
            "                  'usage': {'input_tokens': 2, 'cache_creation_input_tokens': 1800, 'output_tokens': 300}}))\n", encoding="utf-8")
        (FAKE / "fakeclaude.cmd").write_text(f'@"{sys.executable}" "%~dp0fake_claude.py" %*\r\n', encoding="ascii")
        c.update(summary_mode="claude", claude_cmd=str(FAKE / "fakeclaude.cmd"), simulate_offline=True,
                 notion_enabled=True, notion_mode="api", notion_database_id="x"); write_json(CFG, c)
        time.sleep(3)
        inject(1001, "끊김시험", "망이 끊긴 동안 도착한 글입니다. 20일까지 자료를 정리해서 제출해 주시기 바랍니다.")
        card = lambda: next((i for i in api("/api/state")["items"] if i["key"] == api("/api/state")["items"][0]["key"]), {})
        check("끊긴 동안 온 글도 바로 카드로(규칙 정리)", wait(lambda: card().get("title") == "끊김시험" and card().get("mode") == "규칙(오프라인)", 15))
        off_key = card().get("key")
        st = api("/api/state")
        check("끊긴 동안 노션은 시도하지 않고 대기", st["notion_pending"] == 1 and "오프라인" in st["status"]["detail"] and st["status"]["state"] == "watching")
        check("연결되면 다시 정리할 글로 적어 둠", "다시 정리할 글 1건" in st["status"]["detail"])
        time.sleep(5)
        lg = (FAKE / "data" / "coolwatch.log").read_text(encoding="utf-8")
        check("끊긴 동안 로그에 실패가 쌓이지 않음(끊김 한 줄만)", f"{off_key}번 노션 전송 실패" not in lg and lg.count("인터넷 끊김") == 1)
        c.update(simulate_offline=False, notion_mode="fake"); write_json(CFG, c)
        by_key = lambda: next((i for i in api("/api/state")["items"] if i["key"] == off_key), {})
        check("다시 연결되면 Claude로 다시 정리됨", wait(lambda: by_key().get("mode") == "Claude" and by_key().get("title") == "CLAUDE정리", 20))
        check("다시 연결되면 밀린 노션 전송도 끝남", wait(lambda: api("/api/state")["notion_pending"] == 0 and by_key().get("notion_url", "").startswith("https://"), 15))
        check("다시 정리할 글이 비워짐", wait(lambda: "다시 정리할 글" not in api("/api/state")["status"]["detail"], 10))
        check("Claude를 부른 횟수가 사용량에 잡힘", api("/api/state")["usage"]["calls"] >= 1)
        lg = (FAKE / "data" / "coolwatch.log").read_text(encoding="utf-8")
        check("로그에 다시 연결됨이 한 줄", lg.count("인터넷 다시 연결됨") == 1)
        c.pop("simulate_offline"); c.update(summary_mode="rules", notion_enabled=False); write_json(CFG, c)
        time.sleep(3)

        subprocess.run([sys.executable, str(BASE / "inject_fake_message.py"), "--benign-error"],
                       capture_output=True, env=env)
        inject(1001, "시작기록뒤", "20일까지 제출")
        check("쿨메신저 시작 기록(LogStart 등)만 붙으면 연동 계속",
              wait(lambda: "시작기록뒤" in md_text(), 15) and api("/api/state")["status"]["state"] == "watching")

        inj_err = subprocess.run([sys.executable, str(BASE / "inject_fake_message.py"), "--touch-error"],
                                 capture_output=True, env=env)
        check("가짜 Error.log 변경 시 오류 상태", wait(lambda: api("/api/state")["status"]["state"] == "error", 10))
        inject(1001, "오류중", "20일까지 제출")
        time.sleep(5)
        check("오류 상태에서는 기록하지 않음", "오류중" not in md_text())
        api("/api/control", {"action": "reset_error"}, tok)
        check("오류 확인 후 다시 시작하면 밀린 메시지 기록",
              wait(lambda: "오류중" in md_text(), 15) and api("/api/state")["status"]["state"] == "watching")

        log = (FAKE / "data" / "coolwatch.log").read_text(encoding="utf-8")
        check("로그에 메시지 내용·제목·발신자 없음", not any(x in log for x in ("회의 안내", "김가나", "정지중A", "회신")))
    finally:
        w.terminate()
        srv.shutdown()
    print(f"\n{sum(results)}/{len(results)} 통과")
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    import urllib.parse, urllib.error
    main()
