# watcher.py - 쿨메신저 DB와 연동해서 새 업무 메시지를 정리합니다.
#   ① inbox/날짜.md 에 기록  ② 화면용 카드(data/items.json)  ③ 노션 '받은 업무함' 전송 대기열
# 화면(트레이·설정 페이지)과 별개 프로세스라서 화면이 꺼져도 계속 돕니다.
# 원칙: 원본 DB는 읽기 전용으로 짧게만 열고, 로그에는 번호와 상태만 남깁니다.
#
# 사용: pythonw watcher.py [--config 경로]        (창 없이)
#       python  watcher.py [--config 경로] --once  (한 번만 처리하고 끝, 시험용)
import os, re, sqlite3, sys, time
from datetime import datetime

from common import Paths, read_json, write_json, log, PHONE, attachment_names, connect_ro, online
import notion_sync
from summarize import summarize, clean_sender

DAYS = "월화수목금토일"
KEEP_ITEMS = 120   # 화면에 보관할 최근 카드 수
COLS = "MessageKey, SenderKey, Sender, Title, MessageText, ReceiveDate, FilePath"
ALIVE = "(DeletedDate IS NULL OR DeletedDate = '')"


def mtime(p):
    try:
        return p.stat().st_mtime
    except OSError:
        return None


def connect(db):
    # 읽기 전용 연결. WAL 모드라 쿨메신저의 쓰기를 막지 않습니다. (쿨메신저가 꺼져 있을 때는 파일을 만들지 않는 방식으로)
    return connect_ro(db)


def query(db, sql, args=()):
    con = connect(db)
    try:
        return con.execute(sql, args).fetchall()
    finally:
        con.close()


def sender_id(sender_key):
    parts = [x for x in (sender_key or "").split("|") if x]
    return parts[-1] if parts else ""


def fetch_new(db, last_key):
    return query(db, f"SELECT {COLS} FROM tbl_recv WHERE MessageKey > ? AND {ALIVE} ORDER BY MessageKey", (last_key,))


def fetch_recent(db, n):
    """가장 최근 n건 (오래된 것부터)"""
    return list(reversed(query(db, f"SELECT {COLS} FROM tbl_recv WHERE {ALIVE} ORDER BY MessageKey DESC LIMIT ?", (n,))))


def fetch_keys(db, keys):
    ph = ",".join("?" * len(keys))
    return query(db, f"SELECT {COLS} FROM tbl_recv WHERE MessageKey IN ({ph}) AND {ALIVE} ORDER BY MessageKey", list(keys))


def max_key(db):
    return query(db, "SELECT IFNULL(MAX(MessageKey), 0) FROM tbl_recv")[0][0]


def received_time(rdate):
    """'2026/10/07 12:52:00 (수)' -> datetime. 실패하면 지금."""
    try:
        return datetime.strptime((rdate or "")[:19], "%Y/%m/%d %H:%M:%S")
    except ValueError:
        return datetime.now()


def wanted(cfg, row):
    """화이트리스트(또는 전체 수신)와 제외 단어를 통과하는가"""
    body = (row[3] or "") + (row[4] or "")
    if not (cfg.get("record_all") or sender_id(row[1]) in cfg["whitelist"]):
        return False
    return not any(w in body for w in cfg["exclude_words"])


def render_md(key, sender, title, when, text, s, keep_original):
    head = title or s["한줄요약"] or "(제목 없음)"
    mark = {"나": " ⭐", "전체": " 📢"}.get(s.get("관련"), "")
    lines = [f"## {when:%H:%M} · {sender or '?'} · {head}{mark}  `#{key}`", ""]
    if s.get("한줄요약") and s["한줄요약"] != head:
        lines += [f"> {s['한줄요약']}", ""]

    def block(label, items):
        if items:
            lines.append(f"- **{label}**: " + (items[0] if len(items) == 1 else ""))
            if len(items) > 1:
                lines.extend(f"  - {i}" for i in items)

    if s.get("대상") or s.get("관련"):
        lines.append(f"- **대상**: {s.get('대상') or '-'} ({s.get('관련') or '기타'})")
    block("요청사항", s.get("요청사항") or ["(요청 없음 — 안내)"])
    block("기한", s.get("기한") or ["(명시 없음)"])
    block("일정", s.get("일정"))
    block("준비물·첨부", s.get("준비물"))
    block("링크", s.get("링크"))
    lines.append(f"- 정리 방식: {s['방식']}")
    if keep_original:
        body = text.replace("\n", "\n> ")
        lines += ["", "<details><summary>원문</summary>", "", f"> {body}", "", "</details>"]
    lines.append("")
    return "\n".join(lines) + "\n"


# 쿨메신저가 시작할 때 늘 적는 가벼운 기록. 이런 줄만 새로 붙었으면 연동을 계속합니다.
BENIGN = re.compile(r"^(LogStart\(\d{8} \d{2}:\d{2}\) - Ver : [\d.]+"
                    r"|\w+\(\d{8} \d{2}:\d{2}\) - CPPSQLITE_ERROR\[1000\] : Null Virtual Machine pointer\(CPPSQLITE_ERROR\))$")


class Watcher:
    def __init__(self, config_path=None):
        self.paths = Paths(config_path)
        self.err_ready = False   # 오류 로그 기준점을 잡았는지
        self.err_mtime = None
        self.err_pos = 0         # 여기까지는 이미 확인한 오류 로그 위치(바이트)
        self.seen = None
        self.last_state = None
        self.cur_db = None
        self.notion_retry_at = 0
        self.notion_note = ""
        self.claude_pause_until = 0   # Claude 요약이 실패하면 이때까지는 규칙으로 정리
        self.net_ok = True            # 인터넷 연결 (바뀔 때만 로그에 적음)
        self.skip_logged = (None, 0)  # 같은 '건너뜀'을 로그에 되풀이해 적지 않게

    # ----- 쿨메신저 오류 로그 (안전장치) -----
    def errlog_mark(self, errlog):
        """지금 오류 로그의 끝을 '확인 끝' 기준점으로 삼음"""
        self.err_mtime = mtime(errlog)
        try:
            self.err_pos = errlog.stat().st_size
        except OSError:
            self.err_pos = 0
        self.err_ready = True

    def errlog_problem(self, errlog):
        """새로 붙은 오류 로그에 낯선 내용이 있으면 사유(문자열), 없으면 None.
        내용은 화면·로그에 옮기지 않고 줄 수만 알립니다."""
        m = mtime(errlog)
        if m == self.err_mtime:
            return None
        try:
            size = errlog.stat().st_size
            if size < self.err_pos:
                return "쿨메신저 오류 로그가 줄어들거나 새로 만들어졌습니다"
            with open(errlog, "rb") as fh:
                utf16 = fh.read(2) == b"\xff\xfe"  # 쿨메신저 오류 로그는 UTF-16(BOM 있음)
                fh.seek(self.err_pos)
                new = fh.read(size - self.err_pos)
        except OSError:
            return "쿨메신저 오류 로그를 읽을 수 없습니다"
        if utf16:
            bom = 2 if self.err_pos == 0 else 0    # 파일 맨 앞의 BOM 2바이트는 건너뜀
            n = (len(new) - bom) // 2 * 2
            text = new[bom:bom + n].decode("utf-16-le", errors="replace")
            end_chars = text.rfind("\n") + 1       # 쓰는 중인 마지막 줄은 다음에 확인
            end = bom + end_chars * 2
            full = end == len(new)
            lines = [l.strip() for l in text[:end_chars].splitlines()]
        else:
            end = new.rfind(b"\n") + 1
            full = end == len(new)
            lines = [l.strip() for l in new[:end].decode("utf-8", errors="replace").splitlines()]
        bad = [l for l in lines if l and not BENIGN.match(l)]
        if bad:
            return f"쿨메신저 오류 로그에 새 오류 {len(bad)}줄이 생겼습니다"
        if full:  # 끝까지 확인했을 때만 기준점 이동
            self.err_mtime = m
        self.err_pos += end
        return None

    # ----- 파일들 -----
    def f(self, name):
        return self.paths.data() / name

    def set_status(self, state, detail="", **extra):
        st = {"state": state, "detail": detail, "updated": time.time(), "pid": os.getpid(), **extra}
        write_json(self.f("status.json"), st)
        if state != self.last_state:
            log(self.paths, f"상태: {state}")
            self.last_state = state

    def control(self):
        return read_json(self.f("control.json"), {}) or {}

    def last_key(self, db):
        d = read_json(self.f("state.json"))
        if d and "last_key" in d and d.get("db") == str(db):
            return d["last_key"]
        # 첫 실행이거나 DB가 바뀜(예: 가짜 → 실제): 과거 메시지는 올리지 않고 지금부터
        k = max_key(db)
        write_json(self.f("state.json"), {"last_key": k, "db": str(db)})
        log(self.paths, f"{'DB 변경' if d else '첫 실행'}: {k}번 이후부터 기록")
        return k

    def items(self):
        """화면용 카드 목록. 로그와 달리 발신자·제목·요약이 들어가며 data/ 안에만 있습니다."""
        d = read_json(self.f("items.json"))
        if d is None:   # 예전 형식(today.json)에서 옮겨오기
            old = (read_json(self.f("today.json"), {}) or {})
            return [{**i, "date": old.get("date", "")} for i in old.get("items", [])]
        return d.get("items", [])

    def save_items(self, items):
        items = sorted(items, key=lambda i: i.get("key", 0))[-KEEP_ITEMS:]
        write_json(self.f("items.json"), {"items": items})

    # ----- Claude 사용량 (data/usage.json: 오늘 부른 횟수와 토큰. 화면에 보여 주고 하루 한도를 지킴) -----
    def usage(self):
        d = read_json(self.f("usage.json"), {}) or {}
        return d if d.get("date") == f"{datetime.now():%Y-%m-%d}" else {"date": f"{datetime.now():%Y-%m-%d}", "calls": 0, "tokens": 0}

    def add_usage(self, cfg, tokens):
        d = self.usage()
        d["calls"] += 1
        d["tokens"] += tokens
        write_json(self.f("usage.json"), d)

    def claude_rest(self, cfg):
        """Claude를 부르지 않고 규칙으로 정리해야 하면 그 까닭(짧은 말), 아니면 None"""
        if cfg.get("summary_mode") != "claude":
            return None
        if not online(cfg, "api.anthropic.com"):
            return "오프라인"
        if time.time() < self.claude_pause_until:
            return "Claude 쉬는 중"
        if self.usage()["calls"] >= cfg.get("claude_daily_limit", 200):
            return "하루 한도"
        return None

    # ----- 기록 -----
    def digest(self, cfg, row):
        """한 건을 읽어 정리 결과를 만듦: (카드, 노션용 항목, md 글)"""
        key, _, sender, title, text, rdate, fpath = row
        text = PHONE.sub("[전화번호]", (text or "").strip())
        title = PHONE.sub("[전화번호]", (title or "").strip())
        sender = clean_sender(sender)
        attach = ", ".join(attachment_names(fpath))
        rest = self.claude_rest(cfg)
        s, fail = summarize({**cfg, "summary_mode": "rules"} if rest else cfg, title, text, rdate or "", attach)
        if rest:
            s["방식"] = f"규칙({rest})"
        if fail or rest in ("오프라인", "Claude 쉬는 중"):   # 일단 규칙으로 보여 주고, 연결되면 Claude로 다시 정리
            self.queue_retry(key)
        tokens = s.pop("_tokens", 0)
        if tokens:
            self.add_usage(cfg, tokens)
        if fail:   # 사용 한도·로그인 풀림 등: 매 글마다 다시 부르지 않고 잠시 쉼
            self.claude_pause_until = time.time() + cfg.get("claude_cooldown_sec", 600)
            log(self.paths, f"{key}번 Claude 요약 실패({fail}) → 규칙으로 대체, {cfg.get('claude_cooldown_sec', 600) // 60}분 쉼")
        when = received_time(rdate)
        keep = cfg.get("keep_original", True)
        head = s.get("짧은제목") or title or s["한줄요약"] or "(제목 없음)"   # 표·카드에서 한눈에 읽히는 제목
        md_name = f"{when:%Y-%m-%d}.md"
        item = {
            "key": key, "date": f"{when:%Y-%m-%d}", "time": f"{when:%H:%M}", "sender": sender,
            "title": head, "summary": s.get("한줄요약", ""),
            "requests": s.get("요청사항") or [], "deadlines": s.get("기한") or [], "schedule": s.get("일정") or [],
            "links": s.get("링크") or [], "attach": attach, "due": s.get("기한일") or "", "event": s.get("일정일") or "",
            "rel": s.get("관련") or "기타", "target": s.get("대상") or "", "mode": s["방식"],
            "file": md_name, "notion_url": ""}
        entry = {"key": key, "sender": sender, "title": head,
                 "when_iso": f"{when:%Y-%m-%dT%H:%M:%S}+09:00", "attach": attach, "summary": s,
                 "original": text if keep else ""}
        return item, entry, (when, render_md(key, sender, head, when, text, s, keep))

    def record(self, cfg, row):
        """한 건을 정리해 md·카드·노션 대기열에 넣음. 이미 기록된 번호면 False."""
        if any(i.get("key") == row[0] for i in self.items()):
            return False   # 번호를 되돌리거나 '최근 불러오기'를 눌렀을 때 중복 방지
        item, entry, (when, md_text) = self.digest(cfg, row)
        if cfg.get("notion_enabled"):
            self.enqueue_notion(entry)
        md = self.paths.inbox(cfg) / item["file"]
        new_file = not md.exists()
        with open(md, "a", encoding="utf-8") as fh:
            if new_file:
                fh.write(f"# {when:%Y-%m-%d} ({DAYS[when.weekday()]}) 받은 업무\n\n")
            fh.write(md_text)
        self.save_items(self.items() + [item])
        return True

    def redo(self, cfg, db, n):
        """최근 n건을 새 방식으로 다시 정리해 카드와 노션 페이지를 덮어씀 (md 기록은 그대로 둠)"""
        rows = [r for r in fetch_recent(db, n) if wanted(cfg, r)]
        log(self.paths, f"최근 {n}건 다시 정리: 대상 {len(rows)}건")
        for i, row in enumerate(rows, 1):
            self.set_status("watching", f"다시 정리하는 중 ({i}/{len(rows)})", last_check=time.time())
            self.redo_row(cfg, row)

    def redo_row(self, cfg, row):
        """한 건을 다시 정리해 카드와 노션 페이지를 덮어씀. 반환: 정리 방식(예: 'Claude', '규칙(오프라인)')"""
        old = next((x for x in self.items() if x.get("key") == row[0]), None)
        if old is None:
            self.record(cfg, row)
            return next((x.get("mode", "") for x in self.items() if x.get("key") == row[0]), "")
        item, entry, _ = self.digest(cfg, row)
        item["notion_url"] = old.get("notion_url", "")
        self.save_items([x for x in self.items() if x.get("key") != row[0]] + [item])
        if not cfg.get("notion_enabled"):
            return item["mode"]
        waiting = [e for e in self.pending() if e["key"] != row[0]]
        try:
            if item["notion_url"] and notion_sync.resolve_mode(cfg) == "api":
                notion_sync.update_api(cfg, entry, item["notion_url"])
                log(self.paths, f"{row[0]}번 노션 페이지 갱신")
            elif not item["notion_url"]:   # 아직 안 올라간 글은 새 내용으로 대기열에
                write_json(self.f("notion_pending.json"), sorted(waiting + [entry], key=lambda e: e["key"]))
            else:   # 이미 올라간 페이지를 덮어쓰는 것은 API 키 방식에서만 가능
                log(self.paths, f"{row[0]}번 노션 페이지 갱신 건너뜀(노션 키 필요)")
        except Exception as e:
            log(self.paths, f"{row[0]}번 노션 갱신 실패({notion_sync.describe(e)})")
        return item["mode"]

    # ----- 끊겼을 때 규칙으로 정리해 둔 글: 연결되면 Claude로 다시 정리 (data/claude_retry.json: 번호 -> 시도 횟수) -----
    def retry_queue(self):
        return read_json(self.f("claude_retry.json"), {}) or {}

    def queue_retry(self, key):
        q = self.retry_queue()
        if str(key) not in q:
            q[str(key)] = 0
            write_json(self.f("claude_retry.json"), q)

    def retry_claude(self, cfg, db):
        q = self.retry_queue()
        if q and cfg.get("summary_mode") != "claude":   # 규칙 방식으로 바꿨으면 다시 정리할 까닭이 없음
            write_json(self.f("claude_retry.json"), {})
            return
        if not q or self.claude_rest(cfg):
            return
        keys = sorted(int(k) for k in q)[:3]   # 한 회차에 3건까지 (새 메시지 확인이 밀리지 않게)
        rows = {r[0]: r for r in fetch_keys(db, keys)}
        for i, key in enumerate(keys, 1):
            row = rows.get(key)
            done = row is None or not wanted(cfg, row)   # 지워졌거나 이제 대상이 아닌 글
            if not done:
                self.set_status("watching", f"밀린 글을 Claude로 다시 정리하는 중 ({len(q)}건 남음)", last_check=time.time())
                done = self.redo_row(cfg, row).startswith("Claude")
                if done:
                    log(self.paths, f"{key}번 다시 정리 완료(Claude)")
            q = self.retry_queue()
            q[str(key)] = q.get(str(key), 0) + 1
            if done or q[str(key)] >= 5:   # 다섯 번 해도 안 되면 그만둠 (화면의 '다시 정리'로 직접 가능)
                q.pop(str(key), None)
            write_json(self.f("claude_retry.json"), q)
            if not done:
                return

    def backfill(self, cfg, db, n):
        """최근 n건을 다시 읽어 아직 카드가 없는 것만 정리 (마지막 처리 번호는 건드리지 않음)"""
        rows = [r for r in fetch_recent(db, n) if wanted(cfg, r)]
        have = {i.get("key") for i in self.items()}
        todo = [r for r in rows if r[0] not in have]
        log(self.paths, f"최근 {n}건 불러오기: 대상 {len(rows)}건 중 새로 정리 {len(todo)}건")
        for i, row in enumerate(todo, 1):
            self.set_status("watching", f"최근 메시지 불러오는 중 ({i}/{len(todo)})", last_check=time.time())
            if self.record(cfg, row):
                log(self.paths, f"{row[0]}번 기록(불러오기)")

    # ----- 노션 대기열 -----
    def pending(self):
        return read_json(self.f("notion_pending.json"), []) or []

    def enqueue_notion(self, entry):
        q = self.pending()
        if not any(e["key"] == entry["key"] for e in q):
            write_json(self.f("notion_pending.json"), sorted(q + [entry], key=lambda e: e["key"]))

    def flush_notion(self, cfg):
        """대기열의 메시지를 번호 순서대로 노션에 올림. 실패하면 남겨 두고 잠시 뒤 다시 시도."""
        if not cfg.get("notion_enabled") or time.time() < self.notion_retry_at:
            return
        mode = notion_sync.resolve_mode(cfg)
        if mode in ("api", "claude") and self.pending() and not online(cfg, "api.notion.com" if mode == "api" else "api.anthropic.com"):
            self.notion_note = "오프라인"   # 끊겨 있으면 시도하지 않고 조용히 기다림 (연결되면 번호 순서대로 올림)
            return
        # claude 연결 방식은 한 건에 20~40초 걸리므로 한 회차에 1건씩 (새 메시지 감지가 밀리지 않게)
        batch = 5 if notion_sync.resolve_mode(cfg) != "claude" else 1
        for _ in range(batch):
            q = self.pending()
            if not q:
                self.notion_note = ""
                return
            entry = q[0]
            try:
                url = notion_sync.push(cfg, entry)
                self.notion_note = ""
            except notion_sync.NoTokenError:
                if not self.notion_note:
                    log(self.paths, "노션 키(NOTION_TOKEN)가 없어 전송을 보류합니다.")
                self.notion_note = "노션 키 필요"
                self.notion_retry_at = time.time() + cfg.get("notion_retry_sec", 60)
                return
            except Exception as e:  # 접속 끊김·시간 초과·응답 형식 오류 등
                log(self.paths, f"{entry['key']}번 노션 전송 실패({notion_sync.describe(e)}) → {len(q)}건 대기")
                self.notion_note = "노션 전송 재시도 중"
                self.notion_retry_at = time.time() + cfg.get("notion_retry_sec", 60)
                return
            write_json(self.f("notion_pending.json"), [e for e in self.pending() if e["key"] != entry["key"]])
            items = self.items()
            for i in items:
                if i.get("key") == entry["key"]:
                    i["notion_url"] = url
            self.save_items(items)
            log(self.paths, f"{entry['key']}번 노션 전송 완료")

    def detail(self, base, cfg):
        rest = self.claude_rest(cfg)
        if rest:
            base += f" · 지금은 규칙으로 정리({rest})"
        waiting = len(self.retry_queue())
        if waiting:
            base += f" · 연결되면 Claude로 다시 정리할 글 {waiting}건"
        n = len(self.pending()) if cfg.get("notion_enabled") else 0
        if not n:
            return base
        return f"{base} · " + (f"{self.notion_note} — " if self.notion_note else "") + f"노션 대기 {n}건"

    # ----- 한 회차 -----
    def tick(self):
        cfg = self.paths.cfg()
        db = self.paths.db(cfg)
        errlog = db.with_name(db.name + "_Error.log")
        wal = db.with_name(db.name + "-wal")
        ctl = self.control()

        if self.cur_db is not None and self.cur_db != db:  # 실행 중에 DB 경로가 바뀜 → 기준점 다시 잡기
            self.err_ready = False
            self.seen = None
        self.cur_db = db
        if not self.err_ready or ctl.get("reset_error"):
            self.errlog_mark(errlog)
            if ctl.get("reset_error"):
                write_json(self.f("control.json"), {**self.control(), "reset_error": False})
                self.seen = None
        # 안전장치: 쿨메신저 오류 로그에 낯선 새 오류가 생기면 멈춤 (원인 확인 후 화면에서 다시 시작)
        problem = self.errlog_problem(errlog)
        if problem:
            self.set_status("error", problem + ". 연동을 멈췄습니다")
            return
        if ctl.get("paused"):
            self.set_status("paused", "일시정지 중")
            return
        try:
            n = int(ctl.get("backfill") or 0)
            if n:
                again = bool(ctl.get("redo"))
                write_json(self.f("control.json"), {**self.control(), "backfill": 0, "redo": False})
                self.last_key(db)   # 첫 실행이면 기준 번호부터 잡아 둠
                (self.redo if again else self.backfill)(cfg, db, min(n, 50))
            stamp = (mtime(wal), mtime(db), tuple(cfg["whitelist"]), tuple(cfg["exclude_words"]), cfg.get("record_all"))
            if stamp != self.seen:
                last = self.last_key(db)
                for row in fetch_new(db, last):
                    key = row[0]
                    self.set_status("watching", "새 메시지 정리 중", last_check=time.time())   # 오래 걸려도 살아 있음을 알림
                    if wanted(cfg, row):
                        log(self.paths, f"{key}번 기록" if self.record(cfg, row) else f"{key}번은 이미 기록되어 건너뜀")
                    else:
                        log(self.paths, f"{key}번 건너뜀")
                    last = key
                    write_json(self.f("state.json"), {"last_key": last, "db": str(db)})
                self.seen = stamp
            self.retry_claude(cfg, db)
            self.flush_notion(cfg)
            uses_net = cfg.get("notion_enabled") or cfg.get("summary_mode") == "claude"
            net = not uses_net or online(cfg, "api.notion.com" if cfg.get("notion_enabled") else "api.anthropic.com")
            if net != self.net_ok:   # 바뀔 때만 한 줄
                log(self.paths, "인터넷 다시 연결됨" if net else "인터넷 끊김: 이 PC 안에는 계속 정리하고, 연결되면 이어서 올립니다")
                self.net_ok = net
            # 쿨메신저가 켜져 있으면 -wal 파일이 있음. 꺼져 있을 때는 새 글이 올 수 없으니 조용히 기다림
            base = "연동 중" if wal.exists() else "쿨메신저가 꺼져 있습니다. 켜지면 이어서 정리합니다"
            self.set_status("watching", self.detail(base + ("" if net else " · 인터넷 끊김"), cfg), last_check=time.time(),
                            messenger=wal.exists(), online=net)
            self.skip_logged = (None, 0)
        except (sqlite3.Error, OSError) as e:
            # 실패하면 번호를 넘기지 않으므로 다음 회차에 같은 메시지부터 다시 시도합니다.
            name = type(e).__name__
            if self.skip_logged[0] != name or time.time() - self.skip_logged[1] > 600:   # 같은 까닭은 10분에 한 번만
                log(self.paths, f"이번 회차 건너뜀: {name}")
                self.skip_logged = (name, time.time())
            self.set_status("watching", f"재시도 대기({type(e).__name__})", last_check=time.time())

    def acquire_lock(self):
        """연동 프로그램은 반드시 하나만. (둘이 뜨면 같은 메시지를 두 번 정리해 노션에 두 줄이 생김)
        운영체제 잠금이라 프로그램이 죽으면 저절로 풀립니다."""
        self._lock = open(self.f("watcher.lock"), "a+")
        try:
            self._lock.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self._lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError:
            self._lock.close()
            return False

    def run(self, once=False):
        if not self.acquire_lock():
            log(self.paths, "이미 다른 연동 프로그램이 돌고 있어 이 프로그램은 끝냅니다")
            return
        log(self.paths, "연동 프로그램 시작")
        while True:
            try:
                self.tick()
            except Exception as e:  # 예상 밖 오류도 프로그램이 죽지 않게
                log(self.paths, f"예상 밖 오류: {type(e).__name__}")
                self.set_status("error", f"예상 밖 오류: {type(e).__name__}")
            if once:
                return
            time.sleep(self.paths.cfg()["poll_sec"])


if __name__ == "__main__":
    args = sys.argv[1:]
    cfg_path = args[args.index("--config") + 1] if "--config" in args else None
    Watcher(cfg_path).run(once="--once" in args)
