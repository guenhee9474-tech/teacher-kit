# app.py - 트레이 아이콘 + 설정 페이지. 연동 프로그램(watcher.py)을 따로 띄우고 상태를 보여줍니다.
# 알림 풍선·소리·팝업은 쓰지 않습니다. 상태는 아이콘 색으로만 보입니다.
#
# 사용: pythonw app.py [--config 경로]     (로그온 때 자동 실행하려면 작업 스케줄러에 이것을 등록)
#       python app.py --no-tray            (pystray 없이 설정 페이지만)
import os, subprocess, sys, threading, time, webbrowser, socket

from common import Paths, BASE, read_json
import ui_server

COLORS = {"watching": (24, 170, 100), "paused": (150, 154, 164), "error": (228, 0, 58), "stopped": (228, 0, 58)}
TITLES = {"watching": "연동 중", "paused": "일시정지", "error": "오류 — 멈춤", "stopped": "연동 꺼짐"}


def ensure_watcher(paths):
    st = ui_server.current_status(paths)
    if st["state"] != "stopped":
        return
    exe = sys.executable
    if os.name == "nt":
        pw = os.path.join(os.path.dirname(exe), "pythonw.exe")
        exe = pw if os.path.exists(pw) else exe
    flags = 0x08000000 | 0x00000008 if os.name == "nt" else 0  # NO_WINDOW | DETACHED
    subprocess.Popen([exe, str(BASE / "watcher.py"), "--config", str(paths.config_path)],
                     cwd=str(BASE), creationflags=flags, close_fds=True)


def stop_watcher(paths):
    st = read_json(paths.data() / "status.json", {}) or {}
    pid = st.get("pid")
    if pid and ui_server.pid_alive(pid):
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True, creationflags=0x08000000)
        else:
            os.kill(int(pid), 15)


PANEL_TITLE = "coolwatch · 받은 업무"   # ui_page.html 의 제목. 전용 창은 이 글자로 끝나는 창 제목을 가짐
EDGE_PATHS = (r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe")


def focus_panel():
    """전용 창이 이미 떠 있으면 앞으로 가져오고 True"""
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def each(hwnd, _):
        n = user32.GetWindowTextLengthW(hwnd)
        if n and user32.IsWindowVisible(hwnd):
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            if buf.value.endswith(PANEL_TITLE):
                found.append(hwnd)
        return True

    user32.EnumWindows(each, 0)
    for hwnd in found[:1]:
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)   # 최소화되어 있으면 되살림
        user32.SetForegroundWindow(hwnd)
    return bool(found)


def open_panel(paths, url):
    """화면 오른쪽 끝에 주소창 없는 좁은 창으로 엶. Edge가 없거나 window_mode 가 browser 면 브라우저 탭으로."""
    cfg = paths.cfg()
    edge = next((p for p in map(os.path.expandvars, EDGE_PATHS) if os.path.exists(p)), None)
    if os.name != "nt" or cfg.get("window_mode", "panel") != "panel" or not edge:
        webbrowser.open(url)
        return
    if focus_panel():
        return
    import ctypes
    from ctypes import wintypes
    area = wintypes.RECT()
    ctypes.windll.user32.SystemParametersInfoW(0x30, 0, ctypes.byref(area), 0)   # 작업표시줄을 뺀 화면 영역
    w = max(360, min(int(cfg.get("panel_width", 440)), area.right - area.left))
    # 전용 프로필을 써야 크기·위치가 지켜지고, 한 번 옮겨 두면 그 자리를 기억함
    subprocess.Popen([edge, f"--app={url}", f"--user-data-dir={paths.data(cfg) / 'edge_panel'}",
                      f"--window-size={w},{area.bottom - area.top}", f"--window-position={area.right - w},{area.top}",
                      "--no-first-run", "--no-default-browser-check"],
                     creationflags=0x00000008, close_fds=True)

    def bring():   # 가끔 최소화된 채로 뜨는 일이 있어, 뜨면 한 번 앞으로 가져옴
        for _ in range(16):
            time.sleep(0.5)
            if focus_panel():
                return
    threading.Thread(target=bring).start()


def port_free(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def main():
    args = sys.argv[1:]
    cfg_path = args[args.index("--config") + 1] if "--config" in args else None
    paths = Paths(cfg_path)
    port = paths.cfg()["ui_port"]
    url = f"http://127.0.0.1:{port}/"

    if not port_free(port):  # 이미 실행 중이면 화면만 엽니다
        open_panel(paths, url)
        return

    app = ui_server.App(cfg_path)
    ui_server.start(app, port)
    ensure_watcher(paths)
    if not paths.cfg().get("setup_done") and "--no-tray" not in args:   # 처음 켰을 때는 '처음 설정'이 보이게 창을 엶
        open_panel(paths, url)

    if "--no-tray" in args:
        open_panel(paths, url)
        while True:
            time.sleep(60)

    import pystray
    from PIL import Image, ImageDraw

    def icon_image(state, dot=False):
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse((6, 6, 58, 58), fill=COLORS.get(state, COLORS["stopped"]) + (255,))
        if state == "paused":  # 일시정지는 막대 두 개
            d.rectangle((22, 20, 28, 44), fill="white")
            d.rectangle((36, 20, 42, 44), fill="white")
        elif state in ("error", "stopped"):
            d.rectangle((29, 16, 35, 36), fill="white")
            d.ellipse((28, 40, 36, 48), fill="white")
        if dot:  # 아직 안 본 새 글이 있음: 오른쪽 위에 주황 점 (화면을 열면 사라짐)
            d.ellipse((34, 0, 64, 30), fill="white")
            d.ellipse((38, 4, 60, 26), fill=(245, 140, 20, 255))
        return img

    def unseen():
        try:
            return app.unseen() if paths.cfg().get("tray_dot", True) else 0
        except Exception:
            return 0

    cur = {"state": None, "quitting": False, "revived": time.time() + 30}

    def state():
        return ui_server.current_status(paths)["state"]

    def toggle_pause(icon, item):
        s = state()
        if s == "paused":
            app.set_control(paused=False)
        elif s == "error":
            app.set_control(reset_error=True, paused=False)
        else:
            app.set_control(paused=True)

    def open_ui(icon=None, item=None):
        open_panel(paths, url)

    def open_inbox(icon, item):
        os.startfile(str(paths.inbox()))

    def open_notion(icon, item):
        webbrowser.open(paths.cfg()["notion_url"])

    def quit_ui(icon, item):
        icon.stop()

    def quit_all(icon, item):
        cur["quitting"] = True
        stop_watcher(paths)
        icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem(lambda item: TITLES.get(state(), ""), None, enabled=False),
        pystray.MenuItem("받은 업무 열기", open_ui, default=True),
        pystray.MenuItem(lambda item: {"paused": "다시 시작", "error": "오류 확인 · 다시 시작"}.get(state(), "일시정지"),
                         toggle_pause),
        pystray.MenuItem("정리 폴더 열기", open_inbox),
        pystray.MenuItem("노션 받은 업무함 열기", open_notion, visible=lambda item: bool(paths.cfg().get("notion_url"))),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("화면만 끄기 (연동은 계속)", quit_ui),
        pystray.MenuItem("연동까지 끄기", quit_all),
    )
    icon = pystray.Icon("coolwatch", icon_image("stopped"), "coolwatch", menu)

    def updater():
        while True:
            s = state()
            if s == "stopped" and not cur["quitting"] and time.time() - cur["revived"] > 60:
                cur["revived"] = time.time()
                ensure_watcher(paths)   # 연동 프로그램이 죽었으면 조용히 다시 띄움
            n = unseen()
            if (s, n) != cur["state"]:
                cur["state"] = (s, n)
                icon.icon = icon_image(s, dot=n > 0)
                icon.title = f"coolwatch · {TITLES.get(s, s)}" + (f" · 새 글 {n}건" if n else "")
                icon.update_menu()
            time.sleep(2)

    def setup(icon):
        icon.visible = True
        threading.Thread(target=updater, daemon=True).start()

    icon.run(setup)


if __name__ == "__main__":
    main()
