# make_fake_db.py - 시험용 가짜 쿨메신저 DB를 fake/ 에 만듭니다. (실제 DB와 같은 모양, 내용은 전부 가짜)
# 사용: python make_fake_db.py
import pathlib, sqlite3, json
from datetime import datetime, timedelta

BASE = pathlib.Path(__file__).resolve().parent
FAKE = BASE / "fake"
DB = FAKE / "test.udb"

NAMES = ["김가나", "이다라", "박마바", "최사아", "정자차", "강카타", "조파하", "윤거너", "장더러", "임머버",
         "한서어", "오저처", "서커터", "신퍼허", "권고노", "황도로", "안모보", "송소오", "류조초", "홍코토"]

SCHEMA = """
CREATE TABLE tbl_recv (
  MessageKey INTEGER PRIMARY KEY AUTOINCREMENT,
  SenderKey TEXT, Sender TEXT, Title TEXT, MessageText TEXT, MessageBody TEXT,
  ReceiveDate DATE, FilePath TEXT, LinkURL TEXT, IsUnRead INTEGER DEFAULT 1,
  MessageType INTEGER, MessageCategory INTEGER, DeletedDate TEXT,
  CoolFile2SessionID TEXT, ReferenceList TEXT, CCList TEXT, FileHost TEXT,
  MemoID TEXT, IsChecked INTEGER DEFAULT 0, IsMoved INTEGER DEFAULT 0
);
CREATE TABLE tbl_member (K_MemberID INTEGER, MemberID TEXT, MemberName TEXT);
CREATE TABLE tbl_send (MessageKey INTEGER PRIMARY KEY AUTOINCREMENT, ScheduledDate TEXT);
"""

DAYS = "월화수목금토일"


def fmt(dt):
    return dt.strftime("%Y/%m/%d %H:%M:%S") + f" ({DAYS[dt.weekday()]})"


def add_message(con, member_id, sender, title, text, when=None, fpath=""):
    when = when or datetime.now()
    con.execute(
        """INSERT INTO tbl_recv (SenderKey, Sender, Title, MessageText, ReceiveDate, FilePath, MessageType, MessageCategory)
           VALUES (?,?,?,?,?,?,0,0)""",
        (f"|1|{member_id}|", sender, title, "\r\n" + text, fmt(when), fpath),
    )


def main():
    FAKE.mkdir(exist_ok=True)
    for suffix in ("", "-wal", "-shm"):
        p = pathlib.Path(str(DB) + suffix)
        if p.exists():
            p.unlink()
    con = sqlite3.connect(DB)
    con.execute("PRAGMA journal_mode=wal")
    con.executescript(SCHEMA)
    for i, n in enumerate(NAMES):
        con.execute("INSERT INTO tbl_member VALUES (?,?,?)", (1001 + i, f"user{1001 + i}", n))
    now = datetime.now()
    add_message(con, 1001, NAMES[0], "교과 협의회 안내",
                "10월 15일(수) 14:30 교과 협의회가 있습니다. 회의록 양식을 작성하여 10월 14일까지 회신 바랍니다.",
                now - timedelta(hours=3))
    add_message(con, 1002, NAMES[1], "현장체험학습 결과 보고",
                "결과보고서를 내일까지 제출해 주세요. 연락처 010-1234-5678", now - timedelta(hours=2),
                r"|1|2048;2048|C:\fake\보낸사람폴더|보고서양식.hwpx|1|")   # 실제 쿨메신저의 첨부 칸 모양
    add_message(con, 1003, NAMES[2], "생활기록부 점검",
                "생활기록부 점검 자료를 확인해 주세요.", now - timedelta(hours=1))
    con.commit()
    con.close()
    # 가짜 Error.log (수정 시각이 바뀌면 연동이 멈추는지 시험용)
    # 실제 로그처럼 UTF-16(BOM 있음)
    (FAKE / "test.udb_Error.log").write_bytes(
        "LogStart(20261007 09:00) - Ver : 5.75.80.1\r\n".encode("utf-16"))
    # 시험용 설정: 경로를 fake/ 안으로 가둡니다.
    cfg = {"db_path": "test.udb", "whitelist": ["1001", "1002", "1003"], "data_dir": "data",
           "inbox_dir": "inbox", "poll_sec": 2, "summary_mode": "rules"}
    (FAKE / "config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"가짜 DB를 만들었습니다: {DB}")


if __name__ == "__main__":
    main()
