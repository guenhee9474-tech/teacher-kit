@echo off
rem coolwatch installer (local): just double-click this file (no administrator rights needed)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install.ps1" -Mode local
echo.
pause
