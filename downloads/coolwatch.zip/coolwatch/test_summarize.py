# test_summarize.py - 규칙 요약 시험 (가짜 문장만 사용. 실제 메시지 내용은 넣지 않음)
from summarize import summarize_rules, clean_sender

R = "2026/10/07 10:43:25 (수)"
fails = []


def check(name, ok):
    print(("통과  " if ok else "실패  ") + name)
    if not ok:
        fails.append(name)


# 1) '오늘 중' = 기한, 인사말은 요청사항이 아님
s = summarize_rules("", "OO 선생님 안녕하세요?\r\n\r\n연수 시간을 오늘 중 쪽지로 보내주시면 감사드리겠습니다~!", R, "")
check("'오늘 중'이 기한으로 분류", s["기한"] and "오늘" in s["기한"][0] and not s["일정"])
check("요청사항에 '보내주시면' 문장", any("보내" in x for x in s["요청사항"]))

# 2) 인용된 이전 메시지는 제외하고 새 내용만
q = ("의무가 아니니 들으셨다면 알려주시면 됩니다.\r\n올해부터 ~ 10월 말까지입니다.\r\n\r\n"
     "홍길동 ☏111님이 보낸글 >>2026/10/07 10:43:27 (수)\r\n이전 메시지입니다. 내일 14:00까지 제출해 주세요.")
s = summarize_rules("", q, R, "")
check("인용 아래(내일 14:00)는 무시", not any("내일" in x for x in s["기한"] + s["일정"]))
check("'10월 말'이 기한", any("10월 말" in x for x in s["기한"]))
check("방식에 '인용 제외' 표시", "인용 제외" in s["방식"])

# 3) 링크 추출, 링크는 요청 문장에 섞이지 않음
s = summarize_rules("", "미이수 연수를 확인해 주세요.\r\n이수현황:\r\nhttps://example.com/a?x=1&y=2\r\n\r\n연수원:\r\nhttps://example.org/b", R, "")
check("링크 2개 추출", s["링크"] == ["https://example.com/a?x=1&y=2", "https://example.org/b"])
check("요청사항에 URL이 섞이지 않음", not any("http" in x for x in s["요청사항"]))

# 4) 인사·덕담은 요청사항 제외 (강한 요청이 없을 때도)
s = summarize_rules("", "안녕하세요 샘들\r\n검토가 완료되었습니다.\r\n출력 후 직접 도장 부탁드려요\r\n점심 맛있게 드시고 10월에도 잘 부탁드립니다", R, "")
check("덕담('잘 부탁드립니다')은 제외", not any("잘 부탁" in x for x in s["요청사항"]))
check("실제 부탁('도장')은 포함", any("도장" in x for x in s["요청사항"]))

# 5) 기존 동작 유지
s = summarize_rules("", "10월 15일(수) 14:30 협의회가 있습니다. 회의록을 10월 14일까지 회신 바랍니다.", R, "")
check("일정/기한 구분 유지", any("15일" in x for x in s["일정"]) and any("14일" in x for x in s["기한"]))
s = summarize_rules("", "내일까지 제출", R, "")
check("'내일까지'는 실제 날짜로 환산", s["기한"] and "10월 8일" in s["기한"][0])

# 6) 발신자 정리
check("발신자 내선번호 제거", clean_sender("홍길동 ☏323(홍길동)") == "홍길동" and clean_sender("A ☏358,346(A)") == "A")

# 6-2) 요청 없는 안내문: 인사말이 요청사항으로 잡히면 안 됨
s = summarize_rules("", "안녕하세요\r\n\r\n10/8(목) 수업 변동 안내드립니다.\r\n\r\n사유: OO 선생님 지참(10/7)", R, "")
check("안내문의 요청사항이 인사말이 아님", s["요청사항"] and "안녕하세요" not in s["요청사항"][0])
check("안내문 일정 추출", any("10/8" in x for x in s["일정"]))

# 7) 빈/짧은 본문에서 오류 없음
s = summarize_rules("TEST", "TEST-1", R, "")
check("짧은 본문 처리", s["요청사항"] == ["TEST-1"])
# 8) Claude 호출: 모델·노력 옵션, 토큰 집계, 오류 응답 (가짜 claude 프로그램으로. 실제 Claude는 부르지 않음)
import json, os, pathlib, sys, tempfile
from summarize import summarize, claude_args

a = claude_args({})
check("기본값은 가벼운 모델 + 노력 낮음", a[a.index("--model") + 1] == "haiku" and a[a.index("--effort") + 1] == "low")
a = claude_args({"claude_model": "sonnet; rm -rf", "claude_effort": "엄청"})
check("이상한 값은 기본값으로", a[a.index("--model") + 1] == "haiku" and a[a.index("--effort") + 1] == "low")
check("토큰을 아끼는 옵션(전용 안내문, 도구·연결 끔)", all(x in a for x in ("--system-prompt", "--strict-mcp-config", "--disable-slash-commands")))
with tempfile.TemporaryDirectory() as tmp:
    tmp = pathlib.Path(tmp)
    (tmp / "fake_claude.py").write_text(
        "import json, os, sys\n"
        "sys.stdin.read()\n"
        "json.dump(sys.argv[1:], open(os.path.join(os.path.dirname(__file__), 'args.json'), 'w'))\n"
        "bad = os.environ.get('FAKE_CLAUDE_ERROR')\n"
        "body = {'짧은제목': 'T', '한줄요약': 'S', '요청사항': ['A'], '기한': ['10/9(금)까지 · X'], '기한일': '2026-10-09', '관련': '전체', '대상': 'D'}\n"
        "print(json.dumps({'is_error': bool(bad), 'result': '```json\\n' + json.dumps(body, ensure_ascii=True) + '\\n```',\n"
        "                  'usage': {'input_tokens': 2, 'cache_creation_input_tokens': 1800, 'cache_read_input_tokens': 0, 'output_tokens': 300}}))\n",
        encoding="utf-8")
    (tmp / "fakeclaude.cmd").write_text(f'@"{sys.executable}" "%~dp0fake_claude.py" %*\r\n', encoding="ascii")
    cfg = {"summary_mode": "claude", "claude_cmd": str(tmp / "fakeclaude.cmd"), "claude_model": "sonnet", "claude_effort": "medium"}
    long_text = "OO 선생님들께 안내드립니다. 내일까지 회의록을 작성해서 회신해 주시기 바랍니다."
    s, fail = summarize(cfg, "", long_text, R, "")
    args = json.loads((tmp / "args.json").read_text()) if (tmp / "args.json").exists() else []
    check("Claude 응답을 정리 결과로 받음", fail is None and s["방식"] == "Claude" and s["짧은제목"] == "T" and s["기한일"] == "2026-10-09")
    check("고른 모델·노력이 그대로 전달됨", "--model" in args and args[args.index("--model") + 1] == "sonnet" and args[args.index("--effort") + 1] == "medium")
    check("쓴 토큰을 합산", s.get("_tokens") == 2102)
    (tmp / "args.json").unlink(missing_ok=True)
    s, fail = summarize(cfg, "", "네 알겠습니다", R, "")
    check("짧은 글은 Claude를 부르지 않음", s["방식"] == "규칙(짧은 글)" and not (tmp / "args.json").exists())
    os.environ["FAKE_CLAUDE_ERROR"] = "1"
    s, fail = summarize(cfg, "", long_text, R, "")
    del os.environ["FAKE_CLAUDE_ERROR"]
    check("Claude가 오류(사용 한도 등)면 규칙으로 대체", fail and s["방식"] == "규칙(Claude 실패 대체)" and s["요청사항"])

print(f"\n{'모두 통과' if not fails else '실패 ' + str(len(fails)) + '건'}")
raise SystemExit(1 if fails else 0)
