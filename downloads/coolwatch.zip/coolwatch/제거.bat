@echo off
rem coolwatch uninstaller: stops the program and removes autostart/shortcuts. Your records (data, inbox) are kept.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install.ps1" -Uninstall
echo.
pause
