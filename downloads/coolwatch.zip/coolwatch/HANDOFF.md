# coolwatch 핸드오프 (2026-10-07)

## 목표

쿨메신저로 업무 메시지가 오면 즉시 노션 '받은 업무함' DB에 기록한다. 교사는 정신없는 팝업을 꺼 두었고, 노션 받은 업무함을 "조용한 알림창"으로 쓰려 한다. 답장 자동화는 하지 않는다. 할 일·일정 정리는 나중에 노션 쪽에서 Claude Routines로 한다(이번 범위 아님).

이번 작업은 지금의 명령줄 스크립트(`coolwatch.py` v0.1)를 **쓰기 편한 인터페이스가 있는 도구**로 만드는 것이다.

## 직접 확인된 사실

교사가 PC에서 직접 실행해 확인한 내용이다. 다시 확인하려고 실제 DB를 열지 말 것.

**파일**
- 위치: `C:\Users\user\AppData\Local\CoolMessenger\Memo\`
- `<이름>.udb` (약 287MB, SQLite 3), `-wal`, `-shm`, `<이름>.udb_Error.log` (마지막 수정 2026-08-19)
- `PRAGMA journal_mode` = `wal`
- 새 메시지를 받으면 `-wal`의 수정 시각과 크기만 바뀌고, 본 파일은 바뀌지 않는다. 감시 신호는 `-wal` 수정 시각.
- 287MB라 매번 복사하는 방식은 쓰지 않는다. 읽기 전용 URI 연결로 원본을 직접 짧게 조회하는 방식이 동작함을 확인했다.

**스키마 (쓰는 테이블만)**

`tbl_recv` (받은 메시지)
- `MessageKey INTEGER` 자동 증가(`sqlite_sequence` 존재). "마지막 처리 번호보다 큰 것"으로 새 메시지를 가린다.
- `SenderKey TEXT` 예: `|1|1234|` → 마지막 숫자가 발신자 ID
- `Sender TEXT`, `Title TEXT`
- `MessageText TEXT` 사람이 읽을 수 있는 본문. 앞에 `\r\n`이 붙어 있다.
- `MessageBody TEXT` `{COMP}` + base64(zlib) 압축 서식 데이터. 쓰지 않는다.
- `ReceiveDate DATE` 형식: `2026/10/07 12:52:00 (수)` (한국 시간)
- `FilePath`, `LinkURL`, `IsUnRead`, `MessageType`, `MessageCategory`, `DeletedDate` 등
- 그 밖의 열: `CoolFile2SessionID, ReferenceList, CCList, FileHost, MemoID, IsChecked, IsMoved`

`tbl_member` (교직원 210명): `K_MemberID INTEGER, MemberID TEXT, MemberName TEXT`
- `SenderKey`의 ID가 `K_MemberID`와 `MemberID` 중 어느 쪽과 맞는지는 **아직 미확인**. `coolwatch.py --find 이름`으로 교사가 확인할 예정.

`tbl_send`(보낸 메시지, `ScheduledDate` 있음), `tbl_dbInfo`, `tbl_autotext`, `tbl_alarm`, `sqlite_stat1`도 있으나 쓰지 않는다.

**자기 테스트 결과**: 나에게 보낸 예약 메시지가 `tbl_recv`에 들어온다(`MessageType=5, MessageCategory=0, SenderKey='|1|1234|'`). 실제 동료 메시지의 Type/Category 값은 아직 모른다.

## 현재 코드: coolwatch.py v0.1

- 15초마다 `-wal`과 본 파일의 수정 시각을 보고, 바뀌었으면 새 메시지를 조회한다.
- 화이트리스트 발신자만 기록하고, 제외 단어가 있으면 건너뛰며, 휴대폰 번호는 가린다.
- 노션 API(`2022-06-28`, `urllib`)로 페이지를 만든다. 속성: 제목(title), 발신자(text), 받은시각(date), 상태(select, "미정리"), 메시지키(number), 첨부(text). 본문은 블록으로.
- 실패하면 번호를 넘기지 않아 다음 회차에 다시 시도한다.
- 첫 실행 때 현재 최대 번호부터 시작한다(과거 메시지를 올리지 않음).
- `--find 이름`(발신자 ID 찾기), `--test`(노션 연결 시험) 기능이 있다.
- 설정은 파일 맨 위 상수다. → 이번에 설정 파일로 분리한다.

## 이번 작업: 인터페이스

### 교사가 원하는 것
1. **조용함**: 팝업, 소리, 토스트 알림 없음. 이게 이 도구의 존재 이유다.
2. **한눈에 상태 확인**: 지금 감시 중인지, 멈췄는지, 오류인지.
3. **화이트리스트를 이름으로 관리**: ID를 외우지 않고, 교직원 명단에서 이름을 검색해 체크한다.
4. **제외 단어 편집**: 목록에 추가하고 삭제한다.
5. **오늘 기록된 항목 보기**: 시각, 발신자, 제목, 노션 페이지 바로가기.
6. **일시정지와 재개**, 노션 받은 업무함 바로 열기.
7. 로그온할 때 자동 실행.

### 권장 구성 (확인 후 Claude가 최종 결정)
- 작업표시줄 트레이 아이콘(예: `pystray` + `Pillow`)과 클릭하면 열리는 로컬 설정 페이지(`127.0.0.1`에서만 접속, 가능하면 표준 라이브러리 `http.server`).
  - 아이콘 색으로 상태를 표시한다(감시 중 / 일시정지 / 오류).
- pip 설치가 막혀 있으면 표준 라이브러리 `tkinter` 창 하나로 대체한다.
- 먼저 `pip install`이 되는지 확인하고, 두 안 중 하나를 교사에게 짧게 제안한 뒤 진행할 것.

### 구조 정리
- `config.json`: DB 경로, 화이트리스트, 제외 단어, 노션 DB ID, 감시 주기. UI에서 편집한다. 키는 넣지 않는다.
- 감시 로직(`watcher`)과 UI를 분리한다. UI가 꺼져도 감시는 계속 돌 수 있게.
- 실행 중 생기는 데이터(상태 번호, 오늘 기록 목록, 로그)는 `data/`에 둔다.
  - 오늘 기록 목록에는 노션 응답의 페이지 URL을 저장한다(v0.1은 응답을 버리고 있음).
- 화이트리스트에는 ID를 저장하되, UI에는 `tbl_member`에서 읽은 이름으로 보여 준다. 실행 중에 읽는 것이므로 Claude가 명단 내용을 볼 필요는 없다.

### 개발 방식 (필수)
- `make_fake_db.py`: 위 스키마와 같은 가짜 DB(WAL 모드, 가짜 교직원 20명, 가짜 메시지 몇 개)를 `fake/`에 만든다.
- `inject_fake_message.py`: 가짜 DB에 메시지를 한 건 추가한다. 실시간 감지 시험용.
- 가짜 `Error.log`의 수정 시각을 바꿔 중단 장치도 시험한다.
- 노션 시험은 교사에게 별도의 시험용 DB를 만들어 달라고 요청한다.

### 완료 기준
- [ ] 가짜 DB에 메시지를 넣으면 15초 안에 노션 시험 DB에 기록되고, 오늘 목록에 나타난다
- [ ] 화이트리스트에 없는 발신자, 제외 단어가 있는 메시지는 기록되지 않는다
- [ ] 이름 검색으로 화이트리스트를 추가하거나 빼면 다시 시작하지 않아도 반영된다
- [ ] 일시정지 중에 온 메시지는 재개 후 빠짐없이 기록된다
- [ ] 노션 접속이 끊겼다가 돌아오면 밀린 메시지를 순서대로 기록한다
- [ ] 가짜 Error.log를 바꾸면 멈추고, 아이콘과 화면에 오류가 보인다
- [ ] 로그와 화면 어디에도 팝업·소리가 없다
- [ ] 로그온 자동 실행 방법(작업 스케줄러)을 교사가 따라 할 수 있게 안내한다
- [ ] 실제 DB로 바꾸는 방법(config.json의 경로 한 줄)을 교사에게 안내한다. 직접 바꾸지 않는다.

## 나중 단계 (이번 범위 아님)
- 노션 받은 업무함 → 할 일·일정 정리 (Claude Routines + 노션 커넥터)
- 첨부 HWPX에서 마감일 추출
- PyInstaller로 exe 만들기

## 진행 기록 (2026-10-07, 2차)
- 교사 결정: 노션은 보류, 출력은 `inbox/날짜.md`. 요청사항·기한·일정 정리를 자동화. 요약 봇(`claude -p`)이 메시지를 읽는 것은 허용(스위치 방식). 개발 세션의 실제 메시지 열람 금지는 유지(CLAUDE.md 갱신).
- 구현: `common.py, watcher.py, summarize.py, ui_server.py, ui_page.html, app.py, make_fake_db.py, inject_fake_message.py, test_fake.py, config.json, 사용안내.md`. `test_fake.py` 18/18 통과.
- 미검증: ① `claude -p --tools ""` 옵션(이 PC에 claude CLI 없음) ② 실제 트레이 아이콘 모양·설정 페이지의 브라우저 표시 ③ `SenderKey` ID가 K_MemberID/MemberID 중 어느 쪽인지(`member_id_column`) ④ 실제 쿨메신저 메시지의 Type/Category.
- `coolwatch.py`(v0.1, 노션 전송)는 참고용으로 남김. 노션 연동은 나중에 watcher의 `record()`에 추가.

## 진행 기록 (2026-10-07, 3차)
- 규칙 완화(교사): 개발 세션도 실제 DB를 읽기 전용으로 확인 가능. CLAUDE.md 갱신.
- 확인된 사실: 실제 `Error.log`는 **UTF-16(BOM)**, 쿨메신저 시작 때만 `LogStart`/`Null Virtual Machine pointer` 줄이 붙음(로그아웃은 안 바뀜). `SenderKey`의 ID는 **K_MemberID**와 163/163 일치(`MemberID` 열은 이름). MessageType 0/5/28, Category 0/NULL.
- 변경: 오류 로그 판단을 '수정 시각'에서 '새로 붙은 줄이 낯선 오류인가'로 변경(방식 A). DB 경로가 바뀌면 last_key 재설정. `test_fake.py` 19/19.
- `config.json`의 `db_path`를 실제 DB로 전환함. 화이트리스트는 비어 있음(교사가 설정 페이지에서 선택).
- 남은 것: Claude 요약(`claude` CLI 설치 필요) 시험, 실제 동료 메시지로 규칙 요약 품질 점검, 로그온 자동 실행 등록.

## 진행 기록 (2026-10-07, 4차)
- 실제 메시지 5건으로 규칙 요약 점검 → 개선(인용 제외, '오늘 중' 등 기한, '10월 말', 링크, 인사말 제외, 발신자 내선번호 제거). `test_summarize.py` 13/13.
- 방향: 최종적으로 Claude 요약이 본체, 규칙은 대체 수단. 노션은 이 결과를 입력으로 나중에 추가.
- Claude CLI 설치: `npm install -g @anthropic-ai/claude-code` 후 네이티브 패키지가 빠져 `claude-code-win32-x64@2.1.292`를 따로 설치하고 `node install.cjs` 재실행(학교 네트워크가 느려 9분 소요). 이미 claude.ai 로그인됨.
- `summarize.py`: `shutil.which`로 claude 경로 해결(Windows .cmd), `--no-session-persistence` 추가. 가짜 메시지 Claude 요약 시험 통과.
- 미반영: 앱 재시작(전체 수신 `record_all`, 개선된 요약 적용)과 `summary_mode: claude` 전환은 교사가 한다.

## 진행 기록 (2026-10-07, 5차) - 노션 연결
- 노션에 '받은 업무함' DB 생성(DB (지움), data source (지움)). config.json에 연결, notion_enabled=true.
- `notion_sync.py`: API 방식(NOTION_TOKEN) 기본. 가짜 서버로 요청 모양 시험(`test_notion_api.py`). 실제 노션으로는 키가 없어 미시험.
- claude -p의 노션 MCP 방식은 6회 중 1회만 성공(모델이 도구를 안 부르고 가짜 URL을 지어냄) → 자동 선택 제외, tool_result 검증 추가.
- watcher: 노션 대기열(data/notion_pending.json), 실패/키 없음이면 보관 후 재시도, 번호 순서 보장, 중복 방지. `test_fake.py` 24/24.
- 교사 할 일: `python notion_setup.py`로 키 설정 → 앱 재시작. 노션의 [시험] 페이지 2개 삭제.

## 진행 기록 (2026-10-07, 6차) - 최종 정리
- 화면 전면 개편(`ui_page.html`): 상태·숫자 타일·카드 목록(관련도 띠)·다가오는 기한/일정·설정 접이식. 가짜 데이터로 Edge 헤드리스 캡처해 확인.
- 관련도(`relevance.py` + Claude): config `my_roles`, `my_name`(DB 파일명에서 자동) → 나/전체/기타. 노션 속성 `관련`, `대상` 추가.
- 달력: 요약에 `기한일`, `일정일`(ISO) 추가(월 없는 '20일까지', '내일', '10월 말' 등 해석). 노션 `일정일` 속성 + 보기(기한 캘린더, 일정 캘린더, 상태 보드, 미정리, 나와 관련).
- 노션: 교사가 NOTION_TOKEN 설정함 → API 방식 실전 확인(0.7초). 키는 레지스트리 사용자 환경변수에서도 읽음(재시작 불필요). 화면에서 키 저장 가능.
  - claude -p MCP 방식 실패 원인 = 시작 직후 claude.ai 커넥터가 아직 안 붙음. stream-json 입력으로 12초 기다린 뒤 요청하면 됨(`notion_mcp_wait_sec`). 키 없을 때의 대체 경로.
- watcher: 카드 `data/items.json`(최근 120), 지난 메시지 불러오기(control.backfill), 중복 방지, 노션 대기열. app: 감시 프로그램 자동 재실행. `write_json`의 Windows 바꿔치기 재시도.
- 자동 실행: 시작프로그램 폴더 `coolwatch.lnk`. 바탕화면 `coolwatch 받은 업무.url`.
- 시험: test_fake 32/32, test_summarize, test_notion_api 통과.
- 개발 세션은 실제 메시지 본문을 읽는 명령이 권한 판정기에 막힘 → 실제 요약 품질은 교사가 화면에서 확인.

## 진행 기록 (2026-10-08) - 중복 기록 버그 수정
- 증상: 노션에 같은 메시지가 2줄씩. 원인: app.py의 자동 되살리기가 켠 직후(감시기가 status를 쓰기 전)에 '꺼짐'으로 오판해 watcher를 하나 더 띄움 → 둘이 같은 메시지를 각자 정리.
- 수정: watcher에 운영체제 잠금(data/watcher.lock, 단일 실행 보장), app은 시작 후 90초간 되살리기 안 함, 화면의 '꺼짐' 판정은 pid 생존 기준, 메시지 처리 중 heartbeat.
- 수정: notion_sync.page_id — 주소 '…/제목-10-8-<ID>'에서 제목의 숫자가 ID에 섞여 404 나던 문제(맨 끝 32자리만 사용). 노션 오류는 describe()로 로그에 코드·종류 기록.
- 가독성: 노션 보기 6칸 이하 + 줄바꿈, Claude가 18자 이내 '짧은제목'과 25자 이내 할 일을 쓰도록 프롬프트 변경, '다시 정리'(control.redo / 화면 체크박스).
- 정리: 노션 중복 4줄 + 시험 1줄 휴지통, 카드·md 번호 기준 중복 제거. 14건(#9928~#9941) 새 형식으로 갱신. test_fake 36/36.

## 진행 기록 (2026-10-08, 2차) - 쓰기 편하게
- 작은 수정: `check_recent.py --claude`가 실제로 Claude 요약을 보여 줌. `notion_setup.py` 속성 점검 목록 보완. '다시 정리'에서 노션 키가 없으면 로그에 '갱신 건너뜀'.
- 첨부 이름: 실제 `FilePath`는 `|개수|크기;크기|폴더|파일이름|번호|…|` 꼴(폴더는 보낸 사람 PC 경로, 이 PC에 파일 없음). `common.attachment_names`로 파일 이름만 뽑음(여러 개 지원). 노션 '첨부' 칸도 이 이름을 씀.
- 처리 상태: 화면 카드에 완료 / 해당없음 / 되돌리기. `data/marks.json`(화면 프로그램만 씀)에 저장하고 `ui_server.App.sync_loop`가 노션 '상태'와 양방향으로 맞춤(API 키 방식만. 보내기는 20초 안, 읽어 오기는 화면을 보는 동안 1분마다, 아직 못 보낸 화면 쪽 변경이 우선). 화면 기본 목록은 '남은 업무'만, 끝낸 글은 '끝남' 탭.
- 원문 보기: 카드 안에서 펼침. `/api/original`이 그 자리에서 DB를 읽기 전용으로 조회(전화번호 가림, 저장 안 함, 화면 토큰 필요).
- 새 글 표시: `data/seen.json`. 안 본 글이 있으면 트레이 아이콘에 주황 점 + 도움말에 건수, 화면에는 '새 글' 표시. 화면을 보면 꺼짐. `tray_dot: false`로 끔.
- 노션: '미정리' 보기 → '남은 업무'(미정리·확인함), '나와 관련' 보기 → '내 할 일'(관련=나 & 미정리·확인함). 페이지 레이아웃: 제목 아래 상태·관련·기한일·발신자 고정, 나머지 속성은 옆 칸.
- 확인: 노션 14줄과 카드 14장은 번호·제목·요청·주소가 모두 일치(중복 없음). 08:21의 404 7건은 page_id 수정 전 코드가 낸 것으로, 이후 정상 갱신됨.
- 시험: test_fake 46/46, test_notion_api 16항목, test_summarize 통과.
- 작은 전용 창: `app.open_panel`이 Edge `--app` 창을 화면 오른쪽 끝(폭 `panel_width` 440, 작업 영역 높이)에 띄움. 전용 프로필 `data/edge_panel`(크기·위치 기억). 이미 떠 있으면 창 제목으로 찾아 앞으로 가져옴. `window_mode: browser`면 예전처럼 탭. 바깥 링크는 `/api/open {what:url}`로 기본 브라우저에서 엶(전용 프로필에는 노션 로그인이 없음).
- 화면: 폭 700px 이하에서 한 줄 배치(기한 3줄 → 카드 → 설정, 머리 고정). 움직임(처음 차례로 올라옴, 새 카드 빛남, 끝낸 카드 옆으로 빠짐, 숫자 튐)은 '동작 줄이기' 설정이면 꺼짐. 화면 점검은 Edge 헤드리스를 디버그 포트로 조종해 버튼을 실제로 눌러 확인함.
- git: 이 PC 안에서만 관리(`data/`, `inbox/`, `.env`, `fake/` 제외). GitHub에는 올리지 않음.
- 버그 수정: 프로그램을 다시 켜면 화면 토큰이 바뀌어, 열려 있던 창의 버튼(완료 등)이 모두 403으로 거절되던 문제 → 상태 응답에 `page_version`을 넣어 창이 스스로 새로 고침(403을 받아도 새로 고침). 방금 노션에 보낸 상태는 90초 동안 노션의 옛 값으로 덮어쓰지 않음.
- 용어: 화면·로그·안내의 '감시'를 '연동'으로 바꿈(상태 코드 watching 등은 그대로).
- 디자인 개편(교사가 gdweb.co.kr 참고 요청): 밝은 머리띠에 남은 업무 수를 큰 숫자로(처음엔 검정 띠였으나 교사가 너무 어둡지 않게 요청 → 흰 바탕), 굵은 글자·가는 선·진홍 강조색 하나, 밑줄형 탭, 알약형 버튼. 트레이 아이콘은 동그라미 그대로(색만 맞춤). 글꼴은 PC에 있는 것만 사용(외부에서 받아오지 않음).
- Claude 요약 호출 개선(측정 근거): 예전에는 `--model` 없이 불러 계정 기본 모델(Opus 5.5)로 한 건에 입력 약 4,800토큰·환산 $0.041. 지금은 `--model haiku --effort low` + 짧은 전용 `--system-prompt` + `--strict-mcp-config` + `--disable-slash-commands` + `--tools ""`로 입력 약 1,850토큰·환산 $0.0005~0.0007(가짜 글 기준, 결과 품질 동등). Sonnet·low는 $0.012.
  - 설정: `claude_model`(haiku/sonnet/opus), `claude_effort`(low/medium/high), `claude_min_chars` 30, `claude_daily_limit` 200, `claude_cooldown_sec` 600. 화면 '정리 방식'에서 모델·노력 선택, 오늘 사용량(`data/usage.json`) 표시, claude 없으면 안내.
  - 응답은 `--output-format json`으로 받아 `is_error`·토큰을 확인. 실패하면 쉬는 시간 동안 규칙으로 정리하고 카드 방식에 까닭을 적음.
- 화면 색: `ui_theme`(crimson/blue/green/violet/orange/ink), `ui_mode`(auto/light/dark). `<html data-theme data-mode>`로 적용, 서버가 처음부터 넣어 줌. 방금 누른 색·완료는 6초 동안 서버의 옛 값보다 우선(깜빡임 방지).
- 그 밖: `db_path: "auto"`(쿨메신저 DB 자동 찾기), 창 닫힘으로 끊긴 연결의 오류 출력 없앰, `notion_model` 기본값을 별칭 haiku로. 시험 test_fake 52항목.
- 끊김·재접속 대응(교사가 교실을 옮겨 다님. 자리의 랜선이 빠지면 쿨메신저가 꺼짐):
  - 확인한 사실: 실제 Error.log는 3년간 33줄뿐이고 모두 허용된 두 종류(LogStart, Null Virtual Machine pointer). 망 끊김으로 오류 로그가 늘지는 않음. 쿨메신저 프로세스 이름은 `CoolMessenger`.
  - 발견: `mode=ro`로 열어도 `-wal`이 없으면 SQLite가 `-wal`/`-shm`을 새로 만듦(가짜 DB로 확인) → `common.connect_ro`가 `-wal`이 없을 때 `immutable=1`로 엶. 쿨메신저가 꺼진 동안 그 폴더에 아무것도 만들지 않음.
  - `common.online(cfg, host)`: 443 연결을 2초 안에 확인, 20초 기억. 끊겨 있으면 Claude·노션을 시도하지 않고 미룸(시험용 `simulate_offline`).
  - 끊긴 동안 온 글: 규칙으로 바로 카드(`규칙(오프라인)`) → `data/claude_retry.json`에 번호를 적어 두고, 연결되면 회차당 3건씩 `redo_row`로 Claude 재정리(5번 실패하면 포기). Claude 실패·쉬는 중인 글도 같은 대기열로.
  - 노션 대기열·상태 맞추기: 끊겨 있으면 조용히 대기(로그에 실패가 쌓이지 않음). 로그는 끊김/다시 연결됨이 바뀔 때 한 줄. DB 읽기 실패도 같은 까닭이면 10분에 한 줄.
  - 화면: 쿨메신저가 꺼져 있으면(=`-wal` 없음) '대기 중' 표시. 상태 코드는 watching 그대로.
  - 시험: test_fake 62항목(끊김 → 규칙 카드 → 재연결 → Claude 재정리·노션 전송 포함). 실제로 랜선을 뽑는 시험은 하지 못함.

## 진행 기록 (2026-10-08, 3차) - 공유·배포 준비
- 대상: ① 받아서 쓰기만 할 사람 ② 이것을 바탕으로 더 발전시킬 사람. 둘 다 Claude 구독자. 비공개 초대 방식.
- 설치: `설치.bat` → `tools/install.ps1`. `%LOCALAPPDATA%\coolwatch`에 복사(설정·기록 유지), 실행 환경은 그 안의 `runtime/`(PC에 파이썬 3.10+가 있으면 venv, 없으면 python.org의 embeddable 3.12.10 + get-pip), `pystray`·`pillow` 설치, 바탕화면·시작프로그램 바로가기, 실행. `제거.bat`은 끄고 바로가기만 지움. 두 방식 모두 임시 폴더에 실제 설치해 확인했고, 내려받은 파이썬으로 test_fake 전체가 돎.
  - `.ps1`은 UTF-8(BOM)+CRLF, `.bat`은 영문+CRLF여야 함(Windows PowerShell 5.1·cmd가 한글을 깨뜨림).
- 처음 설정: `setup_done`이 false면 화면 맨 위에 안내(쿨메신저 찾기·제외 단어·내 역할·Claude·노션). Claude는 `claude auth status --json`으로 설치·로그인·요금제를 확인하고, 설치(`irm https://claude.ai/install.ps1 | iex`)와 로그인(`claude auth login`)은 보이는 창에서 실행. `common.find_claude`는 방금 설치해 PATH에 없는 경우(`~/.local/bin/claude.exe`)도 찾음.
- 노션: 화면에서 받은 업무함 주소를 붙여 넣으면 ID 저장(`/api/notion_db`), 키 확인이 성공하면 `notion_enabled`를 켬. 노션에 '사용 설명서' 페이지와 그 아래 '받은 업무함 (템플릿)'(속성 16개, 보기 5개, 페이지 배치)을 만들어 둠. 주소는 `config.example.json`의 `manual_url`, `notion_template_url`.
- 배포물: `python tools/make_release.py` → `dist/coolwatch-<버전>.zip`. `config.json`·기록·예전 `coolwatch.py`는 넣지 않고, HANDOFF의 개인 값은 지우며, 압축 파일 안에 개인 값·메일·노션 시크릿 모양이 있으면 실패. 새 설치의 기본값(`config.example.json`): `db_path` auto, 제외 단어 5개, 규칙 정리, 노션 꺼짐.
- 아직: 다른 PC·다른 쿨메신저 버전에서는 한 번도 돌려 보지 못함. GitHub 비공개 저장소는 만들지 않음(이 PC에 gh 없음).

- 공개 웹사이트(GitHub Pages): https://guenhee9474-tech.github.io/teacher-kit/ (연수 자료 카드 모음) 과 그 아래 /coolwatch/ (설명서 + 압축 파일 받기). 소스는 site/, 올리기는 python tools/publish_site.py(압축 파일을 새로 만들어 site/downloads/coolwatch.zip으로 넣고 공개 저장소 teacher-kit 에 올림. gh 로그인 필요, 휴대용 gh 는 dist/tools/gh). 카드는 site/index.html의 CARDS 목록에 추가. 교사 요청으로 홍보 느낌 없이 문서처럼 담백하게.
- 노션에는 받은 업무함 템플릿만 남김(공개 게시됨). 설명서·연수 안내 노션 페이지는 웹사이트로 대체.
- 남은 것(교사 결정으로 보류): exe 만들기. 그 밖의 후보: 첨부 HWPX 마감일 추출, 노션 → 할 일·일정 정리(Routines).
