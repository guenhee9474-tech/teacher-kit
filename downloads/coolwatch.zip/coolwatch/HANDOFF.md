# coolwatch 핸드오프 (2026-10-07)

## 목표

쿨메신저로 업무 메시지가 오면 즉시 노션 '받은 업무함' DB에 기록한다. 교사는 정신없는 팝업을 꺼 두었고, 노션 받은 업무함을 "조용한 알림창"으로 쓰려 한다. 답장 자동화는 하지 않는다. 할 일·일정 정리는 나중에 노션 쪽에서 Claude Routines로 한다(이번 범위 아님).

이번 작업은 지금의 명령줄 스크립트(`coolwatch.py` v0.1)를 **쓰기 편한 인터페이스가 있는 도구**로 만드는 것이다.

## 직접 확인된 사실

교사가 PC에서 직접 실행해 확인한 내용이다. 다시 확인하려고 실제 DB를 열지 말 것.

**파일**
- 위치: `C:\Users\user\AppData\Local\CoolMessenger\Memo\`
- `<이름>.udb` (약 287MB, SQLite 3), `-wal`, `-shm`, `<이름>.udb_Error.log` (마지막 수정 2026-08-19)
- `PRAGMA journal_mode` = `wal`
- 새 메시지를 받으면 `-wal`의 수정 시각과 크기만 바뀌고, 본 파일은 바뀌지 않는다. 감시 신호는 `-wal` 수정 시각.
- 287MB라 매번 복사하는 방식은 쓰지 않는다. 읽기 전용 URI 연결로 원본을 직접 짧게 조회하는 방식이 동작함을 확인했다.

**스키마 (쓰는 테이블만)**

`tbl_recv` (받은 메시지)
- `MessageKey INTEGER` 자동 증가(`sqlite_sequence` 존재). "마지막 처리 번호보다 큰 것"으로 새 메시지를 가린다.
- `SenderKey TEXT` 예: `|1|1234|` → 마지막 숫자가 발신자 ID
- `Sender TEXT`, `Title TEXT`
- `MessageText TEXT` 사람이 읽을 수 있는 본문. 앞에 `\r\n`이 붙어 있다.
- `MessageBody TEXT` `{COMP}` + base64(zlib) 압축 서식 데이터. 쓰지 않는다.
- `ReceiveDate DATE` 형식: `2026/10/07 12:52:00 (수)` (한국 시간)
- `FilePath`, `LinkURL`, `IsUnRead`, `MessageType`, `MessageCategory`, `DeletedDate` 등
- 그 밖의 열: `CoolFile2SessionID, ReferenceList, CCList, FileHost, MemoID, IsChecked, IsMoved`

`tbl_member` (교직원 210명): `K_MemberID INTEGER, MemberID TEXT, MemberName TEXT`
- `SenderKey`의 ID가 `K_MemberID`와 `MemberID` 중 어느 쪽과 맞는지는 **아직 미확인**. `coolwatch.py --find 이름`으로 교사가 확인할 예정.

`tbl_send`(보낸 메시지, `ScheduledDate` 있음), `tbl_dbInfo`, `tbl_autotext`, `tbl_alarm`, `sqlite_stat1`도 있으나 쓰지 않는다.

**자기 테스트 결과**: 나에게 보낸 예약 메시지가 `tbl_recv`에 들어온다(`MessageType=5, MessageCategory=0, SenderKey='|1|1234|'`). 실제 동료 메시지의 Type/Category 값은 아직 모른다.

## 현재 코드: coolwatch.py v0.1

- 15초마다 `-wal`과 본 파일의 수정 시각을 보고, 바뀌었으면 새 메시지를 조회한다.
- 화이트리스트 발신자만 기록하고, 제외 단어가 있으면 건너뛰며, 휴대폰 번호는 가린다.
- 노션 API(`2022-06-28`, `urllib`)로 페이지를 만든다. 속성: 제목(title), 발신자(text), 받은시각(date), 상태(select, "미정리"), 메시지키(number), 첨부(text). 본문은 블록으로.
- 실패하면 번호를 넘기지 않아 다음 회차에 다시 시도한다.
- 첫 실행 때 현재 최대 번호부터 시작한다(과거 메시지를 올리지 않음).
- `--find 이름`(발신자 ID 찾기), `--test`(노션 연결 시험) 기능이 있다.
- 설정은 파일 맨 위 상수다. → 이번에 설정 파일로 분리한다.

## 이번 작업: 인터페이스

### 교사가 원하는 것
1. **조용함**: 팝업, 소리, 토스트 알림 없음. 이게 이 도구의 존재 이유다.
2. **한눈에 상태 확인**: 지금 감시 중인지, 멈췄는지, 오류인지.
3. **화이트리스트를 이름으로 관리**: ID를 외우지 않고, 교직원 명단에서 이름을 검색해 체크한다.
4. **제외 단어 편집**: 목록에 추가하고 삭제한다.
5. **오늘 기록된 항목 보기**: 시각, 발신자, 제목, 노션 페이지 바로가기.
6. **일시정지와 재개**, 노션 받은 업무함 바로 열기.
7. 로그온할 때 자동 실행.

### 권장 구성 (확인 후 Claude가 최종 결정)
- 작업표시줄 트레이 아이콘(예: `pystray` + `Pillow`)과 클릭하면 열리는 로컬 설정 페이지(`127.0.0.1`에서만 접속, 가능하면 표준 라이브러리 `http.server`).
  - 아이콘 색으로 상태를 표시한다(감시 중 / 일시정지 / 오류).
- pip 설치가 막혀 있으면 표준 라이브러리 `tkinter` 창 하나로 대체한다.
- 먼저 `pip install`이 되는지 확인하고, 두 안 중 하나를 교사에게 짧게 제안한 뒤 진행할 것.

### 구조 정리
- `config.json`: DB 경로, 화이트리스트, 제외 단어, 노션 DB ID, 감시 주기. UI에서 편집한다. 키는 넣지 않는다.
- 감시 로직(`watcher`)과 UI를 분리한다. UI가 꺼져도 감시는 계속 돌 수 있게.
- 실행 중 생기는 데이터(상태 번호, 오늘 기록 목록, 로그)는 `data/`에 둔다.
  - 오늘 기록 목록에는 노션 응답의 페이지 URL을 저장한다(v0.1은 응답을 버리고 있음).
- 화이트리스트에는 ID를 저장하되, UI에는 `tbl_member`에서 읽은 이름으로 보여 준다. 실행 중에 읽는 것이므로 Claude가 명단 내용을 볼 필요는 없다.

### 개발 방식 (필수)
- `make_fake_db.py`: 위 스키마와 같은 가짜 DB(WAL 모드, 가짜 교직원 20명, 가짜 메시지 몇 개)를 `fake/`에 만든다.
- `inject_fake_message.py`: 가짜 DB에 메시지를 한 건 추가한다. 실시간 감지 시험용.
- 가짜 `Error.log`의 수정 시각을 바꿔 중단 장치도 시험한다.
- 노션 시험은 교사에게 별도의 시험용 DB를 만들어 달라고 요청한다.

### 완료 기준
- [ ] 가짜 DB에 메시지를 넣으면 15초 안에 노션 시험 DB에 기록되고, 오늘 목록에 나타난다
- [ ] 화이트리스트에 없는 발신자, 제외 단어가 있는 메시지는 기록되지 않는다
- [ ] 이름 검색으로 화이트리스트를 추가하거나 빼면 다시 시작하지 않아도 반영된다
- [ ] 일시정지 중에 온 메시지는 재개 후 빠짐없이 기록된다
- [ ] 노션 접속이 끊겼다가 돌아오면 밀린 메시지를 순서대로 기록한다
- [ ] 가짜 Error.log를 바꾸면 멈추고, 아이콘과 화면에 오류가 보인다
- [ ] 로그와 화면 어디에도 팝업·소리가 없다
- [ ] 로그온 자동 실행 방법(작업 스케줄러)을 교사가 따라 할 수 있게 안내한다
- [ ] 실제 DB로 바꾸는 방법(config.json의 경로 한 줄)을 교사에게 안내한다. 직접 바꾸지 않는다.

## 나중 단계 (이번 범위 아님)
- 노션 받은 업무함 → 할 일·일정 정리 (Claude Routines + 노션 커넥터)
- 첨부 HWPX에서 마감일 추출
- PyInstaller로 exe 만들기

## 진행 기록 (2026-10-07, 2차)
- 교사 결정: 노션은 보류, 출력은 `inbox/날짜.md`. 요청사항·기한·일정 정리를 자동화. 요약 봇(`claude -p`)이 메시지를 읽는 것은 허용(스위치 방식). 개발 세션의 실제 메시지 열람 금지는 유지(CLAUDE.md 갱신).
- 구현: `common.py, watcher.py, summarize.py, ui_server.py, ui_page.html, app.py, make_fake_db.py, inject_fake_message.py, test_fake.py, config.json, 사용안내.md`. `test_fake.py` 18/18 통과.
- 미검증: ① `claude -p --tools ""` 옵션(이 PC에 claude CLI 없음) ② 실제 트레이 아이콘 모양·설정 페이지의 브라우저 표시 ③ `SenderKey` ID가 K_MemberID/MemberID 중 어느 쪽인지(`member_id_column`) ④ 실제 쿨메신저 메시지의 Type/Category.
- `coolwatch.py`(v0.1, 노션 전송)는 참고용으로 남김. 노션 연동은 나중에 watcher의 `record()`에 추가.

## 진행 기록 (2026-10-07, 3차)
- 규칙 완화(교사): 개발 세션도 실제 DB를 읽기 전용으로 확인 가능. CLAUDE.md 갱신.
- 확인된 사실: 실제 `Error.log`는 **UTF-16(BOM)**, 쿨메신저 시작 때만 `LogStart`/`Null Virtual Machine pointer` 줄이 붙음(로그아웃은 안 바뀜). `SenderKey`의 ID는 **K_MemberID**와 163/163 일치(`MemberID` 열은 이름). MessageType 0/5/28, Category 0/NULL.
- 변경: 오류 로그 판단을 '수정 시각'에서 '새로 붙은 줄이 낯선 오류인가'로 변경(방식 A). DB 경로가 바뀌면 last_key 재설정. `test_fake.py` 19/19.
- `config.json`의 `db_path`를 실제 DB로 전환함. 화이트리스트는 비어 있음(교사가 설정 페이지에서 선택).
- 남은 것: Claude 요약(`claude` CLI 설치 필요) 시험, 실제 동료 메시지로 규칙 요약 품질 점검, 로그온 자동 실행 등록.

## 진행 기록 (2026-10-07, 4차)
- 실제 메시지 5건으로 규칙 요약 점검 → 개선(인용 제외, '오늘 중' 등 기한, '10월 말', 링크, 인사말 제외, 발신자 내선번호 제거). `test_summarize.py` 13/13.
- 방향: 최종적으로 Claude 요약이 본체, 규칙은 대체 수단. 노션은 이 결과를 입력으로 나중에 추가.
- Claude CLI 설치: `npm install -g @anthropic-ai/claude-code` 후 네이티브 패키지가 빠져 `claude-code-win32-x64@2.1.292`를 따로 설치하고 `node install.cjs` 재실행(학교 네트워크가 느려 9분 소요). 이미 claude.ai 로그인됨.
- `summarize.py`: `shutil.which`로 claude 경로 해결(Windows .cmd), `--no-session-persistence` 추가. 가짜 메시지 Claude 요약 시험 통과.
- 미반영: 앱 재시작(전체 수신 `record_all`, 개선된 요약 적용)과 `summary_mode: claude` 전환은 교사가 한다.

## 진행 기록 (2026-10-07, 5차) - 노션 연결
- 노션에 '받은 업무함' DB 생성(DB (지움), data source (지움)). config.json에 연결, notion_enabled=true.
- `notion_sync.py`: API 방식(NOTION_TOKEN) 기본. 가짜 서버로 요청 모양 시험(`test_notion_api.py`). 실제 노션으로는 키가 없어 미시험.
- claude -p의 노션 MCP 방식은 6회 중 1회만 성공(모델이 도구를 안 부르고 가짜 URL을 지어냄) → 자동 선택 제외, tool_result 검증 추가.
- watcher: 노션 대기열(data/notion_pending.json), 실패/키 없음이면 보관 후 재시도, 번호 순서 보장, 중복 방지. `test_fake.py` 24/24.
- 교사 할 일: `python notion_setup.py`로 키 설정 → 앱 재시작. 노션의 [시험] 페이지 2개 삭제.

## 진행 기록 (2026-10-07, 6차) - 최종 정리
- 화면 전면 개편(`ui_page.html`): 상태·숫자 타일·카드 목록(관련도 띠)·다가오는 기한/일정·설정 접이식. 가짜 데이터로 Edge 헤드리스 캡처해 확인.
- 관련도(`relevance.py` + Claude): config `my_roles`, `my_name`(DB 파일명에서 자동) → 나/전체/기타. 노션 속성 `관련`, `대상` 추가.
- 달력: 요약에 `기한일`, `일정일`(ISO) 추가(월 없는 '20일까지', '내일', '10월 말' 등 해석). 노션 `일정일` 속성 + 보기(기한 캘린더, 일정 캘린더, 상태 보드, 미정리, 나와 관련).
- 노션: 교사가 NOTION_TOKEN 설정함 → API 방식 실전 확인(0.7초). 키는 레지스트리 사용자 환경변수에서도 읽음(재시작 불필요). 화면에서 키 저장 가능.
  - claude -p MCP 방식 실패 원인 = 시작 직후 claude.ai 커넥터가 아직 안 붙음. stream-json 입력으로 12초 기다린 뒤 요청하면 됨(`notion_mcp_wait_sec`). 키 없을 때의 대체 경로.
- watcher: 카드 `data/items.json`(최근 120), 지난 메시지 불러오기(control.backfill), 중복 방지, 노션 대기열. app: 감시 프로그램 자동 재실행. `write_json`의 Windows 바꿔치기 재시도.
- 자동 실행: 시작프로그램 폴더 `coolwatch.lnk`. 바탕화면 `coolwatch 받은 업무.url`.
- 시험: test_fake 32/32, test_summarize, test_notion_api 통과.
- 개발 세션은 실제 메시지 본문을 읽는 명령이 권한 판정기에 막힘 → 실제 요약 품질은 교사가 화면에서 확인.

## 진행 기록 (2026-10-08) - 중복 기록 버그 수정
- 증상: 노션에 같은 메시지가 2줄씩. 원인: app.py의 자동 되살리기가 켠 직후(감시기가 status를 쓰기 전)에 '꺼짐'으로 오판해 watcher를 하나 더 띄움 → 둘이 같은 메시지를 각자 정리.
- 수정: watcher에 운영체제 잠금(data/watcher.lock, 단일 실행 보장), app은 시작 후 90초간 되살리기 안 함, 화면의 '꺼짐' 판정은 pid 생존 기준, 메시지 처리 중 heartbeat.
- 수정: notion_sync.page_id — 주소 '…/제목-10-8-<ID>'에서 제목의 숫자가 ID에 섞여 404 나던 문제(맨 끝 32자리만 사용). 노션 오류는 describe()로 로그에 코드·종류 기록.
- 가독성: 노션 보기 6칸 이하 + 줄바꿈, Claude가 18자 이내 '짧은제목'과 25자 이내 할 일을 쓰도록 프롬프트 변경, '다시 정리'(control.redo / 화면 체크박스).
- 정리: 노션 중복 4줄 + 시험 1줄 휴지통, 카드·md 번호 기준 중복 제거. 14건(#9928~#9941) 새 형식으로 갱신. test_fake 36/36.

## 진행 기록 (2026-10-08, 2차) - 쓰기 편하게
- 작은 수정: `check_recent.py --claude`가 실제로 Claude 요약을 보여 줌. `notion_setup.py` 속성 점검 목록 보완. '다시 정리'에서 노션 키가 없으면 로그에 '갱신 건너뜀'.
- 첨부 이름: 실제 `FilePath`는 `|개수|크기;크기|폴더|파일이름|번호|…|` 꼴(폴더는 보낸 사람 PC 경로, 이 PC에 파일 없음). `common.attachment_names`로 파일 이름만 뽑음(여러 개 지원). 노션 '첨부' 칸도 이 이름을 씀.
- 처리 상태: 화면 카드에 완료 / 해당없음 / 되돌리기. `data/marks.json`(화면 프로그램만 씀)에 저장하고 `ui_server.App.sync_loop`가 노션 '상태'와 양방향으로 맞춤(API 키 방식만. 보내기는 20초 안, 읽어 오기는 화면을 보는 동안 1분마다, 아직 못 보낸 화면 쪽 변경이 우선). 화면 기본 목록은 '남은 업무'만, 끝낸 글은 '끝남' 탭.
- 원문 보기: 카드 안에서 펼침. `/api/original`이 그 자리에서 DB를 읽기 전용으로 조회(전화번호 가림, 저장 안 함, 화면 토큰 필요).
- 새 글 표시: `data/seen.json`. 안 본 글이 있으면 트레이 아이콘에 주황 점 + 도움말에 건수, 화면에는 '새 글' 표시. 화면을 보면 꺼짐. `tray_dot: false`로 끔.
- 노션: '미정리' 보기 → '남은 업무'(미정리·확인함), '나와 관련' 보기 → '내 할 일'(관련=나 & 미정리·확인함). 페이지 레이아웃: 제목 아래 상태·관련·기한일·발신자 고정, 나머지 속성은 옆 칸.
- 확인: 노션 14줄과 카드 14장은 번호·제목·요청·주소가 모두 일치(중복 없음). 08:21의 404 7건은 page_id 수정 전 코드가 낸 것으로, 이후 정상 갱신됨.
- 시험: test_fake 46/46, test_notion_api 16항목, test_summarize 통과.
- 작은 전용 창: `app.open_panel`이 Edge `--app` 창을 화면 오른쪽 끝(폭 `panel_width` 440, 작업 영역 높이)에 띄움. 전용 프로필 `data/edge_panel`(크기·위치 기억). 이미 떠 있으면 창 제목으로 찾아 앞으로 가져옴. `window_mode: browser`면 예전처럼 탭. 바깥 링크는 `/api/open {what:url}`로 기본 브라우저에서 엶(전용 프로필에는 노션 로그인이 없음).
- 화면: 폭 700px 이하에서 한 줄 배치(기한 3줄 → 카드 → 설정, 머리 고정). 움직임(처음 차례로 올라옴, 새 카드 빛남, 끝낸 카드 옆으로 빠짐, 숫자 튐)은 '동작 줄이기' 설정이면 꺼짐. 화면 점검은 Edge 헤드리스를 디버그 포트로 조종해 버튼을 실제로 눌러 확인함.
- git: 이 PC 안에서만 관리(`data/`, `inbox/`, `.env`, `fake/` 제외). GitHub에는 올리지 않음.
- 버그 수정: 프로그램을 다시 켜면 화면 토큰이 바뀌어, 열려 있던 창의 버튼(완료 등)이 모두 403으로 거절되던 문제 → 상태 응답에 `page_version`을 넣어 창이 스스로 새로 고침(403을 받아도 새로 고침). 방금 노션에 보낸 상태는 90초 동안 노션의 옛 값으로 덮어쓰지 않음.
- 용어: 화면·로그·안내의 '감시'를 '연동'으로 바꿈(상태 코드 watching 등은 그대로).
- 디자인 개편(교사가 gdweb.co.kr 참고 요청): 밝은 머리띠에 남은 업무 수를 큰 숫자로(처음엔 검정 띠였으나 교사가 너무 어둡지 않게 요청 → 흰 바탕), 굵은 글자·가는 선·진홍 강조색 하나, 밑줄형 탭, 알약형 버튼. 트레이 아이콘은 동그라미 그대로(색만 맞춤). 글꼴은 PC에 있는 것만 사용(외부에서 받아오지 않음).
- Claude 요약 호출 개선(측정 근거): 예전에는 `--model` 없이 불러 계정 기본 모델(Opus 5.5)로 한 건에 입력 약 4,800토큰·환산 $0.041. 지금은 `--model haiku --effort low` + 짧은 전용 `--system-prompt` + `--strict-mcp-config` + `--disable-slash-commands` + `--tools ""`로 입력 약 1,850토큰·환산 $0.0005~0.0007(가짜 글 기준, 결과 품질 동등). Sonnet·low는 $0.012.
  - 설정: `claude_model`(haiku/sonnet/opus), `claude_effort`(low/medium/high), `claude_min_chars` 30, `claude_daily_limit` 200, `claude_cooldown_sec` 600. 화면 '정리 방식'에서 모델·노력 선택, 오늘 사용량(`data/usage.json`) 표시, claude 없으면 안내.
  - 응답은 `--output-format json`으로 받아 `is_error`·토큰을 확인. 실패하면 쉬는 시간 동안 규칙으로 정리하고 카드 방식에 까닭을 적음.
- 화면 색: `ui_theme`(crimson/blue/green/violet/orange/ink), `ui_mode`(auto/light/dark). `<html data-theme data-mode>`로 적용, 서버가 처음부터 넣어 줌. 방금 누른 색·완료는 6초 동안 서버의 옛 값보다 우선(깜빡임 방지).
- 그 밖: `db_path: "auto"`(쿨메신저 DB 자동 찾기), 창 닫힘으로 끊긴 연결의 오류 출력 없앰, `notion_model` 기본값을 별칭 haiku로. 시험 test_fake 52항목.
- 끊김·재접속 대응(교사가 교실을 옮겨 다님. 자리의 랜선이 빠지면 쿨메신저가 꺼짐):
  - 확인한 사실: 실제 Error.log는 3년간 33줄뿐이고 모두 허용된 두 종류(LogStart, Null Virtual Machine pointer). 망 끊김으로 오류 로그가 늘지는 않음. 쿨메신저 프로세스 이름은 `CoolMessenger`.
  - 발견: `mode=ro`로 열어도 `-wal`이 없으면 SQLite가 `-wal`/`-shm`을 새로 만듦(가짜 DB로 확인) → `common.connect_ro`가 `-wal`이 없을 때 `immutable=1`로 엶. 쿨메신저가 꺼진 동안 그 폴더에 아무것도 만들지 않음.
  - `common.online(cfg, host)`: 443 연결을 2초 안에 확인, 20초 기억. 끊겨 있으면 Claude·노션을 시도하지 않고 미룸(시험용 `simulate_offline`).
  - 끊긴 동안 온 글: 규칙으로 바로 카드(`규칙(오프라인)`) → `data/claude_retry.json`에 번호를 적어 두고, 연결되면 회차당 3건씩 `redo_row`로 Claude 재정리(5번 실패하면 포기). Claude 실패·쉬는 중인 글도 같은 대기열로.
  - 노션 대기열·상태 맞추기: 끊겨 있으면 조용히 대기(로그에 실패가 쌓이지 않음). 로그는 끊김/다시 연결됨이 바뀔 때 한 줄. DB 읽기 실패도 같은 까닭이면 10분에 한 줄.
  - 화면: 쿨메신저가 꺼져 있으면(=`-wal` 없음) '대기 중' 표시. 상태 코드는 watching 그대로.
  - 시험: test_fake 62항목(끊김 → 규칙 카드 → 재연결 → Claude 재정리·노션 전송 포함). 실제로 랜선을 뽑는 시험은 하지 못함.

## 진행 기록 (2026-10-08, 3차) - 공유·배포 준비
- 대상: ① 받아서 쓰기만 할 사람 ② 이것을 바탕으로 더 발전시킬 사람. 둘 다 Claude 구독자. 비공개 초대 방식.
- 설치: `설치.bat` → `tools/install.ps1`. `%LOCALAPPDATA%\coolwatch`에 복사(설정·기록 유지), 실행 환경은 그 안의 `runtime/`(PC에 파이썬 3.10+가 있으면 venv, 없으면 python.org의 embeddable 3.12.10 + get-pip), `pystray`·`pillow` 설치, 바탕화면·시작프로그램 바로가기, 실행. `제거.bat`은 끄고 바로가기만 지움. 두 방식 모두 임시 폴더에 실제 설치해 확인했고, 내려받은 파이썬으로 test_fake 전체가 돎.
  - `.ps1`은 UTF-8(BOM)+CRLF, `.bat`은 영문+CRLF여야 함(Windows PowerShell 5.1·cmd가 한글을 깨뜨림).
- 처음 설정: `setup_done`이 false면 화면 맨 위에 안내(쿨메신저 찾기·제외 단어·내 역할·Claude·노션). Claude는 `claude auth status --json`으로 설치·로그인·요금제를 확인하고, 설치(`irm https://claude.ai/install.ps1 | iex`)와 로그인(`claude auth login`)은 보이는 창에서 실행. `common.find_claude`는 방금 설치해 PATH에 없는 경우(`~/.local/bin/claude.exe`)도 찾음.
- 노션: 화면에서 받은 업무함 주소를 붙여 넣으면 ID 저장(`/api/notion_db`), 키 확인이 성공하면 `notion_enabled`를 켬. 노션에 '사용 설명서' 페이지와 그 아래 '받은 업무함 (템플릿)'(속성 16개, 보기 5개, 페이지 배치)을 만들어 둠. 주소는 `config.example.json`의 `manual_url`, `notion_template_url`.
- 배포물: `python tools/make_release.py` → `dist/coolwatch-<버전>.zip`. `config.json`·기록·예전 `coolwatch.py`는 넣지 않고, HANDOFF의 개인 값은 지우며, 압축 파일 안에 개인 값·메일·노션 시크릿 모양이 있으면 실패. 새 설치의 기본값(`config.example.json`): `db_path` auto, 제외 단어 5개, 규칙 정리, 노션 꺼짐.
- 아직: 다른 PC·다른 쿨메신저 버전에서는 한 번도 돌려 보지 못함. GitHub 비공개 저장소는 만들지 않음(이 PC에 gh 없음).

- 공개 웹사이트(GitHub Pages): https://guenhee9474-tech.github.io/teacher-kit/ (연수 자료 카드 모음) 과 그 아래 /coolwatch/ (설명서 + 압축 파일 받기). 소스는 site/, 올리기는 python tools/publish_site.py(압축 파일을 새로 만들어 site/downloads/coolwatch.zip으로 넣고 공개 저장소 teacher-kit 에 올림. gh 로그인 필요, 휴대용 gh 는 dist/tools/gh). 카드는 site/index.html의 CARDS 목록에 추가. 교사 요청으로 홍보 느낌 없이 문서처럼 담백하게.
- 노션에는 받은 업무함 템플릿만 남김(공개 게시됨). 설명서·연수 안내 노션 페이지는 웹사이트로 대체.
- 사이트에 페이지 추가(2026-10-08): site/prep/(연수 전 준비 체크리스트, 체크는 브라우저에 저장), site/devenv/(교사의 아티팩트 'AI 작업실 설계도'를 옮겨 온 것. scratchpad의 변환 스크립트로 만들었고 coolwatch 설명을 지금 상태로 고침), site/writing/(영어 쓰기 수행평가 본보기 안내)와 site/writing/demo/(서버 없는 체험 페이지).
- 수행평가 본보기: 원본은 교사의 다른 프로젝트(~/claudetest, 실제 수업에 운영 중, 건드리지 않음). python tools/make_writing_kit.py가 원본을 읽어 서버 주소·토큰·PIN·폴더 ID·배포 ID·메일·저장소 주소를 가리고 kits/english-writing/, site/downloads/english-writing-kit.zip, 체험 페이지를 만든 뒤 남은 값이 있으면 실패함. 추가한 것: CONFIG.assignmentId(과제별 저장 칸), 한국어 줄바꿈, 연습 모드 표시, 새로 설치하는 사람용 README·CLAUDE.md. 원본의 자동 시험(mocktest 117항목, teachertest)이 사본에서 통과함(가짜 서버 주소를 넣은 임시 사본, Edge 사용).
- 첫 화면 카드 순서: site/index.html의 CARDS 목록 순서가 기본. 화면 아래 '카드 순서 바꾸기'로 끌어서 바꾸면 그 브라우저에만 저장되고, '카드 순서: a, b, c' 줄을 받아 CARDS 순서를 고쳐 올리면 모두에게 적용됨.
- 남은 것(교사 결정으로 보류): exe 만들기. 그 밖의 후보: 첨부 HWPX 마감일 추출, 노션 → 할 일·일정 정리(Routines).

## 2026-10-08 (오후) 시연용 화면, 개발환경 페이지 다시 쓰기, 발표자료

- `시연.bat` / `tools/demo.py`: 지어낸 메시지만 든 `demo/` 폴더(깃 제외)로 coolwatch 를 8790 포트에 띄움. 규칙 요약, 노션·Claude 안 씀. 화면에 "시연용 · 가짜 자료" 표시, 창 제목 "coolwatch 시연"(진짜 창과 섞이지 않게). 설정에 `"demo": true`.
- 교사 본인 설정의 제외 단어를 기본 다섯 개(상담, 학부모, 생활기록, 성적, 결석)로 채움(교사가 맡김). 새 메시지부터 적용.
- 수행평가 본보기: 설치 안내 9단계(`git push -u`), 10단계(주소 고친 뒤 `clasp push` 먼저) 수정, `setup.sh` 용도 설명, 안내 글의 숫자를 코드 값(이탈 전송 4초, 총괄 갱신 180초/20초)에 맞춤. 받은 압축 파일에 새 값을 넣는 흐름을 흉내 내 자동 시험 통과(117항목, 교사 화면). clasp 3.4.1 에서 안내의 명령 이름이 모두 있는 것 확인. 구글 로그인이 필요한 단계는 여전히 실제로 돌려 보지 못함.
- 원본 수행평가 저장소(공개)는 건드리지 않음. 확인한 것: 학생 글 읽기는 기기 열쇠, 반 현황은 교사 열쇠가 필요하고 둘 다 소스·git 기록에 없음. 소스에 보이는 것은 주소·token·PIN(학생이 자기 기기에서 제출 취소 가능, 낯선 사람이 빈 줄을 만들 수 있음). 무료 계정은 비공개로 바꾸면 Pages 가 꺼지므로 그대로 둠.
- `site/devenv/index.html`: 검토에서 나온 오류·불일치를 반영해 다시 씀(자료가 가는 길 표, 세 질문, 본보기 실제 구조, 배포 규칙, 연수에서 하는 것과 구상 구분, 용어 표).
- 발표자료(27장): https://claude.ai/artifact/5CpT4jtdGjT1W4FbJHifMP (비공개. 수행평가 16장 → AI 작업실 4장 → coolwatch 4장). 원고는 scratchpad 가 아니라 아티팩트 안에 있음.
- (같은 날 저녁) 교사 의견 반영: 개발환경 페이지를 "설계도"에서 실습에 필요한 것만 담은 안내로 다시 씀(클라우드 세션·구상 부분 삭제, 카드 이름도 "개발환경"). 준비 페이지의 "진행자 준비" 삭제(체크 14개). 발표자료는 꾸밈을 빼고 구조 중심 26장으로 다시 씀(요청 흐름, Apps Script 서버, 시트, 배포 구조 장 추가). 발표자료는 교사만 봄.
- (같은 날 밤) 교사가 정한 중심: "구조(프론트엔드·백엔드·데이터·배포)를 틀로 Claude Code 와 계획하고 대화하는 것". 발표자료를 이 틀로 다시 씀(15장: 네 층 → 계획 대화 → 층별 구현과 "Claude Code 와 나눌 말" → 고칠 때 좁혀 말하기 → coolwatch → 시연 5분·실습 15분, 실제 화면 사진 포함). 개발환경 페이지에 "Claude Code 를 쓰는 방법·왜 VS Code 와 터미널인가·방법별 설치"와 "만들기 전에 Claude Code 와 계획하기" 추가.

## 2026-10-12 보이는 이름 변경, 기한·일정에서 카드로 가기

- 교사 결정: 보이는 이름을 "coolwatch" → "쿨메신저 보조도구"로. 화면 제목·상표, 트레이 글자, 설치 안내, 바탕화면 바로가기, 사이트와 문서의 글을 바꿈. **폴더(`C:\coolwatch`, `%LOCALAPPDATA%\coolwatch`), 파일 이름, 압축 파일(`coolwatch.zip`), 사이트 주소(`/coolwatch/`), 자동 실행 바로가기 이름은 그대로**(링크와 기존 설치가 깨지지 않게). `app.py` 의 `PANEL_TITLE` 과 `ui_page.html` 의 `<title>` 은 늘 같아야 함(창 찾기에 씀).
- '다가오는 기한 · 일정'의 줄을 누르면(또는 Enter) 그 업무 카드로 이동하고 테두리가 깜빡임. 탭이나 검색어 때문에 카드가 안 보이면 '남은 업무'로 돌린 뒤 찾음(`gotoCard`, 카드에 `data-card`).
- 발표자료: 구조(프론트엔드·백엔드·데이터·배포)를 틀로 Claude Code 와 계획하는 내용으로 15장, 본문은 개조식, 일곱 장을 모식도로.
- 첨부 열기(2026-10-12): 카드의 첨부 이름을 누르면 받은 파일 폴더에서 같은 이름(또는 `이름 (1)`, `이름_1`)을 찾아 엶. 폴더는 `attach_dirs` 설정 → 레지스트리 `HKCU\Software\Jiransoft\CoolMsg50\Option\GetFile\DownPath`, `…\DeskTop\MsgDownloadPath` → `문서\CoolMessenger Files\Received Files`, `다운로드`. 이름은 그 메시지의 FilePath 에 있는 것만 받음(경로는 화면에서 안 받음). 실행 파일 종류는 폴더에서 보여 주기만. 상태의 `attach_have` 로 "저장 전" 표시. 없으면 화면이 3초마다 2분간 다시 물어, 저장되는 순간 엶.
- 확인한 사실: FilePath 의 폴더 칸은 보낸 사람 PC 의 경로다(최근 60건 중 이 PC 에 실제로 있던 것은 2건). 쿨메신저에 "받자마자 자동 저장" 설정은 없음(레지스트리·프로그램 글자열 확인). 파일 전송은 CoolFile2.dll 의 자체 소켓 방식이고, 화면은 CEF 인데 밖에서 조작할 통로(원격 디버깅 포트)가 없음. 그래서 **저장 자동화는 넣지 않음**: 서버에 비공식 접속을 하거나 쿨메신저 창을 대신 눌러야 하는데, 앞은 학교 서버·계정에 위험하고 뒤는 읽음 표시가 바뀌고 화면을 빼앗음.
- 첨부 저장 대신 누르기(2026-10-12, 교사가 강하게 요청): `cm_save.py`. 메시지 관리함 창(목록 번호 3195)에서 그 글을 고르고(목록에 HOME/DOWN 신호), 화면의 첨부 줄 글자가 받으려는 파일 이름과 맞는지 확인한 뒤 '모든파일 저장 (Ctrl+S)' 단추(번호 3320, 글자 확인)에 BM_CLICK. 마우스·키보드는 안 움직임. 진짜 쿨메신저 DB 일 때만 동작(`real_db`), 가짜·시연 DB 로는 쿨메신저를 건드리지 않음. 교사가 직접 돌린 시험에서 첨부 8개가 1초 만에 받은 파일 폴더에 생김. 부작용: 그 글(그리고 내려가며 지나친 글)이 읽음으로 바뀜, 창이 그 글로 넘어감. 목록 30번째 아래는 하지 않음. 카드에서 '저장 전' 첨부를 누르면 이것을 부르고 저장되면 엶. 새 글 자동 저장은 설정 `attach_autosave`(기본 꺼짐). 쿨메신저가 업데이트되어 번호가 바뀌면 깨질 수 있음 → `python cm_save.py --try --look` 으로 점검.
- 이 환경의 자동 권한 판정은 다른 프로그램에 입력을 보내는 실행을 막음. 그런 시험은 교사가 `! 명령` 으로 직접 돌림.

## 2026-10-14 첨부 저장을 '줄 누르기' 방식으로, 안내 자료 정리

- `cm_save.select_row`: 목록에 HOME/DOWN 신호를 보내는 방식은 쿨메신저 목록에서 먹히지 않았음(성공으로 보인 것은 그 글이 이미 떠 있던 경우). 지금은 그 줄을 맨 위로 올린 뒤(LVM_ENSUREVISIBLE) 그 자리에 누름 신호를 보내 고르고, LVM_GETNEXTITEM 으로 실제로 골라졌는지 확인함. 별표 칸을 피해 보낸사람 칸을 누름. 지나친 글이 읽음으로 바뀌지 않음. 이미 그 줄이 골라져 있는데 화면이 옛 글이면 옆 줄을 거쳐 다시 고름.
- 교사가 직접 돌린 시험: 목록 8번째 줄의 글을 찾아 저장, 0.5초 만에 파일 생김. 새 글 자동 저장은 세 번(1.5·3·5초 뒤)까지 시도, 밀린 글은 글마다 세 번까지.
- 안내 자료(설명서, 사용안내, README, CLAUDE.md)를 여기에 맞춤. "쿨메신저는 읽기만 한다"는 설명은 "기록 파일은 읽기만, 첨부 자동 저장은 저장 단추를 대신 누름"으로 바로잡음.

## 2026-10-14 연수 자료 전체 정리 (교사 결정: 실습의 핵심은 수행평가 페이지로 Claude Code 에 입문하는 것)

- 사이트 구성: 연수 전(준비, 가입과 설치 따라 하기) → 연수 날(실습: Claude Code 첫걸음, 수행평가 페이지) → 자료(Claude Code와 일하는 법 = 옛 개발환경, 쿨메신저 보조도구).
- 연수 전에 꼭: Claude 구독 확인, Claude Code 설치·로그인, VS Code 설치, 본보기 폴더를 문서 폴더에 받아 VS Code 로 열어 보기. 모두 붙여넣는 명령으로 제공(`site/prep`). GitHub 가입과 Git·Node·Python 은 연수 뒤(내 수업용으로 설치할 때).
- 실습은 VS Code → 그 안의 터미널 → `claude`. 일곱 단계(켠다, 읽게 한다, 구조를 묻는다, 고치게 한다, 확인한다, 되돌린다, 계획한다).
- 화면 그림은 실제 캡처가 아니라 본떠 그린 것(`site/assets/screens.css`). Claude Code 문구는 설치된 2.1.296 에서 확인. GitHub 가입 화면과 설치 직후 출력은 확인하지 못하고 그림.
- 발표자료 17장: 표지, 순서, 네 층, 계획 대화, 층별 구현 8장, 고치기, 보조도구, 시연, 실습, 연수 뒤에. 순서 장의 노트에 진행표.
- (같은 날) 교사 지적: 카드가 겹친다. 사이트를 다섯 장으로 다시 묶음. 연수 전 준비(옛 준비 + 옛 가입과 설치 따라 하기의 연수 전 부분: 터미널, Claude Code 설치, 로그인, VS Code·본보기) / 실습 / 수행평가 페이지(연수 뒤 설치에 필요한 GitHub 가입·도구 설치·폴더 구성·배포 규칙을 여기로) / 발표 정리: 구조와 계획(옛 Claude Code와 일하는 법에서 겹치는 것 뺌) / 쿨메신저 보조도구. `site/setup/` 은 준비로 넘기는 빈 페이지. 원칙: 각 내용은 쓰이는 곳 한 군데에만.
- 발표자료 15장: 네 층과 이 프로젝트를 한 장으로, 프론트엔드 두 장을 한 장으로 합침.
- (2026-10-15) 교사 결정: 연수 전에는 VS Code 설치와 Claude Code 설치·로그인만. 본보기 폴더 받기는 실습 첫 단계로 옮김(명령 네 줄). 준비 페이지 체크 3개.
