# check_recent.py - 실제 DB에서 최근 N건을 읽기 전용으로 조회하고 정리 결과를 화면에만 보여 줍니다. (파일 저장 없음)
# 사용: python check_recent.py [건수] [--claude]    (기본 5건, --claude 를 붙이면 Claude 요약도 같이 보여 줌)
import pathlib, sqlite3, sys

from common import load_config, PHONE, attachment_names
from summarize import summarize_rules, summarize_claude, strip_quote


def main():
    nums = [a for a in sys.argv[1:] if a.isdigit()]
    n = int(nums[0]) if nums else 5
    use_claude = "--claude" in sys.argv
    cfg = load_config()
    db = pathlib.Path(cfg["db_path"])
    con = sqlite3.connect(db.as_uri() + "?mode=ro", uri=True, timeout=2)
    try:
        rows = con.execute(
            """SELECT MessageKey, Sender, Title, MessageText, ReceiveDate, FilePath, MessageType
               FROM tbl_recv WHERE (DeletedDate IS NULL OR DeletedDate='')
               ORDER BY MessageKey DESC LIMIT ?""", (n,)).fetchall()
    finally:
        con.close()
    for key, sender, title, text, rdate, fpath, mtype in reversed(rows):
        text = PHONE.sub("[전화번호]", (text or "").strip())
        title = PHONE.sub("[전화번호]", (title or "").strip())
        attach = ", ".join(attachment_names(fpath))
        excl = [w for w in cfg["exclude_words"] if w in title + text]
        s = summarize_rules(title, text, rdate or "", attach, cfg)
        print(f"=== #{key} | Type {mtype} | {rdate} | 발신 {sender} | 제외단어: {excl or '없음'}")
        print(f"제목: {title[:80]}")
        print(f"원문({len(text)}자): {text[:400]!r}")
        print(f"→ 요청사항: {s['요청사항']}\n→ 기한: {s['기한']}\n→ 일정: {s['일정']}\n→ 준비물: {s['준비물']}")
        if use_claude:   # 연동 프로그램과 같은 방식(인용 제외 후 claude -p)으로 요약
            try:
                c = summarize_claude(title, strip_quote(text), rdate or "", attach,
                                     cfg.get("claude_cmd", "claude"), cfg.get("claude_timeout_sec", 90), cfg)
                print(f"[Claude] 짧은제목: {c['짧은제목']} | 관련: {c['관련']} | 대상: {c['대상']}")
                print(f"[Claude] 요약: {c['한줄요약']}")
                print(f"[Claude] 요청사항: {c['요청사항']}\n[Claude] 기한: {c['기한']} ({c['기한일'] or '-'})"
                      f"\n[Claude] 일정: {c['일정']} ({c['일정일'] or '-'})")
            except Exception as e:  # 파일 없음, 시간 초과, 응답 형식 오류 등
                print(f"[Claude] 요약 실패: {type(e).__name__}")
        print()


if __name__ == "__main__":
    main()
