@echo off
rem coolwatch installer (claude): just double-click this file (no administrator rights needed)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install.ps1" -Mode claude
echo.
pause
