# common.py - 설정·경로·파일 읽고 쓰기 (연동 프로그램과 화면이 함께 씁니다)
import json, os, pathlib, re, tempfile, time
from datetime import datetime

BASE = pathlib.Path(__file__).resolve().parent
VERSION = "1.0.0"
DEFAULT_CONFIG = BASE / "config.json"

DEFAULTS = {
    "db_path": "fake/test.udb",        # 실제 DB로 바꿀 때는 이 한 줄만 교사가 직접 수정
    "record_all": False,                # True면 화이트리스트 없이 모든 발신자를 기록
    "whitelist": [],                    # 발신자 ID 목록 (화면에서는 이름으로 보임)
    "exclude_words": ["상담", "학부모", "생활기록", "성적", "결석"],
    "my_roles": [],                     # 내 역할 (예: "1학년 담임", "영어과", "인문사회부") → '나와 관련' 표시에 사용
    "my_name": "",                      # 비워 두면 DB 파일 이름(예: 홍길동.udb)에서 가져옴
    "poll_sec": 15,
    "data_dir": "data",                 # 상태·로그·오늘 목록
    "inbox_dir": "inbox",               # 정리된 md 파일
    "summary_mode": "rules",            # rules(PC 안에서 규칙) 또는 claude(claude -p 호출)
    "claude_cmd": "claude",
    "claude_timeout_sec": 90,
    "claude_model": "haiku",            # haiku(가벼움, 권장) / sonnet / opus. 짧은 업무 글 정리는 haiku로 충분
    "claude_effort": "low",             # low(권장) / medium / high. 높일수록 생각에 토큰을 더 씀
    "claude_min_chars": 30,             # 이보다 짧은 글(첨부 없음)은 Claude를 부르지 않고 규칙으로 정리
    "claude_daily_limit": 200,          # 하루에 Claude를 부르는 최대 횟수 (넘으면 규칙으로 정리)
    "claude_cooldown_sec": 600,         # Claude가 실패(사용 한도 등)하면 이 시간 동안은 규칙으로 정리
    "ui_theme": "crimson",              # 화면 강조색: crimson / blue / green / violet / orange / ink
    "ui_mode": "auto",                  # 화면 밝기: auto(Windows 설정을 따름) / light / dark
    "keep_original": True,              # md에 원문도 접어서 남길지
    "notion_enabled": False,            # True면 정리된 메시지를 노션 '받은 업무함'에도 올림
    "notion_mode": "auto",              # auto(키 있으면 api, 없으면 claude) / api / claude
    "notion_database_id": "",
    "notion_data_source_id": "",
    "notion_model": "haiku",
    "notion_timeout_sec": 150,
    "notion_mcp_wait_sec": 12,          # claude 연결 방식: 노션 연결이 붙을 때까지 기다리는 시간
    "notion_retry_sec": 60,             # 노션 전송 실패 시 다시 시도하기까지 (초)
    "notion_url": "",                   # 노션 받은 업무함 주소 (화면의 '노션 열기' 버튼)
    "ui_port": 8765,
    "window_mode": "panel",             # panel(화면 오른쪽의 작은 전용 창, Edge 사용) 또는 browser(브라우저 탭)
    "panel_width": 440,
    "setup_done": False,                # 처음 설정을 마쳤는지 (False면 화면 맨 위에 '처음 설정' 안내가 보임)
    "notion_template_url": "",          # 복제해 갈 '받은 업무함' 템플릿 주소 (배포하는 사람이 넣어 둠)
    "manual_url": "",                   # 사용 설명서 주소
    "tray_dot": True,                  # 아직 안 본 새 글이 있으면 트레이 아이콘에 작은 점 (팝업·소리는 없음)
}

PHONE = re.compile(r"01[016789][-\s.]?\d{3,4}[-\s.]?\d{4}")   # 휴대폰 번호는 가려서 기록


def connect_ro(db, timeout=1):
    """원본 DB를 읽기 전용으로 엶. 쿨메신저가 꺼져 있어 -wal 파일이 없을 때는 immutable 로 엽니다.
    (읽기 전용이어도 SQLite는 -wal/-shm 두 파일을 새로 만들기 때문. 쿨메신저 폴더에 아무것도 만들지 않으려는 것)"""
    import sqlite3
    db = pathlib.Path(db)
    running = db.with_name(db.name + "-wal").exists()
    return sqlite3.connect(db.as_uri() + ("?mode=ro" if running else "?mode=ro&immutable=1"), uri=True, timeout=timeout)


_net = {}   # 호스트 -> (확인한 때, 연결 여부)


def online(cfg, host, ttl=20, timeout=2):
    """인터넷(그 서비스)에 지금 닿는지 가볍게 확인. 교실을 옮겨 다니며 망이 끊겼다 붙는 상황에서,
    안 될 일을 시도하다 실패하는 대신 미리 알고 미뤄 두려는 것. 결과는 잠깐 기억해 둠."""
    if cfg.get("simulate_offline") is not None:   # 시험용: 끊긴 상황 흉내
        return not cfg["simulate_offline"]
    import socket
    now = time.time()
    hit = _net.get(host)
    if hit and now - hit[0] < ttl:
        return hit[1]
    try:
        socket.create_connection((host, 443), timeout=timeout).close()
        ok = True
    except OSError:
        ok = False
    _net[host] = (now, ok)
    return ok


def find_claude(cmd="claude"):
    """claude 프로그램의 위치. 방금 설치해서 아직 PATH에 안 잡힌 경우도 찾음. 없으면 None"""
    import shutil
    hit = shutil.which(cmd)
    if hit or cmd != "claude":
        return hit
    for p in (r"%USERPROFILE%\.local\bin\claude.exe", r"%APPDATA%\npm\claude.cmd"):
        p = os.path.expandvars(p)
        if os.path.exists(p):
            return p
    return None


def attachment_names(file_path):
    """쿨메신저 FilePath '|개수|크기;크기|폴더|파일이름|번호|폴더|파일이름|번호|' -> ['파일이름', ...]
    (폴더는 보낸 사람 PC의 경로라 쓰지 않습니다. 평범한 경로 한 개도 받습니다.)"""
    fp = (file_path or "").strip()
    if not fp:
        return []
    t = fp.split("|")
    if len(t) >= 6 and t[0] == "" and t[1].isdigit():
        names = [t[i].strip() for i in range(4, len(t), 3) if t[i].strip()]
        if names:
            return list(dict.fromkeys(names))
    return [os.path.basename(fp.replace("\\", "/"))]


class Paths:
    """설정 파일 하나로 모든 경로가 정해집니다. (시험은 fake/config.json 사용)"""

    def __init__(self, config_path=None):
        self.config_path = pathlib.Path(config_path or DEFAULT_CONFIG).resolve()
        self.root = self.config_path.parent if self.config_path.parent != BASE else BASE

    def rel(self, p):
        p = pathlib.Path(os.path.expandvars(str(p)))
        return p if p.is_absolute() else (self.root / p)

    def cfg(self):
        return load_config(self.config_path)

    def data(self, cfg=None):
        d = self.rel((cfg or self.cfg())["data_dir"])
        d.mkdir(parents=True, exist_ok=True)
        return d

    def inbox(self, cfg=None):
        d = self.rel((cfg or self.cfg())["inbox_dir"])
        d.mkdir(parents=True, exist_ok=True)
        return d

    def db(self, cfg=None):
        return self.rel((cfg or self.cfg())["db_path"])


def write_json(path, obj):
    """임시 파일에 쓴 뒤 바꿔치기해서, 읽는 쪽이 반쯤 쓴 파일을 보지 않게 합니다."""
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        for attempt in range(20):   # Windows: 다른 프로세스가 읽는 순간에는 바꿔치기가 거부될 수 있어 잠깐 기다렸다 다시
            try:
                os.replace(tmp, path)
                break
            except PermissionError:
                if attempt == 19:
                    raise
                time.sleep(0.05)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def read_json(path, default=None):
    try:
        return json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def load_config(path=DEFAULT_CONFIG):
    cfg = dict(DEFAULTS)
    cfg.update(read_json(path, {}) or {})
    if cfg["db_path"] == "auto":   # 이 PC의 쿨메신저 DB를 스스로 찾음 (가장 최근에 쓰인 것)
        found = sorted(pathlib.Path(os.path.expandvars(r"%LOCALAPPDATA%\CoolMessenger\Memo")).glob("*.udb"),
                       key=lambda p: p.stat().st_mtime)
        if found:
            cfg["db_path"] = str(found[-1])
    if not cfg.get("my_name"):
        stem = pathlib.PureWindowsPath(str(cfg["db_path"])).stem
        cfg["my_name"] = "" if stem.lower() == "test" else stem
    return cfg


def save_config(path, cfg):
    write_json(path, cfg)


def log(paths, msg):
    """로그에는 번호와 상태만. 내용·제목·발신자는 남기지 않습니다."""
    with open(paths.data() / "coolwatch.log", "a", encoding="utf-8") as f:
        f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")
