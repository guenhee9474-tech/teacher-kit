# test_notion_api.py - 노션 API 전송 코드를 로컬 가짜 서버로 시험합니다. (실제 노션·실제 키 사용 안 함)
import json, os, threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import notion_sync

got = {}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        got.update(method=self.command, path=self.path, auth=self.headers.get("Authorization"), ver=self.headers.get("Notion-Version"), body=body)
        if os.environ.get("FAKE_FAIL"):
            self.send_response(429); self.end_headers(); return
        out = {"url": "https://www.notion.so/Test-0123456789abcdef0123456789abcdef"}
        if self.path.endswith("/query"):   # 노션에서 바꿔 둔 상태를 돌려줌
            out = {"has_more": False, "results": [
                {"properties": {"메시지키": {"number": 77}, "상태": {"select": {"name": "확인함"}}}},
                {"properties": {"메시지키": {"number": 78}, "상태": {"select": {"name": "해당없음"}}}},
                {"properties": {"메시지키": {"number": 79}, "상태": {"select": None}}}]}
        out = json.dumps(out).encode()
        self.send_response(200); self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out)

    do_PATCH = do_POST


srv = HTTPServer(("127.0.0.1", 0), H)
threading.Thread(target=srv.serve_forever, daemon=True).start()
cfg = {"notion_mode": "api", "notion_database_id": "dbid123", "notion_api_base": f"http://127.0.0.1:{srv.server_port}"}
entry = {"key": 77, "sender": "홍길동", "title": "시험 안내", "when_iso": "2026-10-07T13:30:00+09:00", "attach": "양식.hwpx",
         "original": "원문 " * 800,  # 길이 2000자 초과 → 여러 조각으로 나뉘어야 함
         "summary": {"한줄요약": "요약", "요청사항": ["회신하기"], "기한": ["2026-10-09(금)까지"], "일정": ["10/8 14:00 회의"],
                     "준비물": ["양식.hwpx"], "링크": ["https://example.com/a"], "방식": "Claude"}}
fails = []


def check(name, ok):
    print(("통과  " if ok else "실패  ") + name)
    if not ok: fails.append(name)


notion_sync.get_token = lambda: "secret_test_token"
url = notion_sync.push(cfg, entry)
notion_sync.get_token = notion_sync.__dict__["get_token"]
b = got["body"]; p = b["properties"]
check("페이지 주소를 돌려받음", url.startswith("https://www.notion.so/"))
check("경로/인증/버전 헤더", got["path"] == "/v1/pages" and got["auth"] == "Bearer secret_test_token" and got["ver"] == "2022-06-28")
check("부모가 데이터베이스", b["parent"] == {"database_id": "dbid123"})
check("제목·상태·정리방식·메시지키", p["제목"]["title"][0]["text"]["content"] == "시험 안내" and p["상태"]["select"]["name"] == "미정리"
      and p["정리방식"]["select"]["name"] == "Claude" and p["메시지키"]["number"] == 77)
check("받은시각·기한일 날짜", p["받은시각"]["date"]["start"].startswith("2026-10-07T13:30") and p["기한일"]["date"]["start"] == "2026-10-09")
check("요청사항·링크·첨부 글 칸", "회신하기" in p["요청사항"]["rich_text"][0]["text"]["content"] and "example.com" in p["링크"]["rich_text"][0]["text"]["content"]
      and p["첨부"]["rich_text"][0]["text"]["content"] == "양식.hwpx")
toggle = [c for c in b["children"] if c["type"] == "toggle"][0]["toggle"]["children"]
check("긴 원문이 2000자 이하 조각으로 나뉨", len(toggle) >= 2 and all(len(c["paragraph"]["rich_text"][0]["text"]["content"]) <= 2000 for c in toggle))
check("본문 블록 100개 이하", len(b["children"]) <= 100)
ID = "0a1b2c3d4e5f60718293a4b5c6d7e8f9"   # 지어낸 값
check("페이지 ID: 제목에 숫자가 있어도 정확히 뽑음", all(notion_sync.page_id(u) == ID for u in (
    f"https://www.notion.so/10-8-{ID}", f"https://www.notion.so/2026-12-{ID}?pvs=4", f"https://app.notion.com/p/{ID}?pvs=204",
    f"https://www.notion.so/abc-1-9-{ID[:8]}-{ID[8:12]}-{ID[12:16]}-{ID[16:20]}-{ID[20:]}")))
# ---- 처리 상태: 화면 → 노션, 노션 → 화면 ----
import tempfile, pathlib
import ui_server
from common import write_json, read_json

notion_sync.get_token = lambda: "secret_test_token"
notion_sync.set_status(cfg, f"https://www.notion.so/10-8-{ID}", "처리완료")
check("상태 변경 요청 모양", got["method"] == "PATCH" and got["path"] == f"/v1/pages/{ID}"
      and got["body"] == {"properties": {"상태": {"select": {"name": "처리완료"}}}})
check("노션의 상태 읽기", notion_sync.fetch_statuses(cfg, 70) == {77: "확인함", 78: "해당없음"}
      and got["path"] == "/v1/databases/dbid123/query" and got["body"]["filter"]["number"] == {"greater_than_or_equal_to": 70})
with tempfile.TemporaryDirectory() as tmp:
    tmp = pathlib.Path(tmp)
    write_json(tmp / "config.json", {**cfg, "notion_enabled": True})
    write_json(tmp / "data" / "items.json", {"items": [{"key": 77, "notion_url": f"https://www.notion.so/a-{ID}"},
                                                       {"key": 78, "notion_url": ""}]})
    app = ui_server.App(str(tmp / "config.json"))
    app.set_mark(77, "처리완료")
    app.set_mark(78, "처리완료")      # 아직 노션에 안 올라간 글
    got.clear()
    app.sync_once(pull=False)
    m = read_json(tmp / "data" / "marks.json")
    check("화면에서 누른 완료가 노션으로 감", got.get("method") == "PATCH" and m["77"]["synced"] and not m["78"]["synced"])
    app.sync_once(pull=True)
    m = read_json(tmp / "data" / "marks.json")
    check("방금 보낸 상태는 노션의 옛 값으로 되돌아가지 않음", m["77"]["status"] == "처리완료")
    m["77"]["pushed"] -= 200          # 시간이 지난 뒤
    write_json(tmp / "data" / "marks.json", m)
    app.sync_once(pull=True)
    m = read_json(tmp / "data" / "marks.json")
    check("노션에서 바꾼 상태가 화면으로 옴", m["77"]["status"] == "확인함")
    check("아직 못 보낸 화면의 상태는 덮어쓰지 않음", m["78"]["status"] == "처리완료" and not m["78"]["synced"])

for mode_name, env in (("키 없음", None), ("서버 오류(429)", "1")):
    real_get = notion_sync.get_token
    if env is None: notion_sync.get_token = lambda: ""        # PC에 실제 키가 있어도 '없는 상황'으로 시험
    else: os.environ["FAKE_FAIL"] = "1"; notion_sync.get_token = lambda: "x"
    try:
        notion_sync.push({**cfg, "notion_mode": "api"}, entry); check(f"{mode_name}이면 예외", False)
    except Exception as e:
        check(f"{mode_name}이면 예외({type(e).__name__})", True)
    notion_sync.get_token = real_get
srv.shutdown()
print("\n모두 통과" if not fails else f"\n실패 {len(fails)}건")
raise SystemExit(1 if fails else 0)
