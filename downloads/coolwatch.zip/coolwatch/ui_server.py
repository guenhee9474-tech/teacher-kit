# ui_server.py - 127.0.0.1 에서만 열리는 화면 (표준 라이브러리 http.server)
import hashlib, json, os, re, secrets, shutil, sqlite3, subprocess, threading, time, urllib.error, urllib.request, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from common import Paths, read_json, write_json, save_config, log, BASE, PHONE, VERSION, connect_ro, online, find_claude
import notion_sync, summarize
from notion_sync import STATUSES

THEMES = ("crimson", "blue", "green", "violet", "orange", "ink")   # 화면 강조색 (ui_page.html 의 data-theme 과 같게)
UI_MODES = ("auto", "light", "dark")

PAGE = (BASE / "ui_page.html")
MD_NAME = re.compile(r"^\d{4}-\d{2}-\d{2}\.md$")
NEED_PROPS = ["제목", "상태", "발신자", "받은시각", "요약", "요청사항", "기한", "기한일", "일정", "일정일",
              "링크", "첨부", "정리방식", "메시지키", "관련", "대상"]


def pid_alive(pid):
    if not pid:
        return False
    if os.name == "nt":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))  # QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def current_status(paths):
    """연동 프로그램 상태를 화면용으로 정리: watching / paused / error / stopped"""
    cfg = paths.cfg()
    st = read_json(paths.data(cfg) / "status.json", {}) or {}
    # 요약·노션 전송 중에는 한 회차가 길어질 수 있어 넉넉히 기다림
    if not st or not pid_alive(st.get("pid")):
        return {"state": "stopped", "detail": "연동 프로그램이 꺼져 있습니다", "last_check": 0}
    if time.time() - st.get("updated", 0) > max(600, cfg["poll_sec"] * 4):   # 살아는 있는데 10분째 소식이 없음
        return {"state": "error", "detail": "연동 프로그램이 응답하지 않습니다. 트레이 메뉴에서 연동까지 끄고 다시 켜 주세요", "last_check": 0}
    return {"state": st["state"], "detail": st.get("detail", ""), "last_check": st.get("last_check", 0),
            "messenger": st.get("messenger", True), "online": st.get("online", True)}


def member_col(cfg):
    return "MemberID" if cfg.get("member_id_column") == "MemberID" else "K_MemberID"


def db_members(paths, cfg, q=None, ids=None):
    """교직원 명단을 읽기 전용으로 짧게 조회 (이름 검색 / ID→이름)"""
    db = paths.db(cfg)
    col = member_col(cfg)
    try:
        con = connect_ro(db)
    except sqlite3.Error:
        return []
    try:
        if q is not None:
            rows = con.execute(f"SELECT {col}, MemberName FROM tbl_member WHERE MemberName LIKE ? ORDER BY MemberName LIMIT 30",
                               (f"%{q}%",)).fetchall()
        elif ids:
            ph = ",".join("?" * len(ids))
            rows = con.execute(f"SELECT {col}, MemberName FROM tbl_member WHERE CAST({col} AS TEXT) IN ({ph})",
                               [str(i) for i in ids]).fetchall()
        else:
            rows = []
        return [(str(a), b) for a, b in rows]
    except sqlite3.Error:
        return []
    finally:
        con.close()


def check_notion(cfg, token):
    """키로 '받은 업무함'에 접근되는지 확인. 반환: (성공 여부, 사람이 읽을 메시지)"""
    req = urllib.request.Request(
        cfg.get("notion_api_base", "https://api.notion.com") + f"/v1/databases/{cfg.get('notion_database_id')}",
        headers={"Authorization": f"Bearer {token}", "Notion-Version": notion_sync.NOTION_VERSION})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            have = set(json.loads(r.read()).get("properties", {}))
    except urllib.error.HTTPError as e:
        return False, {401: "키가 올바르지 않습니다.",
                       404: "'받은 업무함'에 이 통합이 연결되지 않았습니다. 노션에서 받은 업무함 → ··· → 연결 → 통합을 추가하세요."
                       }.get(e.code, f"노션이 거부했습니다 (HTTP {e.code}).")
    except OSError:
        return False, "노션에 접속하지 못했습니다. 인터넷 연결을 확인하세요."
    missing = [n for n in NEED_PROPS if n not in have]
    if missing:
        return False, "데이터베이스에 없는 속성: " + ", ".join(missing)
    return True, "연결되었습니다. 이제 노션 API로 바로 올립니다."


class App:
    def __init__(self, config_path=None):
        self.paths = Paths(config_path)
        self.token = secrets.token_urlsafe(16)
        self.lock = threading.Lock()
        self.wake = threading.Event()   # 상태를 바꾸면 노션 맞추기를 바로 깨움
        self.last_view = 0              # 화면이 마지막으로 상태를 물어본 때
        self.last_pull = 0              # 노션의 상태를 마지막으로 읽어 온 때
        self.push_retry_at = 0          # 노션에 상태를 보내다 실패하면 이때까지 쉼

    def page_version(self):
        """프로그램을 다시 켜거나 화면 파일이 바뀌면 달라지는 값. 열려 있던 창이 이걸 보고 스스로 새로 고침
        (예전 토큰을 든 채 남아 있으면 버튼이 모두 거절되므로)"""
        return hashlib.sha256(self.token.encode()).hexdigest()[:10] + f"-{int(PAGE.stat().st_mtime)}"

    # ----- 처리 상태 (data/marks.json: 화면 프로그램만 씀. 카드 목록은 연동 프로그램만 씀) -----
    def marks(self, cfg=None):
        return read_json(self.paths.data(cfg) / "marks.json", {}) or {}

    def set_mark(self, key, status):
        if status not in STATUSES:
            raise KeyError(status)
        with self.lock:
            marks = self.marks()
            marks[str(int(key))] = {"status": status, "synced": False, "t": time.time()}
            write_json(self.paths.data() / "marks.json", marks)
        self.wake.set()

    def sync_once(self, pull=True):
        """화면에서 바꾼 상태 → 노션, 노션에서 바꾼 상태 → 화면. (노션 API 키 방식일 때만)"""
        cfg = self.paths.cfg()
        if not cfg.get("notion_enabled") or notion_sync.resolve_mode(cfg) != "api":
            return
        if not online(cfg, "api.notion.com"):   # 끊겨 있으면 조용히 기다림 (화면에서 누른 상태는 남아 있다가 연결되면 올라감)
            return
        items = {i.get("key"): i for i in self.items(cfg)}
        path = self.paths.data(cfg) / "marks.json"
        for k, m in list(self.marks(cfg).items()) if time.time() >= self.push_retry_at else []:
            it = items.get(int(k))
            if m.get("synced") or not it or not it.get("notion_url"):
                continue   # 아직 노션에 안 올라간 글은 올라간 뒤에 맞춤
            try:
                notion_sync.set_status(cfg, it["notion_url"], m["status"])
            except Exception as e:   # 접속 끊김 등: 1분 뒤에 다시 (화면의 상태는 그대로 유지)
                log(self.paths, f"{k}번 노션 상태 변경 실패({notion_sync.describe(e)})")
                self.push_retry_at = time.time() + cfg.get("notion_retry_sec", 60)
                break
            with self.lock:
                marks = self.marks(cfg)
                if (marks.get(k) or {}).get("t") == m.get("t"):   # 보내는 사이에 또 바꾸지 않았을 때만
                    marks[k].update(synced=True, pushed=time.time())
                    write_json(path, marks)
        if not pull or not items:
            return
        remote = notion_sync.fetch_statuses(cfg, min(items))
        with self.lock:
            marks, changed = self.marks(cfg), False
            for k, st in remote.items():
                cur = marks.get(str(k))
                if k not in items or st not in STATUSES or (cur and not cur.get("synced")):
                    continue   # 화면에서 방금 바꾼 것(아직 안 보낸 것)이 우선
                if cur and time.time() - cur.get("pushed", 0) < 90:
                    continue   # 방금 보낸 것은 노션 목록에 늦게 반영될 수 있어, 옛 값으로 되돌아가지 않게 잠깐 기다림
                if (cur or {}).get("status", "미정리") != st:
                    marks[str(k)] = {"status": st, "synced": True, "t": time.time()}
                    changed = True
            if changed:
                write_json(path, marks)

    def sync_loop(self):
        while True:
            self.wake.wait(20)
            self.wake.clear()
            try:
                # 노션 쪽 변경은 화면을 보고 있을 때만 1분마다 읽어 옴
                pull = time.time() - self.last_view < 120 and time.time() - self.last_pull >= 60
                self.sync_once(pull)
                if pull:
                    self.last_pull = time.time()
            except Exception as e:   # 접속 끊김 등: 다음 회차에 다시
                self.last_pull = time.time()
                log(self.paths, f"노션 상태 맞추기 실패({notion_sync.describe(e)})")

    # ----- 아직 안 본 새 글 (트레이 아이콘의 점) -----
    def seen_key(self, cfg, items):
        d = read_json(self.paths.data(cfg) / "seen.json")
        if d is None:   # 처음: 지금 있는 글은 모두 본 것으로
            return self.mark_seen(cfg, items)
        return d.get("key", 0)

    def mark_seen(self, cfg=None, items=None):
        cfg = cfg or self.paths.cfg()
        top = max([i.get("key", 0) for i in (self.items(cfg) if items is None else items)], default=0)
        write_json(self.paths.data(cfg) / "seen.json", {"key": top})
        return top

    def unseen(self):
        cfg = self.paths.cfg()
        items = self.items(cfg)
        seen = self.seen_key(cfg, items)
        return sum(1 for i in items if i.get("key", 0) > seen)

    def original(self, key):
        """카드에 있는 글의 원문을 그 자리에서 읽기 전용으로 짧게 조회 (전화번호는 가림, 어디에도 저장하지 않음)"""
        cfg = self.paths.cfg()
        if not any(i.get("key") == key for i in self.items(cfg)):
            raise KeyError(key)
        row = None
        try:
            con = connect_ro(self.paths.db(cfg))
            try:
                row = con.execute("SELECT MessageText FROM tbl_recv WHERE MessageKey = ?", (key,)).fetchone()
            finally:
                con.close()
        except sqlite3.Error:
            pass
        return {"found": row is not None, "text": PHONE.sub("[전화번호]", (row[0] or "").strip()) if row else ""}

    def items(self, cfg):
        d = read_json(self.paths.data(cfg) / "items.json")
        if d is None:
            old = read_json(self.paths.data(cfg) / "today.json", {}) or {}
            return [{**i, "date": old.get("date", "")} for i in old.get("items", [])]
        return d.get("items", [])

    def state(self):
        cfg = self.paths.cfg()
        if time.time() - self.last_view > 120:   # 오랜만에 화면을 열면 노션의 상태를 바로 읽어 옴
            self.last_pull = 0
            self.wake.set()
        self.last_view = time.time()
        marks = self.marks(cfg)
        items = sorted(self.items(cfg), key=lambda i: i.get("key", 0), reverse=True)
        items = [{**i, "status": (marks.get(str(i.get("key"))) or {}).get("status", "미정리")} for i in items]
        seen = self.seen_key(cfg, items)
        day = time.strftime("%Y-%m-%d")
        names = dict(db_members(self.paths, cfg, ids=cfg["whitelist"]))
        ctl = read_json(self.paths.data(cfg) / "control.json", {}) or {}
        pending = read_json(self.paths.data(cfg) / "notion_pending.json", []) or []
        return {
            "status": current_status(self.paths),
            "page_version": self.page_version(),
            "paused": bool(ctl.get("paused")),
            "now": day,
            "items": items[:80],
            "today": [i for i in items if i.get("date") == day],
            "seen_key": seen,
            "unseen": sum(1 for i in items if i.get("key", 0) > seen),
            "whitelist": [{"id": i, "name": names.get(str(i), f"(명단에 없음 {i})")} for i in cfg["whitelist"]],
            "exclude_words": cfg["exclude_words"],
            "my_roles": cfg.get("my_roles") or [],
            "my_name": cfg.get("my_name") or "",
            "summary_mode": cfg["summary_mode"],
            "summary_model": cfg["claude_model"],
            "summary_effort": cfg["claude_effort"],
            "claude_found": bool(find_claude(cfg.get("claude_cmd", "claude"))),
            "version": VERSION,
            "setup_done": bool(cfg.get("setup_done")),
            "db_found": self.paths.db(cfg).exists(),
            "notion_db_set": bool(cfg.get("notion_database_id")),
            "notion_template_url": cfg.get("notion_template_url", ""),
            "manual_url": cfg.get("manual_url", ""),
            "usage": self.usage(cfg),
            "ui_theme": cfg["ui_theme"] if cfg["ui_theme"] in THEMES else THEMES[0],
            "ui_mode": cfg["ui_mode"] if cfg["ui_mode"] in UI_MODES else UI_MODES[0],
            "record_all": bool(cfg.get("record_all")),
            "notion_on": bool(cfg.get("notion_enabled")),
            "notion_pending": len(pending) if cfg.get("notion_enabled") else 0,
            "notion_pending_keys": [e.get("key") for e in pending],
            "notion_mode": notion_sync.resolve_mode(cfg) if cfg.get("notion_enabled") else "",
            "notion_has_token": bool(notion_sync.get_token()),
            "notion_url": cfg.get("notion_url", ""),
            "backfilling": int(ctl.get("backfill") or 0),
        }

    def usage(self, cfg):
        """오늘 Claude 요약을 부른 횟수와 토큰 (연동 프로그램이 data/usage.json 에 적어 둠)"""
        d = read_json(self.paths.data(cfg) / "usage.json", {}) or {}
        today = d.get("date") == time.strftime("%Y-%m-%d")
        return {"calls": d.get("calls", 0) if today else 0, "tokens": d.get("tokens", 0) if today else 0,
                "limit": cfg.get("claude_daily_limit", 200)}

    def claude_status(self):
        """처음 설정용: claude 가 설치되어 있는지, 로그인되어 있는지, 어떤 요금제인지 (계정 메일 등은 읽지 않음)"""
        exe = find_claude(self.paths.cfg().get("claude_cmd", "claude"))
        if not exe:
            return {"installed": False, "logged_in": False, "plan": ""}
        try:
            r = subprocess.run([exe, "auth", "status", "--json"], capture_output=True, text=True, encoding="utf-8", timeout=30,
                               creationflags=0x08000000 if os.name == "nt" else 0)
            d = json.loads(r.stdout)
            return {"installed": True, "logged_in": bool(d.get("loggedIn")), "plan": str(d.get("subscriptionType") or "")}
        except (OSError, ValueError, subprocess.SubprocessError):
            return {"installed": True, "logged_in": False, "plan": ""}

    def open_console(self, what):
        """Claude 설치·로그인은 사용자가 진행을 볼 수 있게 보이는 창에서 실행 (명령은 정해진 두 가지뿐)"""
        if what == "install":   # Anthropic 공식 설치 명령 (관리자 권한 불필요)
            cmd = "irm https://claude.ai/install.ps1 | iex; Write-Host ''; Write-Host '설치가 끝났으면 이 창을 닫고, coolwatch 화면에서 [다시 확인]을 누르세요.'"
        elif what == "login":
            exe = find_claude(self.paths.cfg().get("claude_cmd", "claude"))
            if not exe:
                raise KeyError(what)
            cmd = f"& '{exe}' auth login; Write-Host ''; Write-Host '로그인이 끝났으면 이 창을 닫고, coolwatch 화면에서 [다시 확인]을 누르세요.'"
        else:
            raise KeyError(what)
        subprocess.Popen(["powershell", "-NoExit", "-ExecutionPolicy", "Bypass", "-Command", cmd], creationflags=0x00000010)   # 새 창

    def set_notion_db(self, url):
        """노션 '받은 업무함' 주소를 붙여 넣으면 ID를 뽑아 저장"""
        m = re.search(r"([0-9a-f]{32})", url.split("?")[0].replace("-", ""))
        if not m:
            return False, "주소에서 데이터베이스 ID를 찾지 못했습니다. 노션에서 받은 업무함을 열고 주소창의 주소를 그대로 붙여 넣어 주세요."
        self.edit_config(lambda cfg: cfg.update(notion_database_id=m.group(1), notion_url=url.split("?")[0], notion_mode="api"))
        return True, "저장했습니다. 이제 아래에 API 키를 넣고 저장하면 연결을 확인합니다."

    def set_control(self, **kw):
        p = self.paths.data() / "control.json"
        with self.lock:
            ctl = read_json(p, {}) or {}
            ctl.update(kw)
            write_json(p, ctl)

    def edit_config(self, fn):
        with self.lock:
            cfg = read_json(self.paths.config_path, {}) or {}
            full = self.paths.cfg()
            for k in ("whitelist", "exclude_words", "summary_mode", "my_roles"):
                cfg.setdefault(k, full[k])
            fn(cfg)
            save_config(self.paths.config_path, cfg)

    def toggle_list(self, key, value, on):
        value = str(value).strip()

        def fn(cfg):
            rest = [str(x) for x in cfg[key] if str(x) != value]
            cfg[key] = rest + [value] if on and value else rest
        self.edit_config(fn)

    def save_token(self, token):
        cfg = self.paths.cfg()
        ok, msg = check_notion(cfg, token)
        if ok:
            if os.name == "nt":   # 키는 파일이 아니라 Windows 사용자 환경변수에만 저장
                subprocess.run(["setx", "NOTION_TOKEN", token], capture_output=True, check=True, creationflags=0x08000000)
            os.environ["NOTION_TOKEN"] = token
            self.edit_config(lambda c: c.update(notion_enabled=True))   # 연결이 확인되면 바로 올리기 시작
        return ok, msg


def make_handler(app, port):
    allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):  # 콘솔에 아무것도 찍지 않음
            pass

        def _ok_host(self):
            return self.headers.get("Host", "") in allowed_hosts  # 다른 사이트의 접근(DNS 리바인딩) 차단

        def _send(self, code, body, ctype="application/json; charset=utf-8"):
            data = body if isinstance(body, bytes) else body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if not self._ok_host():
                return self._send(403, "{}")
            u = urlparse(self.path)
            if u.path == "/":
                st = app.state()   # 처음 그릴 때부터 고른 색으로 (깜빡임 없이)
                html = (PAGE.read_text(encoding="utf-8").replace("__TOKEN__", app.token).replace("__VER__", app.page_version())
                        .replace("__THEME__", st["ui_theme"]).replace("__MODE__", st["ui_mode"]))
                return self._send(200, html, "text/html; charset=utf-8")
            if u.path == "/api/state":
                return self._send(200, json.dumps(app.state(), ensure_ascii=False))
            if u.path == "/api/members":
                q = (parse_qs(u.query).get("q") or [""])[0].strip()
                cfg = app.paths.cfg()
                if not q:
                    return self._send(200, "[]")
                wl = {str(i) for i in cfg["whitelist"]}
                out = [{"id": i, "name": n, "on": i in wl} for i, n in db_members(app.paths, cfg, q=q)]
                return self._send(200, json.dumps(out, ensure_ascii=False))
            if u.path == "/api/setup":   # 처음 설정 화면이 누를 때만 확인 (claude 를 한 번 실행하므로 조금 걸림)
                return self._send(200, json.dumps(app.claude_status(), ensure_ascii=False))
            if u.path == "/api/original":   # 원문은 이 화면에서 연 요청에만 보여 줌
                if self.headers.get("X-CW-Token") != app.token:
                    return self._send(403, "{}")
                try:
                    out = app.original(int((parse_qs(u.query).get("key") or [""])[0]))
                except (ValueError, KeyError):
                    return self._send(400, "{}")
                return self._send(200, json.dumps(out, ensure_ascii=False))
            self._send(404, "{}")

        def do_POST(self):
            if not self._ok_host() or self.headers.get("X-CW-Token") != app.token:
                return self._send(403, "{}")
            try:
                n = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(n) or b"{}")
                out = self._route(self.path, body) or {}
            except (ValueError, KeyError, OSError, subprocess.SubprocessError):
                return self._send(400, "{}")
            self._send(200, json.dumps(out, ensure_ascii=False))

        def _route(self, path, b):
            if path == "/api/whitelist":
                app.toggle_list("whitelist", b["id"], bool(b["on"]))
            elif path == "/api/exclude":
                app.toggle_list("exclude_words", b["word"], bool(b["on"]))
            elif path == "/api/roles":
                app.toggle_list("my_roles", b["role"], bool(b["on"]))
            elif path == "/api/control":
                a = b["action"]
                if a == "pause":
                    app.set_control(paused=True)
                elif a == "resume":
                    app.set_control(paused=False)
                elif a == "reset_error":
                    app.set_control(reset_error=True, paused=False)
                else:
                    raise KeyError(a)
            elif path == "/api/mark":
                app.set_mark(int(b["key"]), b["status"])
            elif path == "/api/seen":
                app.mark_seen()
            elif path == "/api/backfill":
                app.set_control(backfill=max(1, min(int(b.get("n", 10)), 50)), redo=bool(b.get("redo")))
            elif path == "/api/summary_mode":
                m = b["mode"]
                if m not in ("rules", "claude"):
                    raise KeyError(m)
                app.edit_config(lambda cfg: cfg.__setitem__("summary_mode", m))
            elif path == "/api/claude":
                model, effort = b["model"], b["effort"]
                if model not in summarize.MODELS or effort not in summarize.EFFORTS:
                    raise KeyError(model)
                app.edit_config(lambda cfg: cfg.update(claude_model=model, claude_effort=effort))
            elif path == "/api/ui":
                theme, mode = b["theme"], b["mode"]
                if theme not in THEMES or mode not in UI_MODES:
                    raise KeyError(theme)
                app.edit_config(lambda cfg: cfg.update(ui_theme=theme, ui_mode=mode))
            elif path == "/api/setup_done":
                app.edit_config(lambda cfg: cfg.__setitem__("setup_done", bool(b.get("done", True))))
            elif path == "/api/console":
                app.open_console(b["what"])
            elif path == "/api/notion_db":
                ok, msg = app.set_notion_db(str(b["url"]).strip())
                return {"ok": ok, "message": msg}
            elif path == "/api/record_all":
                v = bool(b["on"])
                app.edit_config(lambda cfg: cfg.__setitem__("record_all", v))
            elif path == "/api/notion_enabled":
                v = bool(b["on"])
                app.edit_config(lambda cfg: cfg.__setitem__("notion_enabled", v))
            elif path == "/api/notion_token":
                ok, msg = app.save_token(str(b["token"]).strip())
                return {"ok": ok, "message": msg}
            elif path == "/api/open":
                what = b["what"]
                if what == "url":   # 바깥 주소는 기본 브라우저로 (전용 창에는 노션 로그인이 없으므로)
                    if not re.match(r"https?://", str(b["url"])):
                        raise KeyError(what)
                    webbrowser.open(str(b["url"]))
                    return
                if what == "inbox":
                    target = app.paths.inbox()
                elif what == "md" and MD_NAME.match(b["file"]):
                    target = app.paths.inbox() / b["file"]
                else:
                    raise KeyError(what)
                if hasattr(os, "startfile") and target.exists():
                    os.startfile(str(target))
            else:
                raise KeyError(path)

    return H


def start(app, port):
    class Quiet(ThreadingHTTPServer):
        def handle_error(self, request, client_address):   # 창을 닫아 연결이 끊긴 것 등은 조용히 넘김
            pass

    srv = Quiet(("127.0.0.1", port), make_handler(app, port))
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    threading.Thread(target=app.sync_loop, daemon=True).start()
    return srv
