# coolwatch

쿨메신저로 받은 업무 메시지를 조용히(팝업·소리 없이) 정리해 주는 학교 PC용 도구입니다.
글마다 할 일·기한·일정을 뽑아 화면 오른쪽의 작은 창에 카드로 보여 주고, 원하면 노션 '받은 업무함'에도 올립니다.

## 그냥 쓰고 싶다면

1. 이 폴더의 **`설치.bat`** 을 더블클릭합니다. (관리자 권한 필요 없음. PC에 파이썬이 없어도 됩니다.)
2. 화면 오른쪽에 창이 열리면 맨 위의 **처음 설정**을 순서대로 확인합니다.

자세한 설명은 `사용안내.md` 또는 배포한 사람이 알려 준 노션 설명서를 보세요.
지울 때는 `제거.bat` 을 실행합니다. 업데이트는 새 폴더에서 `설치.bat` 을 다시 실행하면 됩니다(설정·기록은 유지).

### 알아 둘 것

- 쿨메신저의 기록을 **읽기만** 합니다. 쿨메신저를 바꾸거나 건드리지 않습니다.
- **Claude 요약을 켜면 메시지 본문이 Anthropic으로 전송됩니다.** 처음에는 꺼져 있고, PC 안의 규칙으로 정리합니다.
- 학생·학부모 내용이 든 글은 **제외 단어**로 걸러 기록하지 않습니다. 학교 사정에 맞게 단어를 더 넣어 주세요.
- 프로그램은 `%LOCALAPPDATA%\coolwatch` 에 설치되고, 정리된 기록도 그 안(`data`, `inbox`)에만 있습니다.

## 더 발전시키고 싶다면

이 폴더를 **Claude Code**로 열고 시작하세요.

- `HANDOFF.md`: 지금까지 확인한 사실, 구조, 결정의 까닭, 남은 일. 먼저 읽게 하세요.
- `CLAUDE.md`: 실제 메시지를 다룰 때의 안전 규칙. Claude Code가 자동으로 읽습니다.
- 시험은 실제 쿨메신저 없이 가짜 DB로 합니다.

```
python make_fake_db.py       가짜 쿨메신저 DB 만들기 (fake/)
python test_fake.py          전체 흐름 시험
python test_summarize.py     요약 규칙과 Claude 호출 옵션
python test_notion_api.py    노션 전송 형식 (가짜 서버)
python tools/make_release.py 배포용 압축 파일 만들기 (dist/)
```

| 파일 | 역할 |
|---|---|
| `watcher.py` | 쿨메신저 DB를 읽기 전용으로 확인해 새 글을 정리 (핵심) |
| `summarize.py`, `relevance.py` | 요청사항·기한·일정 요약(Claude 또는 규칙), 나/전체/기타 구분 |
| `notion_sync.py` | 노션 전송과 상태 맞추기 |
| `app.py`, `ui_server.py`, `ui_page.html` | 트레이 아이콘, 작은 전용 창, 설정 화면 |
| `common.py` | 설정·경로·DB 열기·연결 확인 |
| `tools/install.ps1` | 설치 스크립트 (`설치.bat` 이 부름) |

개발용으로 직접 돌릴 때는 `pip install pystray pillow` 뒤 `python app.py` 입니다.
