# make_release.py - 배포용 압축 파일을 dist/ 에 만듭니다.
#  - 개인 설정(config.json), 실제 기록(data, inbox), 예전 참고용 스크립트는 넣지 않습니다.
#  - HANDOFF.md 의 개인 식별 값(노션 ID 등)은 지우고 넣습니다.
#  - 다 만든 뒤 압축 파일 안에 개인 정보가 남아 있는지 검사하고, 남아 있으면 실패합니다.
# 사용: python tools/make_release.py
import json, pathlib, re, sys, zipfile

BASE = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))
from common import VERSION

INCLUDE = ["README.md", "사용안내.md", "HANDOFF.md", "CLAUDE.md", ".gitignore", "config.example.json",
           "설치.bat", "제거.bat", "tools/install.ps1", "tools/make_release.py", ".claude/settings.json",
           "app.py", "common.py", "watcher.py", "summarize.py", "relevance.py", "notion_sync.py", "notion_setup.py",
           "ui_server.py", "ui_page.html", "check_recent.py",
           "make_fake_db.py", "inject_fake_message.py", "test_fake.py", "test_summarize.py", "test_notion_api.py"]


def private_values():
    """이 PC의 개인 설정에서, 배포물에 들어가면 안 되는 값들을 모음"""
    cfg = json.loads((BASE / "config.json").read_text(encoding="utf-8")) if (BASE / "config.json").exists() else {}
    vals = set()
    stem = pathlib.PureWindowsPath(str(cfg.get("db_path", ""))).stem
    if stem and stem.lower() not in ("auto", "test"):
        vals.add(stem)                                        # DB 파일 이름 = 사용자 이름
    for k in ("notion_database_id", "notion_data_source_id", "my_name"):
        if cfg.get(k):
            vals.add(str(cfg[k]))
            vals.add(str(cfg[k]).replace("-", ""))
    return {v for v in vals if len(v) >= 2}


def scrub_handoff(text, private):
    for v in sorted(private, key=len, reverse=True):
        text = text.replace(v, "(지움)")
    text = re.sub(r"\|1\|\d{3,6}\|", "|1|1234|", text)       # 예시로 적힌 실제 발신자 번호
    return text


def main():
    private = private_values()
    out = BASE / "dist" / f"coolwatch-{VERSION}.zip"
    out.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in INCLUDE:
            data = (BASE / rel).read_bytes()
            if rel == "HANDOFF.md":
                data = scrub_handoff(data.decode("utf-8"), private).encode("utf-8")
            z.writestr(f"coolwatch/{rel}", data)
    # 검사: 압축 파일 안에 개인 값·메일 주소·노션 시크릿 모양이 없어야 함
    bad = []
    with zipfile.ZipFile(out) as z:
        for name in z.namelist():
            text = z.read(name).decode("utf-8", "replace")
            for v in private:
                if v in text:
                    bad.append(f"{name}: 개인 값이 남아 있음")
            if re.search(r"[\w.+-]+@(?!anthropic\.com|users\.noreply\.github\.com)[\w-]+(\.[\w-]+)*\.[A-Za-z]{2,}\b", text):
                bad.append(f"{name}: 메일 주소")
            if re.search(r"\b(ntn_|secret_)[A-Za-z0-9]{20,}", text):
                bad.append(f"{name}: 노션 시크릿 모양")
    if bad:
        out.unlink()
        sys.exit("배포 파일을 만들지 않았습니다:\n  " + "\n  ".join(sorted(set(bad))))
    print(f"만들었습니다: {out} ({out.stat().st_size // 1024} KB, 파일 {len(INCLUDE)}개)")


if __name__ == "__main__":
    main()
