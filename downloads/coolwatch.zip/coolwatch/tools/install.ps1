﻿# coolwatch 설치 스크립트 (설치.bat 이 부릅니다)
#  1) 프로그램 파일을 내 PC의 고정된 자리(%LOCALAPPDATA%\coolwatch)에 복사   (다시 실행하면 업데이트: 설정·기록은 그대로)
#  2) 실행에 필요한 파이썬을 그 폴더 안에 따로 준비 (PC에 파이썬이 없어도 됨, 다른 프로그램에 영향 없음)
#  3) 바탕화면 바로가기와 로그온 자동 실행을 만들고 프로그램을 켬
param(
    [string]$Target = (Join-Path $env:LOCALAPPDATA "coolwatch"),
    [switch]$Uninstall,
    [switch]$ForceEmbedded,   # 시험용: PC에 파이썬이 있어도 내려받는 방식으로
    [switch]$NoShortcuts,     # 시험용: 바로가기·자동 실행을 만들지 않음
    [switch]$NoStart          # 시험용: 설치 뒤 프로그램을 켜지 않음
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Source = Split-Path -Parent $PSScriptRoot
$PyVersion = "3.12.10"
$Startup = Join-Path ([Environment]::GetFolderPath("Startup")) "coolwatch.lnk"
$Desktop = Join-Path ([Environment]::GetFolderPath("Desktop")) "coolwatch 받은 업무.lnk"

function Say($text) { Write-Host "  $text" }

function Stop-Coolwatch {
    $mine = [regex]::Escape($Target)
    Get-CimInstance Win32_Process -Filter "Name like 'python%'" |
        Where-Object { $_.CommandLine -match "$mine\\(app|watcher)\.py" } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

if ($Uninstall) {
    Write-Host "coolwatch 를 끄고 자동 실행을 지웁니다."
    Stop-Coolwatch
    Remove-Item $Startup, $Desktop -Force -ErrorAction SilentlyContinue
    Say "끝났습니다. 정리된 기록과 설정은 남겨 두었습니다: $Target"
    Say "완전히 지우려면 그 폴더를 직접 지우세요."
    exit 0
}

Write-Host ""
Write-Host "coolwatch 설치를 시작합니다. (1~3분 걸립니다)"
Write-Host ""

# ---- 1) 파일 복사 ----
Say "[1/4] 프로그램 파일을 복사합니다 → $Target"
Stop-Coolwatch
New-Item -ItemType Directory -Force $Target | Out-Null
if ((Resolve-Path $Source).Path -ne (Resolve-Path $Target).Path) {
    $keep = @("data", "inbox", "runtime", "fake", "__pycache__", ".git", "dist")   # 설정·기록·실행 환경은 건드리지 않음
    Get-ChildItem -LiteralPath $Source -Force | Where-Object { $keep -notcontains $_.Name -and $_.Name -ne "config.json" } |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force }
}
$cfg = Join-Path $Target "config.json"
if (-not (Test-Path $cfg)) { Copy-Item (Join-Path $Target "config.example.json") $cfg }

# ---- 2) 파이썬 준비 ----
$runtime = Join-Path $Target "runtime"
$pyw = @((Join-Path $runtime "Scripts\pythonw.exe"), (Join-Path $runtime "pythonw.exe")) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($pyw) {
    Say "[2/4] 실행 환경이 이미 있습니다."
} else {
    $sys = $null
    if (-not $ForceEmbedded) {
        foreach ($c in @("python", "py")) {
            $cmd = Get-Command $c -ErrorAction SilentlyContinue
            if ($cmd -and $cmd.Source -notmatch "WindowsApps") {   # WindowsApps 의 python 은 스토어로 보내는 가짜
                $ok = & $cmd.Source -c "import sys; print(int(sys.version_info >= (3, 10)))" 2>$null
                if ($ok -eq "1") { $sys = $cmd.Source; break }
            }
        }
    }
    if ($sys) {
        Say "[2/4] PC에 있는 파이썬으로 실행 환경을 만듭니다."
        & $sys -m venv $runtime
        $py = Join-Path $runtime "Scripts\python.exe"
    } else {
        Say "[2/4] 실행에 필요한 파이썬을 내려받습니다. (python.org, 약 11MB)"
        $zip = Join-Path $env:TEMP "coolwatch-python.zip"
        Invoke-WebRequest "https://www.python.org/ftp/python/$PyVersion/python-$PyVersion-embed-amd64.zip" -OutFile $zip -UseBasicParsing
        Expand-Archive $zip -DestinationPath $runtime -Force
        Remove-Item $zip -Force
        # 이 파이썬이 프로그램 폴더(..)와 추가 꾸러미(Lib\site-packages)를 보게 함
        $pth = Get-ChildItem $runtime -Filter "python*._pth" | Select-Object -First 1
        Set-Content -LiteralPath $pth.FullName -Encoding ASCII -Value @("python312.zip", ".", "..", "Lib\site-packages", "import site")
        $getpip = Join-Path $env:TEMP "coolwatch-get-pip.py"
        Invoke-WebRequest "https://bootstrap.pypa.io/get-pip.py" -OutFile $getpip -UseBasicParsing
        $py = Join-Path $runtime "python.exe"
        & $py $getpip --no-warn-script-location -q
        Remove-Item $getpip -Force
    }
    Say "      트레이 아이콘에 필요한 꾸러미를 설치합니다."
    & $py -m pip install --disable-pip-version-check --no-warn-script-location -q pystray pillow
    if ($LASTEXITCODE -ne 0) { throw "꾸러미 설치에 실패했습니다. 인터넷 연결을 확인하고 다시 실행해 주세요." }
    $pyw = @((Join-Path $runtime "Scripts\pythonw.exe"), (Join-Path $runtime "pythonw.exe")) | Where-Object { Test-Path $_ } | Select-Object -First 1
}
$py = Join-Path (Split-Path $pyw) "python.exe"
& $py -c "import pystray, PIL, sqlite3, sys; sys.path.insert(0, r'$Target'); import common, watcher, ui_server; print('      확인: 프로그램 ' + common.VERSION + ', 파이썬 ' + sys.version.split()[0])"
if ($LASTEXITCODE -ne 0) { throw "실행 환경 확인에 실패했습니다." }

# ---- 3) 바로가기 ----
if ($NoShortcuts) {
    Say "[3/4] (시험) 바로가기를 만들지 않습니다."
} else {
    Say "[3/4] 바탕화면 바로가기와 로그온 자동 실행을 만듭니다."
    $shell = New-Object -ComObject WScript.Shell
    foreach ($lnk in @($Startup, $Desktop)) {
        $s = $shell.CreateShortcut($lnk)
        $s.TargetPath = $pyw
        $s.Arguments = '"' + (Join-Path $Target "app.py") + '"'
        $s.WorkingDirectory = $Target
        $s.Description = "coolwatch 받은 업무"
        $s.Save()
    }
}

# ---- 4) 실행 ----
if ($NoStart) {
    Say "[4/4] (시험) 프로그램을 켜지 않습니다."
} else {
    Say "[4/4] 프로그램을 켭니다. 화면 오른쪽에 창이 열리면 '처음 설정'을 따라 하세요."
    Start-Process -FilePath $pyw -ArgumentList ('"' + (Join-Path $Target "app.py") + '"') -WorkingDirectory $Target
}
Write-Host ""
Write-Host "설치가 끝났습니다. 작업표시줄 오른쪽 아래의 동그란 아이콘이 coolwatch 입니다."
Write-Host "다음부터는 로그온하면 자동으로 켜집니다. 이 압축 폴더는 지워도 됩니다."
