﻿# coolwatch 설치 스크립트 (설치-Claude.bat / 설치-이PC의AI.bat 이 부릅니다)
#  1) 프로그램 파일을 내 PC의 고정된 자리(%LOCALAPPDATA%\coolwatch)에 복사   (다시 실행하면 업데이트: 설정·기록은 그대로)
#  2) 실행에 필요한 파이썬을 그 폴더 안에 따로 준비 (PC에 파이썬이 없어도 됨, 다른 프로그램에 영향 없음)
#  3) 고른 정리 방식 준비: claude = Claude 프로그램 설치(로그인은 처음 설정 화면에서)
#                          local  = Ollama 설치 + 모델 받기(약 3.3GB). 메시지가 PC 밖으로 나가지 않음
#  4) 바탕화면 바로가기와 로그온 자동 실행을 만들고 프로그램을 켬
param(
    [ValidateSet("", "claude", "local")]
    [string]$Mode = "",       # 비워 두면 정리 방식을 바꾸지 않음 (처음 설치면 PC 안 규칙)
    [string]$LocalModel = "qwen3.5:4b",
    [string]$Target = (Join-Path $env:LOCALAPPDATA "coolwatch"),
    [switch]$Uninstall,
    [switch]$ForceEmbedded,   # 시험용: PC에 파이썬이 있어도 내려받는 방식으로
    [switch]$NoShortcuts,     # 시험용: 바로가기·자동 실행을 만들지 않음
    [switch]$NoStart          # 시험용: 설치 뒤 프로그램을 켜지 않음
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Source = Split-Path -Parent $PSScriptRoot
$PyVersion = "3.12.10"
$Startup = Join-Path ([Environment]::GetFolderPath("Startup")) "coolwatch.lnk"
$Desktop = Join-Path ([Environment]::GetFolderPath("Desktop")) "쿨메신저 보조도구.lnk"
$OldDesktop = Join-Path ([Environment]::GetFolderPath("Desktop")) "coolwatch 받은 업무.lnk"   # 예전 이름의 바로가기

function Say($text) { Write-Host "  $text" }

function Stop-Coolwatch {
    $mine = [regex]::Escape($Target)
    Get-CimInstance Win32_Process -Filter "Name like 'python%'" |
        Where-Object { $_.CommandLine -match "$mine\\(app|watcher)\.py" } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

if ($Uninstall) {
    Write-Host "쿨메신저 보조도구를 끄고 자동 실행을 지웁니다."
    Stop-Coolwatch
    Remove-Item $Startup, $Desktop, $OldDesktop -Force -ErrorAction SilentlyContinue
    Say "끝났습니다. 정리된 기록과 설정은 남겨 두었습니다: $Target"
    Say "완전히 지우려면 그 폴더를 직접 지우세요."
    Say "이 PC의 AI(Ollama)와 Claude 프로그램은 다른 데서도 쓸 수 있어 남겨 두었습니다. 지우려면 Windows 설정 → 앱에서 지웁니다."
    exit 0
}

$ModeName = @{ "" = "정리 방식은 그대로"; "claude" = "Claude로 정리"; "local" = "이 PC의 AI로 정리" }[$Mode]
Write-Host ""
Write-Host "쿨메신저 보조도구 설치를 시작합니다. ($ModeName)"
Write-Host $(if ($Mode -eq "local") { "모델을 처음 받으면 10~30분 걸립니다." } else { "1~3분 걸립니다." })
Write-Host ""

# ---- 0) 이 PC의 AI: PC가 감당할 수 있는지 먼저 봄 (중간에 멈추지 않게) ----
if ($Mode -eq "local") {
    $ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
    $freeGB = [math]::Round((Get-Item $env:USERPROFILE).PSDrive.Free / 1GB)
    if ($ramGB -lt 8) { throw "이 PC의 메모리는 ${ramGB}GB입니다. 이 PC의 AI는 8GB 이상(16GB 권장)이 필요합니다. 설치-Claude.bat 을 쓰세요." }
    if ($freeGB -lt 10) { throw "디스크 빈 공간이 ${freeGB}GB입니다. 이 PC의 AI는 10GB 이상이 필요합니다. 공간을 비우거나 설치-Claude.bat 을 쓰세요." }
    if ($ramGB -lt 16) { Say "알림: 메모리가 ${ramGB}GB라 정리가 느리거나 다른 프로그램이 버벅일 수 있습니다(16GB 권장)." }
}

# ---- 1) 파일 복사 ----
Say "[1/5] 프로그램 파일을 복사합니다 → $Target"
Stop-Coolwatch
New-Item -ItemType Directory -Force $Target | Out-Null
if ((Resolve-Path $Source).Path -ne (Resolve-Path $Target).Path) {
    $keep = @("data", "inbox", "runtime", "fake", "__pycache__", ".git", "dist")   # 설정·기록·실행 환경은 건드리지 않음
    Get-ChildItem -LiteralPath $Source -Force | Where-Object { $keep -notcontains $_.Name -and $_.Name -ne "config.json" } |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $Target -Recurse -Force }
}
$cfg = Join-Path $Target "config.json"
if (-not (Test-Path $cfg)) { Copy-Item (Join-Path $Target "config.example.json") $cfg }

# ---- 2) 파이썬 준비 ----
$runtime = Join-Path $Target "runtime"
$pyw = @((Join-Path $runtime "Scripts\pythonw.exe"), (Join-Path $runtime "pythonw.exe")) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($pyw) {
    Say "[2/5] 실행 환경이 이미 있습니다."
} else {
    $sys = $null
    if (-not $ForceEmbedded) {
        foreach ($c in @("python", "py")) {
            $cmd = Get-Command $c -ErrorAction SilentlyContinue
            if ($cmd -and $cmd.Source -notmatch "WindowsApps") {   # WindowsApps 의 python 은 스토어로 보내는 가짜
                $ok = & $cmd.Source -c "import sys; print(int(sys.version_info >= (3, 10)))" 2>$null
                if ($ok -eq "1") { $sys = $cmd.Source; break }
            }
        }
    }
    if ($sys) {
        Say "[2/5] PC에 있는 파이썬으로 실행 환경을 만듭니다."
        & $sys -m venv $runtime
        $py = Join-Path $runtime "Scripts\python.exe"
    } else {
        Say "[2/5] 실행에 필요한 파이썬을 내려받습니다. (python.org, 약 11MB)"
        $zip = Join-Path $env:TEMP "coolwatch-python.zip"
        Invoke-WebRequest "https://www.python.org/ftp/python/$PyVersion/python-$PyVersion-embed-amd64.zip" -OutFile $zip -UseBasicParsing
        Expand-Archive $zip -DestinationPath $runtime -Force
        Remove-Item $zip -Force
        # 이 파이썬이 프로그램 폴더(..)와 추가 꾸러미(Lib\site-packages)를 보게 함
        $pth = Get-ChildItem $runtime -Filter "python*._pth" | Select-Object -First 1
        Set-Content -LiteralPath $pth.FullName -Encoding ASCII -Value @("python312.zip", ".", "..", "Lib\site-packages", "import site")
        $getpip = Join-Path $env:TEMP "coolwatch-get-pip.py"
        Invoke-WebRequest "https://bootstrap.pypa.io/get-pip.py" -OutFile $getpip -UseBasicParsing
        $py = Join-Path $runtime "python.exe"
        & $py $getpip --no-warn-script-location -q
        Remove-Item $getpip -Force
    }
    Say "      트레이 아이콘에 필요한 꾸러미를 설치합니다."
    & $py -m pip install --disable-pip-version-check --no-warn-script-location -q pystray pillow
    if ($LASTEXITCODE -ne 0) { throw "꾸러미 설치에 실패했습니다. 인터넷 연결을 확인하고 다시 실행해 주세요." }
    $pyw = @((Join-Path $runtime "Scripts\pythonw.exe"), (Join-Path $runtime "pythonw.exe")) | Where-Object { Test-Path $_ } | Select-Object -First 1
}
$py = Join-Path (Split-Path $pyw) "python.exe"
& $py -c "import pystray, PIL, sqlite3, sys; sys.path.insert(0, r'$Target'); import common, watcher, ui_server; print('      확인: 프로그램 ' + common.VERSION + ', 파이썬 ' + sys.version.split()[0])"
if ($LASTEXITCODE -ne 0) { throw "실행 환경 확인에 실패했습니다." }

# ---- 3) 정리 방식 준비 ----
function Set-Mode($m) {
    & $py -c "import sys; sys.path.insert(0, r'$Target'); from common import read_json, save_config; p = r'$cfg'; c = read_json(p, {}) or {}; c['summary_mode'] = '$m'; save_config(p, c)"
    if ($LASTEXITCODE -ne 0) { throw "설정 저장에 실패했습니다." }
}
function Find-Ollama {
    $p = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
    if (Test-Path $p) { return $p }
    $c = Get-Command ollama -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    return $null
}
function Test-OllamaUp { try { Invoke-RestMethod "http://127.0.0.1:11434/api/version" -TimeoutSec 2 | Out-Null; return $true } catch { return $false } }
function Install-Ollama {
    Say "      Ollama(이 PC에서 AI 모델을 돌리는 프로그램)를 내려받아 설치합니다. (ollama.com, 약 1.6GB). 몇 분 동안 화면이 멈춘 듯 보여도 창을 닫지 마세요."
    $setup = Join-Path $env:TEMP "OllamaSetup.exe"
    Invoke-WebRequest "https://ollama.com/download/OllamaSetup.exe" -OutFile $setup -UseBasicParsing
    Start-Process $setup -ArgumentList "/VERYSILENT", "/NORESTART", "/SUPPRESSMSGBOXES" -Wait
    Remove-Item $setup -Force -ErrorAction SilentlyContinue
}
function Start-Ollama($exe) {
    if (Test-OllamaUp) { return }
    $app = Join-Path (Split-Path $exe) "ollama app.exe"
    if (Test-Path $app) { Start-Process $app } else { Start-Process $exe -ArgumentList "serve" -WindowStyle Hidden }
    for ($i = 0; $i -lt 30 -and -not (Test-OllamaUp); $i++) { Start-Sleep 1 }
    if (-not (Test-OllamaUp)) { throw "Ollama가 켜지지 않습니다. PC를 다시 시작한 뒤 설치 파일을 다시 실행해 주세요." }
}

if ($Mode -eq "claude") {
    Say "[3/5] Claude로 정리하도록 준비합니다."
    $claude = @((Join-Path $env:USERPROFILE ".local\bin\claude.exe"), (Join-Path $env:APPDATA "npm\claude.cmd")) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $claude) { $c = Get-Command claude -ErrorAction SilentlyContinue; if ($c) { $claude = $c.Source } }
    if ($claude) {
        Say "      Claude 프로그램이 이미 있습니다."
    } else {
        Say "      Claude 프로그램을 설치합니다. (Anthropic 공식 설치 명령)"
        try { Invoke-RestMethod "https://claude.ai/install.ps1" | Invoke-Expression }
        catch { Say "      Claude 설치에 실패했습니다. 나중에 '처음 설정' 화면의 [Claude 설치]로 다시 할 수 있습니다." }
    }
    Set-Mode "claude"
    Say "      로그인은 프로그램이 켜진 뒤 '처음 설정' 화면의 [로그인]으로 합니다(Pro·Max 구독 계정)."
} elseif ($Mode -eq "local") {
    Say "[3/5] 이 PC의 AI를 준비합니다. (모델: $LocalModel)"
    $ollama = Find-Ollama
    $fresh = $false
    if (-not $ollama) { Install-Ollama; $fresh = $true; $ollama = Find-Ollama }
    if (-not $ollama) { throw "Ollama 설치를 확인하지 못했습니다. https://ollama.com 에서 직접 설치한 뒤 다시 실행해 주세요." }
    Start-Ollama $ollama
    Say "      모델을 받습니다. 처음에는 약 3.3GB라 시간이 걸립니다. 이미 있으면 바로 끝납니다."
    & $ollama pull $LocalModel
    if ($LASTEXITCODE -ne 0 -and -not $fresh) {   # 예전 Ollama는 새 모델을 모를 수 있어, 새 버전으로 한 번 바꾸고 다시 받음
        Say "      모델을 받지 못했습니다. Ollama를 새 버전으로 바꾸고 다시 받습니다."
        Install-Ollama
        Start-Ollama $ollama
        & $ollama pull $LocalModel
    }
    if ($LASTEXITCODE -ne 0) { throw "모델($LocalModel)을 받지 못했습니다. 학교망이 막았을 수 있습니다. 다른 인터넷에서 다시 실행하거나 설치-Claude.bat 을 쓰세요." }
    Set-Mode "local"
    Say "      준비되었습니다. 메시지는 이 PC 밖으로 나가지 않습니다."
} else {
    Say "[3/5] 정리 방식은 그대로 둡니다."
}

# ---- 4) 바로가기 ----
if ($NoShortcuts) {
    Say "[4/5] (시험) 바로가기를 만들지 않습니다."
} else {
    Say "[4/5] 바탕화면 바로가기와 로그온 자동 실행을 만듭니다."
    Remove-Item $OldDesktop -Force -ErrorAction SilentlyContinue
    $shell = New-Object -ComObject WScript.Shell
    foreach ($lnk in @($Startup, $Desktop)) {
        $s = $shell.CreateShortcut($lnk)
        $s.TargetPath = $pyw
        $s.Arguments = '"' + (Join-Path $Target "app.py") + '"'
        if ($lnk -eq $Desktop) { $s.Arguments += " --open" }   # 바탕화면 아이콘은 켜면서 창도 엶
        $s.WorkingDirectory = $Target
        $s.Description = "쿨메신저 보조도구"
        $s.IconLocation = (Join-Path $Target "app.ico") + ",0"
        $s.Save()
    }
}

# ---- 5) 실행 ----
if ($NoStart) {
    Say "[5/5] (시험) 프로그램을 켜지 않습니다."
} else {
    Say "[5/5] 프로그램을 켭니다. 화면 오른쪽에 창이 열리면 '처음 설정'을 따라 하세요."
    Start-Process -FilePath $pyw -ArgumentList ('"' + (Join-Path $Target "app.py") + '"') -WorkingDirectory $Target
}
Write-Host ""
Write-Host "설치가 끝났습니다. 작업표시줄 오른쪽 아래의 동그란 아이콘이 쿨메신저 보조도구입니다."
Write-Host "다음부터는 로그온하면 자동으로 켜집니다. 이 압축 폴더는 지워도 됩니다."
if ($Mode -eq "claude") { Write-Host "남은 일: 화면 오른쪽 창의 '처음 설정'에서 Claude [로그인]을 누르세요." }
