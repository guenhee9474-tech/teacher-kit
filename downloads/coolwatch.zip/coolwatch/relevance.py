# relevance.py - 이 메시지가 '나'와 관련된 것인지, '전체 교사' 대상인지 가려냅니다. (PC 안에서 규칙으로)
# config.json 의 my_roles(예: ["1학년 담임", "영어과", "인문사회부"])와 my_name 을 씁니다.
import re

EVERYONE = re.compile(
    r"전\s*교직원|전체\s*교직원|전체\s*교사|전\s*교사|모든\s*(?:선생님|교사|교직원)|전체\s*선생님|선생님들|샘들|쌤들"
    r"|교직원\s*여러분|선생님\s*여러분|전\s*직원|전체\s*직원|모두\s*께|전체\s*안내|전체\s*공지"
    r"|각\s*교과\s*(?:선생님|교사)|교과\s*선생님들|교직원\s*(?:배구|체육|연수|회식|친목|협의회)")
# 학년을 밝히지 않은 '각 반 담임' 은 담임 역할이면 내 일
ANY_HOMEROOM = re.compile(r"각\s*반\s*담임|담임\s*선생님(?:들)?\s*(?:께서는|께|은|는)")
# 다른 집단을 콕 집은 말 (이게 있고 내 역할이 아니면 '기타')
OTHER_GROUP = re.compile(r"[1-6]\s*학년|담임|부장|[가-힣]{2,6}(?:과|부)\s*(?:선생님|교사|샘|쌤)|기간제|신규\s*교사|비담임|위원(?:이신|님|분|으로)|해당\s*(?:선생님|교사)")
# 대상을 밝히지 않은 공지·안내는 모두에게 보낸 글로 봄
NOTICE = re.compile(r"공지|알려\s*드립니다|참고\s*바랍니다|참고하시기|휴관|휴무|없습니다\.?\s*참고|양해\s*부탁|이용이\s*어렵")


def role_variants(role):
    """'1학년 담임' -> 토큰 ['1학년','담임'] / '영어과' -> ['영어과' 또는 '영어 교과'...] 로 느슨하게 맞추기"""
    role = role.strip()
    toks = [t for t in re.split(r"\s+", role) if t]
    pats = []
    for t in toks:
        t = re.escape(t)
        t = re.sub(r"(\d)학년", r"\1\\s*학년", t)                 # 1학년 / 1 학년
        if t.endswith("과") and len(t) > 2:                         # 영어과 -> 영어과 / 영어 교과 / 영어 선생님
            stem = t[:-1]
            t = f"{stem}(?:과|\\s*교과|\\s*(?:선생님|교사|샘|쌤))"
        pats.append(t)
    return [re.compile(p) for p in pats]


def classify(cfg, title, text):
    """반환: (관련: '나'|'전체'|'기타', 대상: 사람이 읽을 짧은 말)"""
    body = f"{title}\n{text}"
    head = body[:400]   # 누구에게 보낸 글인지는 보통 앞부분에 있음
    cfg = cfg or {}
    hits = []
    for role in cfg.get("my_roles") or []:
        pats = role_variants(role)
        if pats and all(p.search(head) for p in pats):
            hits.append(role)
    name = (cfg.get("my_name") or "").strip()
    if name and re.search(re.escape(name) + r"\s*(?:선생님|샘|쌤|부장|님)", body):
        hits.append(name)
    if not hits and any("담임" in r and "비담임" not in r for r in cfg.get("my_roles") or []):
        m = ANY_HOMEROOM.search(head)
        if m and not re.search(r"[1-6]\s*학년", head[max(0, m.start() - 12):m.end()]):
            hits.append("담임")
    if hits:
        return "나", ", ".join(dict.fromkeys(hits))
    if EVERYONE.search(head) and not OTHER_GROUP.search(head[:120]):
        return "전체", "전체 교사"
    m = OTHER_GROUP.search(head[:120])
    if m:
        return "기타", m.group(0).strip()
    if EVERYONE.search(head):
        return "전체", "전체 교사"
    if NOTICE.search(body[:600]):
        return "전체", "전체 교사"
    return "기타", ""
