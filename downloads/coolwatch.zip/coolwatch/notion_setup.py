# notion_setup.py - 노션 연결 설정 도우미 (교사가 한 번만 실행)
# 하는 일: ① 키를 입력받아 ② '받은 업무함'에 접근되는지 확인하고 ③ 사용자 환경변수 NOTION_TOKEN 에 저장하고 ④ 시험 페이지를 하나 올립니다.
# 키는 파일에 적지 않고 환경변수(Windows 사용자 설정)에만 저장합니다.
import getpass, json, os, subprocess, sys, urllib.error, urllib.request

from common import load_config
import notion_sync

NEED = ["제목", "상태", "발신자", "받은시각", "요약", "요청사항", "기한", "기한일", "일정", "일정일",
        "링크", "첨부", "정리방식", "메시지키", "관련", "대상"]   # ui_server.NEED_PROPS 와 같게 유지

GUIDE = """
[준비 — 노션에서 2분]
 1. 브라우저에서 https://www.notion.so/profile/integrations 를 엽니다.
 2. '새 통합(New integration)'을 만들고 이름은 coolwatch, 유형은 '내부(Internal)'로 합니다.
 3. 만들어진 통합의 '내부 통합 시크릿(Internal Integration Secret)'을 복사합니다. (ntn_ 또는 secret_ 로 시작)
 4. 노션에서 '받은 업무함' 데이터베이스를 열고, 오른쪽 위 ··· 메뉴 → '연결(Connections)' → coolwatch 를 추가합니다.
"""


def api(token, method, path, body=None):
    req = urllib.request.Request("https://api.notion.com" + path, method=method,
                                 data=json.dumps(body).encode() if body else None,
                                 headers={"Authorization": f"Bearer {token}", "Notion-Version": notion_sync.NOTION_VERSION,
                                          "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read())


def main():
    cfg = load_config()
    db = cfg.get("notion_database_id")
    if not db:
        sys.exit("config.json 에 notion_database_id 가 없습니다.")
    print(GUIDE)
    token = os.environ.get("NOTION_TOKEN") or ""
    if token:
        print("이미 NOTION_TOKEN 이 설정되어 있습니다. 새로 바꾸려면 아래에 입력하고, 그대로 쓰려면 Enter 만 누르세요.")
    entered = getpass.getpass("시크릿 붙여넣기 (화면에 안 보임): ").strip()
    token = entered or token
    if not token:
        sys.exit("키가 없습니다.")

    print("\n접속 확인 중…")
    try:
        info = api(token, "GET", f"/v1/databases/{db}")
    except urllib.error.HTTPError as e:
        hint = {401: "키가 올바르지 않습니다.", 404: "'받은 업무함'이 이 통합과 공유되지 않았습니다. 준비 4번을 확인하세요."}.get(e.code, "")
        sys.exit(f"실패 (HTTP {e.code}). {hint}")
    except OSError as e:
        sys.exit(f"노션에 접속하지 못했습니다: {type(e).__name__}")
    have = set(info.get("properties", {}))
    missing = [n for n in NEED if n not in have]
    if missing:
        sys.exit(f"데이터베이스에 없는 속성이 있습니다: {', '.join(missing)}")
    print("OK: '받은 업무함'에 접근되고 속성이 모두 맞습니다.")

    if entered:
        subprocess.run(["setx", "NOTION_TOKEN", token], capture_output=True, check=True)
        print("키를 사용자 환경변수 NOTION_TOKEN 에 저장했습니다. (파일에는 적지 않았습니다)")
    os.environ["NOTION_TOKEN"] = token

    if input("\n시험 페이지를 하나 올려 볼까요? (y/N) ").strip().lower() == "y":
        entry = {"key": 0, "sender": "coolwatch", "title": "[시험] 연결 확인", "when_iso": None, "attach": "", "original": "",
                 "summary": {"한줄요약": "coolwatch 연결 시험입니다. 지워도 됩니다.", "요청사항": [], "기한": [], "일정": [],
                             "준비물": [], "링크": [], "방식": "규칙"}}
        print("올렸습니다:", notion_sync.push_api({**cfg, "notion_mode": "api"}, entry))
    print("\n마지막: 트레이 아이콘 → '연동까지 끄기' 후 python app.py 로 다시 실행하세요. (새 환경변수가 적용됩니다)")


if __name__ == "__main__":
    main()
