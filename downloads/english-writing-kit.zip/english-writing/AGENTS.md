# 이 폴더에서 일하는 AI 도구에게

이 프로젝트의 설명서와 규칙은 `CLAUDE.md` 에 있다. 작업을 시작하기 전에 `CLAUDE.md` 를 읽고 그대로 따른다.
(Claude Code 는 `CLAUDE.md` 를 스스로 읽는다. 이 파일은 Antigravity CLI 처럼 `AGENTS.md` 를 읽는 도구를 위한 안내다.)
